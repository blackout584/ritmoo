@file:OptIn(ExperimentalMaterial3Api::class)

package com.ritmo.player.ui

import android.net.Uri
import androidx.compose.animation.core.animateFloat
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.RowScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.ritmo.player.data.Song
import com.ritmo.player.data.SongSort
import kotlinx.coroutines.delay

fun formatTime(ms: Long): String {
    val totalSec = (ms / 1000).coerceAtLeast(0)
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

fun formatSpeed(speed: Float): String {
    val text = if (speed % 1f == 0f) speed.toInt().toString() else speed.toString()
    return text.replace('.', ',') + "x"
}

@Composable
fun SimpleTopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    TopAppBar(
        title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        navigationIcon = {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Voltar")
                }
            }
        },
        actions = actions,
        windowInsets = WindowInsets(0, 0, 0, 0),
    )
}

@Composable
fun ArtImage(uri: Uri?, modifier: Modifier = Modifier, corner: Dp = 8.dp) {
    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            Icons.Rounded.MusicNote, null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxSize(0.45f),
        )
        if (uri != null) {
            AsyncImage(
                model = uri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

@Composable
fun EmptyMessage(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(
            text,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** Posição atual da música, atualizada duas vezes por segundo. */
@Composable
fun rememberPlaybackPosition(vm: MainViewModel): State<Long> {
    val pos = remember { mutableLongStateOf(vm.positionMs()) }
    LaunchedEffect(Unit) {
        while (true) {
            pos.longValue = vm.positionMs()
            delay(500)
        }
    }
    return pos
}

@Composable
fun SongList(
    songs: List<Song>,
    vm: MainViewModel,
    playlistId: Long? = null,
    header: (@Composable () -> Unit)? = null,
    sortControl: (@Composable () -> Unit)? = null,
) {
    val player by vm.player.collectAsStateWithLifecycle()
    LazyColumn(Modifier.fillMaxSize()) {
        if (header != null) item { header() }
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("${songs.size} músicas", style = MaterialTheme.typography.labelLarge)
                    sortControl?.invoke()
                }
                FilledTonalButton(onClick = { vm.shuffleAll(songs) }, enabled = songs.isNotEmpty()) {
                    Icon(Icons.Rounded.Shuffle, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Aleatório")
                }
                Spacer(Modifier.width(8.dp))
                Button(onClick = { vm.playSongs(songs, 0) }, enabled = songs.isNotEmpty()) {
                    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Tocar")
                }
            }
        }
        itemsIndexed(songs, key = { i, s -> "${s.id}_$i" }) { i, song ->
            SongRow(
                song = song,
                isCurrent = player.mediaId == song.id.toString(),
                isPlaying = player.isPlaying,
                vm = vm,
                playlistId = playlistId,
                onClick = { vm.playSongs(songs, i) },
                modifier = Modifier.animateItem(),
            )
        }
    }
}

@Composable
fun SongRow(
    song: Song,
    isCurrent: Boolean,
    isPlaying: Boolean,
    vm: MainViewModel,
    playlistId: Long?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var menu by remember { mutableStateOf(false) }
    var addDialog by remember { mutableStateOf(false) }
    ListItem(
        modifier = modifier.clickable(onClick = onClick),
        leadingContent = {
            Box(contentAlignment = Alignment.Center) {
                ArtImage(song.artUri, Modifier.size(48.dp))
                // Mini barrinhas animadas na música que está tocando
                if (isCurrent) {
                    Box(
                        Modifier.size(48.dp).clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.45f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        PlayingIndicator(isPlaying, MaterialTheme.colorScheme.primary)
                    }
                }
            }
        },
        headlineContent = {
            Text(
                song.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (isCurrent) MaterialTheme.colorScheme.primary else Color.Unspecified,
                fontWeight = if (isCurrent) FontWeight.Bold else null,
            )
        },
        supportingContent = {
            Text(
                "${song.artist} • ${formatTime(song.durationMs)}",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        },
        trailingContent = {
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "Opções") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Tocar a seguir") },
                        onClick = { vm.playNext(song); menu = false },
                    )
                    DropdownMenuItem(
                        text = { Text("Adicionar à fila") },
                        onClick = { vm.addToQueue(song); menu = false },
                    )
                    DropdownMenuItem(
                        text = { Text("Adicionar à playlist") },
                        onClick = { addDialog = true; menu = false },
                    )
                    if (playlistId != null) {
                        DropdownMenuItem(
                            text = { Text("Remover da playlist") },
                            onClick = { vm.playlistStore.removeSong(playlistId, song.id); menu = false },
                        )
                    }
                }
            }
        },
    )
    if (addDialog) AddToPlaylistDialog(vm, listOf(song.id)) { addDialog = false }
}

@Composable
fun AddToPlaylistDialog(vm: MainViewModel, songIds: List<Long>, onDismiss: () -> Unit) {
    val playlists by vm.playlistStore.playlists.collectAsStateWithLifecycle()
    var creating by remember { mutableStateOf(false) }
    val context = LocalContext.current

    if (creating) {
        NameDialog(
            title = "Nova playlist",
            initial = "",
            confirmLabel = "Criar",
            onConfirm = { name ->
                val p = vm.playlistStore.create(name)
                vm.playlistStore.addSongs(p.id, songIds)
                Toast.makeText(context, "Adicionada a $name", Toast.LENGTH_SHORT).show()
                onDismiss()
            },
            onDismiss = { creating = false },
        )
        return
    }

    val transparent = ListItemDefaults.colors(containerColor = Color.Transparent)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Adicionar à playlist") },
        text = {
            LazyColumn {
                item {
                    ListItem(
                        colors = transparent,
                        leadingContent = { Icon(Icons.Rounded.Add, null) },
                        headlineContent = { Text("Nova playlist") },
                        modifier = Modifier.clickable { creating = true },
                    )
                }
                items(playlists, key = { it.id }) { p ->
                    ListItem(
                        colors = transparent,
                        headlineContent = { Text(p.name) },
                        supportingContent = { Text("${p.songIds.size} músicas") },
                        modifier = Modifier.clickable {
                            vm.playlistStore.addSongs(p.id, songIds)
                            Toast.makeText(context, "Adicionada a ${p.name}", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        },
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                label = { Text("Nome") },
            )
        },
        confirmButton = {
            TextButton(enabled = text.isNotBlank(), onClick = { onConfirm(text.trim()) }) {
                Text(confirmLabel)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
fun GroupRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    trailing: (@Composable () -> Unit)? = null,
) {
    ListItem(
        modifier = Modifier.clickable(onClick = onClick),
        leadingContent = {
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(24.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        },
        headlineContent = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        supportingContent = { Text(subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        trailingContent = trailing,
    )
}


/** Três barrinhas que pulam, mostrando a música que está tocando. */
@Composable
fun PlayingIndicator(isPlaying: Boolean, color: Color) {
    val transition = androidx.compose.animation.core.rememberInfiniteTransition(label = "eq")
    Row(
        Modifier.size(width = 20.dp, height = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        listOf(420, 560, 360).forEachIndexed { i, duration ->
            val animated by transition.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                    androidx.compose.animation.core.tween(duration),
                    androidx.compose.animation.core.RepeatMode.Reverse,
                ),
                label = "bar$i",
            )
            val h = if (isPlaying) animated else 0.3f
            Box(
                Modifier.weight(1f).fillMaxHeight(h)
                    .clip(RoundedCornerShape(2.dp))
                    .background(color)
            )
        }
    }
}

/** Botão "Ordenar" com a lista de opções. */
@Composable
fun SortButton(current: SongSort, onSelect: (SongSort) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable { open = true }
                .padding(vertical = 4.dp, horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.AutoMirrored.Rounded.Sort, null,
                Modifier.size(16.dp),
                tint = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.width(4.dp))
            Text(
                current.label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            Text(
                "Ordenar por",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            )
            SongSort.entries.forEach { option ->
                DropdownMenuItem(
                    text = {
                        Text(
                            option.label,
                            fontWeight = if (option == current) FontWeight.Bold else null,
                            color = if (option == current) MaterialTheme.colorScheme.primary else Color.Unspecified,
                        )
                    },
                    leadingIcon = {
                        if (option == current) Icon(Icons.Rounded.Check, null, tint = MaterialTheme.colorScheme.primary)
                        else Spacer(Modifier.size(24.dp))
                    },
                    onClick = { onSelect(option); open = false },
                )
            }
        }
    }
}
