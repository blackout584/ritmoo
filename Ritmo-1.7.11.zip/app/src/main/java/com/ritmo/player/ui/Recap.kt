package com.ritmo.player.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.data.MonthStats
import com.ritmo.player.data.MonthlyStatsStore
import com.ritmo.player.data.Song
import java.io.File
import java.util.Calendar

/** Dados prontos para mostrar a retrospectiva de um mês. */
private data class RecapData(
    val top: List<Pair<Song, Int>>,
    val artists: List<Triple<String, Int, android.net.Uri?>>,
    val plays: Int,
    val hours: Long,
    val minutes: Long,
)

private fun buildRecap(stats: MonthStats, songs: List<Song>, artistArt: (String) -> android.net.Uri? = { null }): RecapData {
    val byId = songs.associateBy { it.id }
    val top = stats.songPlays.entries
        .sortedByDescending { it.value }
        .mapNotNull { (id, c) -> byId[id]?.let { it to c } }
    val artists = stats.artistPlays.entries
        .sortedByDescending { it.value }
        .take(6)
        .map { (name, c) -> Triple(name, c, artistArt(name) ?: songs.firstOrNull { it.artist == name }?.artUri) }
    val totalMin = stats.listenedMs / 60_000
    return RecapData(top, artists, stats.plays, totalMin / 60, totalMin % 60)
}

private fun durationText(r: RecapData): String = when {
    r.hours > 0 -> "${r.hours}h"
    else -> "${r.minutes} min"
}

// ---------------- Tela de um mês ----------------

@Composable
fun RecapScreen(month: String, vm: MainViewModel, onBack: () -> Unit) {
    val months by vm.monthlyStats.months.collectAsStateWithLifecycle()
    val songs by vm.songs.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val stats = months[month] ?: MonthStats()
    val photos by vm.artistPhotos.photos.collectAsStateWithLifecycle()
    val recap = remember(stats, songs, photos) { buildRecap(stats, songs) { vm.artistPhotos.uriFor(it) } }
    val title = MonthlyStatsStore.label(month).replaceFirstChar { it.uppercase() }
    val inProgress = month == MonthlyStatsStore.currentMonthKey()
    val primary = MaterialTheme.colorScheme.primary
    BackHandler(onBack = onBack)

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(primary.copy(alpha = 0.35f), MaterialTheme.colorScheme.background)))
    ) {
        Column(Modifier.fillMaxSize()) {
            SimpleTopBar(title, onBack = onBack, actions = {
                IconButton(onClick = { shareRecap(context, title, recap) }) { Icon(Icons.Rounded.Share, "Compartilhar") }
            })
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)
            ) {
                if (inProgress) {
                    Text(
                        "Mês em andamento: os números ainda vão mudar até o fim do mês.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp),
                    )
                }
                if (recap.plays == 0) {
                    Text("Nada tocado neste mês ainda.", modifier = Modifier.padding(top = 24.dp))
                    return@Column
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    BigNumber(durationText(recap), "ouvindo música", Modifier.weight(1f))
                    BigNumber("${recap.plays}", "músicas tocadas", Modifier.weight(1f))
                }

                SectionTitleRecap("Top 5 músicas")
                recap.top.take(5).forEachIndexed { i, (song, count) ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { vm.playSongs(recap.top.map { it.first }, i) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "${i + 1}",
                            color = primary,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.width(28.dp),
                        )
                        ArtImage(song.artUri, Modifier.size(46.dp).clip(RoundedCornerShape(8.dp)), corner = 8.dp)
                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                            Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                            Text(
                                "${song.artist} · ${if (count == 1) "1 vez" else "$count vezes"}",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }

                if (recap.artists.isNotEmpty()) {
                    SectionTitleRecap("Artistas do mês")
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        recap.artists.forEach { (name, count, art) ->
                            Column(Modifier.width(72.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                ArtImage(art, Modifier.size(64.dp).clip(CircleShape), corner = 32.dp)
                                Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
                                Text("$count", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))
                val ids = recap.top.take(25).map { it.first.id }
                Button(
                    onClick = {
                        val name = vm.saveRecapPlaylist(month, ids)
                        Toast.makeText(context, "Playlist \"$name\" criada", Toast.LENGTH_SHORT).show()
                    },
                    enabled = ids.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.AutoMirrored.Rounded.PlaylistAdd, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Salvar como playlist \"${MonthlyStatsStore.shortLabel(month)}\"", maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Spacer(Modifier.height(8.dp))
                FilledTonalButton(
                    onClick = { vm.playSongs(recap.top.map { it.first }, 0) },
                    enabled = recap.top.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Tocar as mais ouvidas")
                }
                Spacer(Modifier.height(32.dp))
            }
        }
    }
}

@Composable
private fun BigNumber(value: String, label: String, modifier: Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
            .padding(14.dp)
    ) {
        Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SectionTitleRecap(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 20.dp, bottom = 6.dp),
    )
}

// ---------------- Lista de meses ----------------

@Composable
fun RecapsListScreen(vm: MainViewModel, onOpen: (String) -> Unit, onBack: () -> Unit) {
    val months by vm.monthlyStats.months.collectAsStateWithLifecycle()
    val current = MonthlyStatsStore.currentMonthKey()
    val keys = remember(months) { (months.keys + current).distinct().sortedDescending() }
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize()) {
        SimpleTopBar("Retrospectivas", onBack = onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            keys.forEach { key ->
                val m = months[key] ?: MonthStats()
                val min = m.listenedMs / 60_000
                val time = if (min >= 60) "${min / 60}h" else "$min min"
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                        .clickable { onOpen(key) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Rounded.CalendarMonth, null, tint = MaterialTheme.colorScheme.primary) }
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(
                            MonthlyStatsStore.label(key).replaceFirstChar { it.uppercase() } + if (key == current) " (em andamento)" else "",
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            if (m.plays == 0) "Nada tocado ainda" else (if (key == current) "até agora: " else "") + "$time · ${m.plays} músicas",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Icon(Icons.Rounded.ChevronRight, null)
                }
            }
            Text(
                "A contagem por mês começou na versão 1.7.9. No dia 1 de cada mês chega o aviso da retrospectiva.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 16.dp),
            )
        }
    }
}

// ---------------- Cartão no Início ----------------

/** Aparece nos 7 primeiros dias do mês, se o mês passado teve músicas tocadas. */
@Composable
fun HomeRecapCard(vm: MainViewModel, onOpen: (String) -> Unit) {
    val months by vm.monthlyStats.months.collectAsStateWithLifecycle()
    val songs by vm.songs.collectAsStateWithLifecycle()
    if (Calendar.getInstance().get(Calendar.DAY_OF_MONTH) > 7) return
    val month = MonthlyStatsStore.previousMonthKey()
    val stats = months[month] ?: return
    if (stats.plays == 0) return
    val recap = remember(stats, songs) { buildRecap(stats, songs) }
    val name = MonthlyStatsStore.label(month).substringBefore(" de ")
    val primary = MaterialTheme.colorScheme.primary
    Column(
        Modifier
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(listOf(primary.copy(alpha = 0.45f), primary.copy(alpha = 0.18f))))
            .clickable { onOpen(month) }
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.CalendarMonth, null, Modifier.size(20.dp))
            Text(
                "Sua retrospectiva de $name",
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 8.dp),
            )
        }
        Text(
            listOfNotNull(
                "${durationText(recap)} ouvidas",
                recap.top.firstOrNull()?.first?.title?.let { "top: $it" },
            ).joinToString(" · "),
            style = MaterialTheme.typography.bodySmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 4.dp),
        )
        Text("Ver retrospectiva ›", color = primary, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
    }
}

// ---------------- Compartilhar como imagem ----------------

private fun shareRecap(context: Context, title: String, r: RecapData) {
    runCatching {
        val w = 1080
        val h = 1350
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val bg = Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, h.toFloat(), Color(0xFF72243E).toArgb(), Color(0xFF16101A).toArgb(), Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)
        fun paint(size: Float, bold: Boolean, color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = color
            typeface = Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        val white = android.graphics.Color.WHITE
        val pink = Color(0xFFED93B1).toArgb()
        val soft = Color(0xFFD3D1C7).toArgb()
        fun clip(text: String, p: Paint, max: Float): String {
            if (p.measureText(text) <= max) return text
            var t = text
            while (t.isNotEmpty() && p.measureText("$t…") > max) t = t.dropLast(1)
            return "$t…"
        }
        var y = 140f
        c.drawText("Minha retrospectiva", 80f, y, paint(44f, false, soft)); y += 80f
        c.drawText(title, 80f, y, paint(72f, true, white)); y += 140f
        c.drawText(durationText(r), 80f, y, paint(96f, true, pink))
        c.drawText("${r.plays}", 560f, y, paint(96f, true, pink)); y += 56f
        c.drawText("ouvindo música", 80f, y, paint(38f, false, soft))
        c.drawText("músicas tocadas", 560f, y, paint(38f, false, soft)); y += 120f
        c.drawText("Top 5 músicas", 80f, y, paint(48f, true, white)); y += 30f
        r.top.take(5).forEachIndexed { i, (s, n) ->
            y += 90f
            c.drawText("${i + 1}", 80f, y, paint(52f, true, pink))
            c.drawText(clip(s.title, paint(44f, true, white), 820f), 160f, y, paint(44f, true, white))
            c.drawText(clip("${s.artist} · $n vezes", paint(34f, false, soft), 820f), 160f, y + 44f, paint(34f, false, soft))
        }
        y += 140f
        if (r.artists.isNotEmpty()) {
            c.drawText("Artistas: " + r.artists.take(4).joinToString(", ") { it.first }.let { clip(it, paint(40f, false, white), 900f) }, 80f, y, paint(40f, false, white))
        }
        c.drawText("Ritmo", 80f, h - 70f, paint(40f, true, pink))

        val dir = File(context.cacheDir, "shared").apply { mkdirs() }
        val file = File(dir, "retrospectiva.png")
        file.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        context.startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND)
                    .setType("image/png")
                    .putExtra(Intent.EXTRA_STREAM, uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
                "Compartilhar retrospectiva",
            )
        )
    }.onFailure {
        Toast.makeText(context, "Não deu para compartilhar agora", Toast.LENGTH_SHORT).show()
    }
}
