@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.ritmo.player.ui

import androidx.compose.foundation.border
import androidx.compose.ui.graphics.lerp
import android.widget.Toast
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.material.icons.rounded.DragIndicator
import androidx.compose.material.icons.rounded.Save
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.zIndex
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.SmartDisplay
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.launch
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import com.ritmo.player.data.AppThemeId
import com.ritmo.player.data.PlayMode
import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.layout.Box
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.core.content.ContextCompat
import com.ritmo.player.playback.AudioEffects
import com.ritmo.player.playback.AudioVisualizer
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import com.ritmo.player.data.FAVORITES_ID
import kotlinx.coroutines.delay

// ---------------- Mini player (barra inferior) ----------------

@Composable
fun MiniPlayer(state: PlayerUiState, vm: MainViewModel, onClick: () -> Unit) {
    val position by rememberPlaybackPosition(vm)
    // Cor do mini player tirada da capa da música
    val artColors = rememberArtColors(state.artUri, MaterialTheme.colorScheme.primary)
    val container by animateColorAsState(
        lerp(artColors.accent, artColors.background, 0.45f),
        tween(700),
        label = "miniColor",
    )
    Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
        Surface(
            onClick = onClick,
            color = container,
            contentColor = Color.White,
            shape = RoundedCornerShape(32.dp),
            shadowElevation = 8.dp,
            modifier = Modifier.fillMaxWidth().padding(start = 12.dp),
        ) {
            Column {
                Row(
                    Modifier.padding(start = 58.dp, end = 6.dp, top = 8.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f).padding(end = 8.dp)) {
                        Text(
                            state.title,
                            maxLines = 1,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.basicMarquee(),
                        )
                        Text(
                            state.artist,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.8f),
                        )
                    }
                    BouncyIconButton(onClick = { vm.togglePlay() }) {
                        Box(
                            Modifier.size(38.dp).border(2.dp, Color.White, CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            AnimatedPlayIcon(state.isPlaying, Modifier.size(22.dp))
                        }
                    }
                    BouncyIconButton(onClick = { vm.next() }) { Icon(Icons.Rounded.SkipNext, "Próxima") }
                }
                LinearProgressIndicator(
                    progress = {
                        if (state.durationMs > 0) (position.toFloat() / state.durationMs).coerceIn(0f, 1f) else 0f
                    },
                    modifier = Modifier.fillMaxWidth().padding(start = 58.dp, end = 24.dp, bottom = 6.dp).height(2.dp),
                    color = Color.White,
                    trackColor = Color.White.copy(alpha = 0.25f),
                    drawStopIndicator = {},
                )
            }
        }
        // Disquinho girando, saindo um pouco para fora do mini player
        VinylArt(
            state.artUri,
            state.isPlaying,
            Modifier.size(62.dp).align(Alignment.CenterStart),
        )
    }
}

// ---------------- Tela "Tocando agora" ----------------

private data class TrackKey(val id: String?, val artUri: Uri?, val index: Int)

@Composable
fun NowPlayingScreen(vm: MainViewModel, onClose: () -> Unit) {
    val s by vm.player.collectAsStateWithLifecycle()
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val playlists by vm.playlistStore.playlists.collectAsStateWithLifecycle()
    val sleepEnd by vm.sleepTimerEnd.collectAsStateWithLifecycle()
    val sleepAtEnd by vm.sleepAtEnd.collectAsStateWithLifecycle()
    val songId = s.mediaId?.toLongOrNull()
    val isFavorite = songId != null &&
        playlists.firstOrNull { it.id == FAVORITES_ID }?.songIds?.contains(songId) == true

    var showQueue by remember { mutableStateOf(false) }
    var showSpeed by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    var showAddToPlaylist by remember { mutableStateOf(false) }
    var showLyrics by rememberSaveable { mutableStateOf(false) }
    var showMore by remember { mutableStateOf(false) }
    var showEq by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    // Deslizar para baixo fecha o player
    val dragY = remember { Animatable(0f) }
    // Deslizar a capa para o lado troca de música
    val dragX = remember { Animatable(0f) }

    if (!s.hasMedia) {
        LaunchedEffect(Unit) { onClose() }
        return
    }

    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(10_000)
        }
    }

    // Cores da capa, com transição suave entre músicas.
    // No tema Preto (sem papel de parede) o player também fica todo preto.
    val allBlack = settings.themeId == AppThemeId.BLACK && settings.wallpaperPath == null
    val fromArt = rememberArtColors(s.artUri, MaterialTheme.colorScheme.primary)
    val artColors = if (allBlack) ArtColors(Color.Black, MaterialTheme.colorScheme.primary) else fromArt
    val bgColor by animateColorAsState(artColors.background, tween(900), label = "bg")
    val accent by animateColorAsState(artColors.accent, tween(900), label = "accent")

    // Barras que dançam
    val context = LocalContext.current
    var micGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        micGranted = it
    }
    val sessionId by AudioEffects.sessionIdFlow.collectAsStateWithLifecycle()
    val showBars = settings.visualizer && micGranted
    DisposableEffect(showBars, sessionId) {
        if (showBars) AudioVisualizer.start(sessionId)
        onDispose { AudioVisualizer.stop() }
    }
    val levels by AudioVisualizer.levels.collectAsStateWithLifecycle()

    val playerScheme = darkColorScheme(
        primary = accent,
        onPrimary = if (accent.luminance() > 0.5f) Color.Black else Color.White,
        primaryContainer = accent.copy(alpha = 0.25f),
        onPrimaryContainer = Color.White,
        background = PlayerBottomColor,
        surface = Color(0xFF17181D),
        surfaceContainerLow = Color(0xFF17181D),
        surfaceContainerHigh = Color(0xFF202128),
    )

    MaterialTheme(colorScheme = playerScheme) {
        val bottomColor = if (allBlack) Color.Black else PlayerBottomColor
        Surface(
            Modifier
                .fillMaxSize()
                .graphicsLayer { translationY = dragY.value }
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragEnd = {
                            scope.launch {
                                if (dragY.value > size.height * 0.18f) onClose() else dragY.animateTo(0f)
                            }
                        },
                        onDragCancel = { scope.launch { dragY.animateTo(0f) } },
                    ) { change, amount ->
                        change.consume()
                        scope.launch { dragY.snapTo((dragY.value + amount).coerceAtLeast(0f)) }
                    }
                },
            color = bottomColor,
            contentColor = Color.White,
            shape = RoundedCornerShape(topStart = if (dragY.value > 0f) 28.dp else 0.dp, topEnd = if (dragY.value > 0f) 28.dp else 0.dp),
        ) {
        Box(Modifier.fillMaxSize()) {
            if (settings.animatedPlayerBg && !allBlack) {
                AnimatedArtBackground(s.artUri, bgColor, bottomColor)
            } else {
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(bgColor, bottomColor))))
            }
            Column(
                Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    BouncyIconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Fechar", tint = Color.White) }
                    Text(
                        "Tocando agora",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                    )
                    BouncyIconButton(onClick = { showQueue = true }) {
                        Icon(Icons.AutoMirrored.Rounded.QueueMusic, "Fila", tint = Color.White)
                    }
                    Box {
                        BouncyIconButton(onClick = { showMore = true }) {
                            Icon(Icons.Rounded.MoreVert, "Mais opções", tint = Color.White)
                        }
                        DropdownMenu(expanded = showMore, onDismissRequest = { showMore = false }) {
                            DropdownMenuItem(
                                leadingIcon = { Icon(Icons.Rounded.Equalizer, null) },
                                text = { Text("Equalizador") },
                                onClick = { showMore = false; showEq = true },
                            )
                            DropdownMenuItem(
                                leadingIcon = { Icon(Icons.Rounded.SmartDisplay, null) },
                                text = { Text("Abrir no YouTube") },
                                onClick = { showMore = false; openInYouTube(context, s.title, s.artist) },
                            )
                            DropdownMenuItem(
                                leadingIcon = { Icon(Icons.Rounded.MusicNote, null) },
                                text = { Text("Abrir no YouTube Music") },
                                onClick = { showMore = false; openInYouTubeMusic(context, s.title, s.artist) },
                            )
                        }
                    }
                }

                if (showLyrics) {
                    Spacer(Modifier.height(8.dp))
                    LyricsPanel(vm, s.mediaId, accent, Modifier.fillMaxWidth().weight(1.6f))
                } else {
                Spacer(Modifier.weight(0.4f))

                // Capa: desliza para o lado ao trocar de música (ou arraste com o dedo)
                AnimatedContent(
                    targetState = TrackKey(s.mediaId, s.artUri, s.queueIndex),
                    contentKey = { it.id },
                    transitionSpec = {
                        val forward = targetState.index >= initialState.index
                        val dir = if (forward) 1 else -1
                        (slideInHorizontally(tween(450)) { w -> dir * w } + fadeIn(tween(450)))
                            .togetherWith(slideOutHorizontally(tween(450)) { w -> -dir * w } + fadeOut(tween(300)))
                            .using(SizeTransform(clip = false))
                    },
                    label = "art",
                    modifier = Modifier
                        .fillMaxWidth()
                        .graphicsLayer {
                            translationX = dragX.value
                            rotationZ = dragX.value / 60f
                        }
                        .pointerInput(Unit) {
                            detectHorizontalDragGestures(
                                onDragEnd = {
                                    val dx = dragX.value
                                    scope.launch {
                                        when {
                                            dx < -size.width * 0.22f -> { vm.next(); dragX.snapTo(0f) }
                                            dx > size.width * 0.22f -> { vm.previous(); dragX.snapTo(0f) }
                                            else -> dragX.animateTo(0f)
                                        }
                                    }
                                },
                                onDragCancel = { scope.launch { dragX.animateTo(0f) } },
                            ) { change, amount ->
                                change.consume()
                                scope.launch { dragX.snapTo(dragX.value + amount) }
                            }
                        },
                ) { key ->
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        if (settings.vinylArt) {
                            VinylArt(key.artUri, s.isPlaying, Modifier.fillMaxWidth(0.92f))
                        } else {
                            BreathingArt(key.artUri, s.isPlaying, Modifier.fillMaxWidth())
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))

                when {
                    showBars -> VisualizerBars(levels, accent)
                    settings.visualizer -> TextButton(onClick = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }) {
                        Icon(Icons.Rounded.GraphicEq, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Ativar barras que dançam")
                    }
                    else -> Spacer(Modifier.height(56.dp))
                }
                }

                Spacer(Modifier.height(12.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    AnimatedContent(
                        targetState = Pair(s.title, s.artist to s.album),
                        transitionSpec = {
                            (slideInVertically { it / 2 } + fadeIn()) togetherWith (slideOutVertically { -it / 2 } + fadeOut())
                        },
                        label = "titles",
                        modifier = Modifier.weight(1f),
                    ) { (title, sub) ->
                        Column {
                            Text(
                                title,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1,
                                modifier = Modifier.basicMarquee(),
                            )
                            Text(
                                listOf(sub.first, sub.second).filter { it.isNotBlank() }.joinToString(" • "),
                                color = Color.White.copy(alpha = 0.7f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                    BouncyIconButton(onClick = { songId?.let { vm.toggleFavorite(it) } }) {
                        val heartScale by animateFloatAsState(
                            if (isFavorite) 1.15f else 1f,
                            spring(dampingRatio = Spring.DampingRatioHighBouncy),
                            label = "heart",
                        )
                        Icon(
                            if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                            "Favorita",
                            tint = if (isFavorite) accent else Color.White,
                            modifier = Modifier.scale(heartScale),
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))
                SeekBar(vm, s.durationMs)
                Spacer(Modifier.height(4.dp))

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    val inactive = Color.White.copy(alpha = 0.6f)
                    PlayModeButton(
                        current = currentPlayMode(s),
                        accent = accent,
                        onSelect = { vm.setPlayMode(it) },
                    )
                    BouncyIconButton(onClick = { vm.previous() }, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Rounded.SkipPrevious, "Anterior", Modifier.size(36.dp), tint = Color.White)
                    }
                    BouncyIconButton(onClick = { vm.togglePlay() }, filled = true, modifier = Modifier.size(76.dp)) {
                        AnimatedPlayIcon(s.isPlaying, Modifier.size(40.dp))
                    }
                    BouncyIconButton(onClick = { vm.next() }, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Rounded.SkipNext, "Próxima", Modifier.size(36.dp), tint = Color.White)
                    }
                    BouncyIconButton(onClick = { vm.cycleRepeat() }) {
                        Icon(
                            if (s.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                            "Repetir",
                            tint = if (s.repeatMode == Player.REPEAT_MODE_OFF) inactive else accent,
                        )
                    }
                }

                Spacer(Modifier.weight(1f))

                Row(
                    Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    val end = sleepEnd
                    PlayerToolButton(Icons.Rounded.Speed, formatSpeed(s.speed), active = s.speed != 1f, accent) { showSpeed = true }
                    PlayerToolButton(
                        Icons.Rounded.Timer,
                        when {
                            sleepAtEnd -> "Fim da música"
                            end == null -> "Timer"
                            else -> "${((end - now) / 60_000 + 1).coerceAtLeast(1)} min"
                        },
                        active = end != null || sleepAtEnd,
                        accent,
                    ) { showSleep = true }
                    PlayerToolButton(Icons.Rounded.Subtitles, "Letra", active = showLyrics, accent) { showLyrics = !showLyrics }
                    PlayerToolButton(Icons.AutoMirrored.Rounded.PlaylistAdd, "Playlist", active = false, accent) { showAddToPlaylist = true }
                }
            }
        }
        }

        if (showQueue) QueueSheet(s, vm) { showQueue = false }
        if (showEq) {
            ModalBottomSheet(onDismissRequest = { showEq = false }) {
                Box(Modifier.fillMaxWidth().fillMaxHeight(0.85f)) { EqualizerScreen() }
            }
        }
        if (showSpeed) SpeedDialog(s.speed, onSelect = { vm.setSpeed(it); showSpeed = false }) { showSpeed = false }
        if (showSleep) {
            SleepDialog(
                active = sleepEnd != null,
                atEnd = sleepAtEnd,
                onSelect = { value ->
                    when (value) {
                        null -> { vm.setSleepTimer(null); vm.setSleepAtEnd(false) }
                        -1 -> vm.setSleepAtEnd(true)
                        else -> vm.setSleepTimer(value)
                    }
                    showSleep = false
                },
            ) { showSleep = false }
        }
        if (showAddToPlaylist && songId != null) AddToPlaylistDialog(vm, listOf(songId)) { showAddToPlaylist = false }
    }
}

@Composable
private fun SeekBar(vm: MainViewModel, durationMs: Long) {
    val position by rememberPlaybackPosition(vm)
    var dragging by remember { mutableStateOf<Float?>(null) }
    val duration = durationMs.coerceAtLeast(1)
    val fraction = dragging ?: (position.toFloat() / duration).coerceIn(0f, 1f)

    Column(Modifier.fillMaxWidth()) {
        Slider(
            value = fraction,
            onValueChange = { dragging = it },
            onValueChangeFinished = {
                dragging?.let { vm.seekTo((it * duration).toLong()) }
                dragging = null
            },
        )
        Row(Modifier.fillMaxWidth()) {
            Text(
                formatTime(if (dragging != null) (fraction * duration).toLong() else position),
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.weight(1f),
            )
            Text(formatTime(durationMs), style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun QueueSheet(s: PlayerUiState, vm: MainViewModel, onDismiss: () -> Unit) {
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = s.queueIndex.coerceAtLeast(0))
    var dragging by remember { mutableStateOf<Int?>(null) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    var saving by remember { mutableStateOf(false) }
    val context = LocalContext.current

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Row(
            Modifier.fillMaxWidth().padding(start = 24.dp, end = 12.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Fila de reprodução (${s.queue.size})",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = { saving = true }, enabled = s.queue.isNotEmpty()) {
                Icon(Icons.Rounded.Save, null, Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Salvar como playlist")
            }
        }
        Text(
            "Segure e arraste pela alça ⋮⋮ para mudar a ordem",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 24.dp),
        )
        LazyColumn(state = listState, modifier = Modifier.fillMaxWidth()) {
            itemsIndexed(s.queue, key = { i, item -> "${item.mediaId}_$i" }) { i, item ->
                val current = i == s.queueIndex
                val isDragged = dragging == i
                ListItem(
                    colors = ListItemDefaults.colors(
                        containerColor = when {
                            isDragged -> MaterialTheme.colorScheme.surfaceContainerHighest
                            current -> MaterialTheme.colorScheme.primaryContainer
                            else -> Color.Transparent
                        },
                    ),
                    headlineContent = {
                        Text(
                            item.mediaMetadata.title?.toString() ?: "",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontWeight = if (current) FontWeight.Bold else null,
                        )
                    },
                    supportingContent = {
                        Text(item.mediaMetadata.artist?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    },
                    leadingContent = { ArtImage(item.mediaMetadata.artworkUri, Modifier.size(40.dp)) },
                    trailingContent = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (!current) {
                                IconButton(onClick = { vm.removeFromQueue(i) }) { Icon(Icons.Rounded.Close, "Remover da fila") }
                            }
                            // Alça de arrastar
                            Icon(
                                Icons.Rounded.DragIndicator,
                                "Arrastar",
                                modifier = Modifier
                                    .size(40.dp)
                                    .padding(8.dp)
                                    .pointerInput(i, s.queue.size) {
                                        detectDragGestures(
                                            onDragStart = { dragging = i; dragOffset = 0f },
                                            onDragEnd = {
                                                val info = listState.layoutInfo.visibleItemsInfo
                                                val me = info.firstOrNull { it.index == i }
                                                if (me != null) {
                                                    val center = me.offset + me.size / 2 + dragOffset
                                                    val target = info.firstOrNull {
                                                        center >= it.offset && center < it.offset + it.size
                                                    }?.index ?: if (dragOffset > 0) info.last().index else info.first().index
                                                    vm.moveQueueItem(i, target.coerceIn(0, s.queue.size - 1))
                                                }
                                                dragging = null
                                                dragOffset = 0f
                                            },
                                            onDragCancel = { dragging = null; dragOffset = 0f },
                                        ) { change, amount ->
                                            change.consume()
                                            dragOffset += amount.y
                                        }
                                    },
                            )
                        }
                    },
                    modifier = Modifier
                        .zIndex(if (isDragged) 1f else 0f)
                        .graphicsLayer {
                            if (isDragged) {
                                translationY = dragOffset
                                shadowElevation = 12f
                            }
                        }
                        .clickable { vm.playQueueIndex(i) },
                )
            }
        }
    }

    if (saving) {
        NameDialog(
            title = "Salvar fila como playlist",
            initial = "",
            confirmLabel = "Salvar",
            onConfirm = { name ->
                vm.saveQueueAsPlaylist(name)
                saving = false
                Toast.makeText(context, "Playlist \"$name\" criada", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { saving = false },
        )
    }
}

@Composable
private fun SpeedDialog(current: Float, onSelect: (Float) -> Unit, onDismiss: () -> Unit) {
    val options = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
    OptionsDialog("Velocidade", options.map { formatSpeed(it) }, options.indexOf(current), { onSelect(options[it]) }, onDismiss)
}

@Composable
private fun SleepDialog(active: Boolean, atEnd: Boolean, onSelect: (Int?) -> Unit, onDismiss: () -> Unit) {
    // -1 = no fim desta música
    val minutes = listOf<Int?>(null, -1, 5, 10, 15, 30, 45, 60, 90)
    val labels = minutes.map {
        when (it) {
            null -> "Desligado"
            -1 -> "No fim desta música"
            else -> "$it minutos"
        }
    }
    OptionsDialog(
        "Parar a música depois de",
        labels,
        when {
            atEnd -> 1
            active -> -1
            else -> 0
        },
        { onSelect(minutes[it]) },
        onDismiss,
    )
}

@Composable
private fun OptionsDialog(
    title: String,
    labels: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                labels.forEachIndexed { i, label ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onSelect(i) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = i == selected, onClick = { onSelect(i) })
                        Text(label)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fechar") } },
    )
}


// ---------------- Modo de reprodução ----------------

fun currentPlayMode(s: PlayerUiState): PlayMode = when {
    s.repeatMode == Player.REPEAT_MODE_ONE -> PlayMode.ONE
    s.shuffle -> PlayMode.SHUFFLE
    s.repeatMode == Player.REPEAT_MODE_ALL -> PlayMode.ALL
    else -> PlayMode.ORDER
}

private fun PlayMode.icon(): ImageVector = when (this) {
    PlayMode.ONE -> Icons.Rounded.RepeatOne
    PlayMode.SHUFFLE -> Icons.Rounded.Shuffle
    PlayMode.ALL -> Icons.Rounded.Repeat
    PlayMode.ORDER -> Icons.AutoMirrored.Rounded.ArrowForward
}

/** Botão da esquerda: ao tocar, abre o menu com os modos de reprodução. */
@Composable
private fun PlayModeButton(current: PlayMode, accent: Color, onSelect: (PlayMode) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val active = current != PlayMode.ORDER
    val bg by animateColorAsState(
        if (active) accent.copy(alpha = 0.22f) else Color.Transparent,
        label = "modeBg",
    )
    Box {
        BouncyIconButton(
            onClick = { open = true },
            modifier = Modifier.clip(CircleShape).background(bg),
        ) {
            Crossfade(targetState = current, label = "modeIcon") { mode ->
                Icon(
                    mode.icon(),
                    "Modo de reprodução: ${mode.label}",
                    tint = if (active) accent else Color.White.copy(alpha = 0.6f),
                )
            }
        }
        DropdownMenu(
            expanded = open,
            onDismissRequest = { open = false },
            shape = RoundedCornerShape(16.dp),
        ) {
            Text(
                "Modo de reprodução",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            )
            listOf(PlayMode.ONE, PlayMode.SHUFFLE, PlayMode.ALL, PlayMode.ORDER).forEach { mode ->
                val selected = mode == current
                DropdownMenuItem(
                    leadingIcon = { Icon(mode.icon(), null, tint = if (selected) accent else MaterialTheme.colorScheme.onSurface) },
                    text = {
                        Text(
                            mode.label,
                            color = if (selected) accent else MaterialTheme.colorScheme.onSurface,
                            fontWeight = if (selected) FontWeight.SemiBold else null,
                        )
                    },
                    trailingIcon = { if (selected) Icon(Icons.Rounded.Check, null, tint = accent) },
                    onClick = {
                        onSelect(mode)
                        open = false
                    },
                    modifier = if (selected) Modifier.background(accent.copy(alpha = 0.15f)) else Modifier,
                )
            }
        }
    }
}

@Composable
private fun PlayerToolButton(
    icon: ImageVector,
    label: String,
    active: Boolean,
    accent: Color,
    onClick: () -> Unit,
) {
    val tint = if (active) accent else Color.White.copy(alpha = 0.75f)
    Column(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(22.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = tint, maxLines = 1)
    }
}
