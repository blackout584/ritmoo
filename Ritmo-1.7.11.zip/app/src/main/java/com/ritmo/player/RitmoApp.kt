package com.ritmo.player

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.memory.MemoryCache
import com.ritmo.player.update.RitmoMessagingService
import com.ritmo.player.update.UpdateCheckWorker

/** Configura o carregamento de capas: transição suave e um cache em memória do tamanho certo. */
class RitmoApp : Application(), ImageLoaderFactory {

    override fun onCreate() {
        super.onCreate()
        // Avisos de versão nova: conferência a cada 15 minutos + aviso instantâneo (Firebase, se configurado)
        runCatching { UpdateCheckWorker.schedule(this) }
        RitmoMessagingService.subscribe()
    }

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .crossfade(true)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.20)
                    .build()
            }
            .respectCacheHeaders(false)
            .build()
}
