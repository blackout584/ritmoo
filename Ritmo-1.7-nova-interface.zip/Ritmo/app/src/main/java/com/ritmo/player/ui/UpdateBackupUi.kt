package com.ritmo.player.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.SystemUpdate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.data.Backup
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Cartão de atualização. [compact] = só aparece quando tem novidade (usado na tela Início). */
@Composable
fun UpdateCard(vm: MainViewModel, compact: Boolean = false) {
    val state by vm.update.collectAsStateWithLifecycle()
    var needsPermission by remember { mutableStateOf(false) }

    if (compact && state !is UpdateUi.Available && state !is UpdateUi.Downloading && state !is UpdateUi.Ready) return

    Surface(
        color = MaterialTheme.colorScheme.primaryContainer,
        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.SystemUpdate, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        when (val s = state) {
                            is UpdateUi.Available -> "Nova versão disponível"
                            is UpdateUi.Downloading -> "Baixando atualização..."
                            UpdateUi.Ready -> "Atualização baixada"
                            UpdateUi.Checking -> "Procurando..."
                            UpdateUi.UpToDate -> "Você já tem a versão mais nova"
                            is UpdateUi.Error -> s.message
                            UpdateUi.Idle -> "Atualizações"
                        },
                        fontWeight = FontWeight.SemiBold,
                    )
                    (state as? UpdateUi.Available)?.let {
                        Text(it.info.name, style = MaterialTheme.typography.bodySmall)
                    }
                }
                if (state == UpdateUi.Checking) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            }
            Spacer(Modifier.height(10.dp))
            when (val s = state) {
                is UpdateUi.Available -> Button(onClick = { vm.downloadUpdate() }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Download, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Baixar e instalar")
                }
                is UpdateUi.Downloading -> {
                    LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth())
                    Text("${(s.progress * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
                }
                UpdateUi.Ready -> Button(
                    onClick = { needsPermission = !vm.installUpdate() },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Instalar agora") }
                else -> OutlinedButton(
                    onClick = { vm.checkForUpdate(manual = true) },
                    enabled = state != UpdateUi.Checking,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Procurar atualização") }
            }
            if (needsPermission) {
                Spacer(Modifier.height(6.dp))
                Text(
                    "Permita que o Ritmo instale apps na tela que abriu, volte aqui e toque em \"Instalar agora\".",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}

@Composable
fun UpdateSettings(vm: MainViewModel) {
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    UpdateCard(vm)
    ListItem(
        headlineContent = { Text("Avisar quando sair versão nova") },
        supportingContent = { Text("Confere sozinho, no máximo duas vezes por dia") },
        trailingContent = {
            Switch(
                checked = settings.autoUpdateCheck,
                onCheckedChange = { on -> vm.settingsStore.update { it.copy(autoUpdateCheck = on) } },
            )
        },
    )
}

/** Salvar e restaurar o backup. */
@Composable
fun BackupSection() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("backup_meta", android.content.Context.MODE_PRIVATE) }
    var last by remember { mutableStateOf(prefs.getLong("last", 0L)) }
    var pendingRestore by remember { mutableStateOf<android.net.Uri?>(null) }
    var working by remember { mutableStateOf(false) }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            working = true
            scope.launch {
                val ok = Backup.export(context, uri)
                working = false
                if (ok) {
                    last = System.currentTimeMillis()
                    prefs.edit().putLong("last", last).apply()
                }
                Toast.makeText(context, if (ok) "Backup salvo" else "Não deu para salvar o backup", Toast.LENGTH_SHORT).show()
            }
        }
    }
    val opener = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pendingRestore = uri
    }

    val dateText = remember(last) {
        if (last == 0L) "Nenhum backup ainda"
        else "Último: " + SimpleDateFormat("dd/MM 'às' HH:mm", Locale("pt", "BR")).format(Date(last))
    }
    ListItem(
        modifier = Modifier.clickable(enabled = !working) {
            val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            saver.launch("Ritmo-backup-$day.zip")
        },
        leadingContent = { Icon(Icons.Rounded.CloudUpload, null, tint = MaterialTheme.colorScheme.primary) },
        headlineContent = { Text("Salvar backup") },
        supportingContent = { Text(dateText) },
        trailingContent = { if (working) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) },
    )
    ListItem(
        modifier = Modifier.clickable(enabled = !working) { opener.launch(arrayOf("application/zip", "*/*")) },
        leadingContent = { Icon(Icons.Rounded.Restore, null, tint = MaterialTheme.colorScheme.primary) },
        headlineContent = { Text("Restaurar backup") },
        supportingContent = { Text("Escolher um arquivo salvo") },
    )
    Text(
        "Guarda playlists, favoritas, notas, edições, letras, temas, papel de parede e estatísticas. " +
            "Em outro celular, as playlists podem não achar todas as músicas.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 16.dp),
    )

    pendingRestore?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            title = { Text("Restaurar backup?") },
            text = { Text("Suas configurações atuais serão trocadas pelas do backup e o Ritmo vai reiniciar.") },
            confirmButton = {
                TextButton(onClick = {
                    pendingRestore = null
                    working = true
                    scope.launch {
                        val ok = Backup.import(context, uri)
                        if (ok) {
                            Toast.makeText(context, "Backup restaurado. Reiniciando...", Toast.LENGTH_SHORT).show()
                            Backup.restartApp(context)
                        } else {
                            working = false
                            Toast.makeText(context, "Esse arquivo não é um backup do Ritmo", Toast.LENGTH_SHORT).show()
                        }
                    }
                }) { Text("Restaurar") }
            },
            dismissButton = { TextButton(onClick = { pendingRestore = null }) { Text("Cancelar") } },
        )
    }
}
