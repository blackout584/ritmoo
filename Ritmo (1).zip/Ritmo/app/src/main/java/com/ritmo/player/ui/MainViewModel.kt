package com.ritmo.player.ui

import android.app.Application
import android.content.ComponentName
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.ritmo.player.data.MusicRepository
import com.ritmo.player.data.PlaylistStore
import com.ritmo.player.data.SettingsStore
import com.ritmo.player.data.Song
import com.ritmo.player.data.toMediaItem
import com.ritmo.player.playback.PlaybackService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

data class PlayerUiState(
    val hasMedia: Boolean = false,
    val mediaId: String? = null,
    val title: String = "",
    val artist: String = "",
    val album: String = "",
    val artUri: Uri? = null,
    val isPlaying: Boolean = false,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val durationMs: Long = 0,
    val speed: Float = 1f,
    val queue: List<MediaItem> = emptyList(),
    val queueIndex: Int = -1,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = MusicRepository(app)
    val playlistStore = PlaylistStore(app)
    val settingsStore = SettingsStore(app)

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()
    private var loaded = false

    private val _player = MutableStateFlow(PlayerUiState())
    val player: StateFlow<PlayerUiState> = _player.asStateFlow()

    private val _sleepTimerEnd = MutableStateFlow<Long?>(null)
    val sleepTimerEnd: StateFlow<Long?> = _sleepTimerEnd.asStateFlow()
    private var sleepJob: Job? = null

    private var controller: MediaController? = null

    init {
        connectToService()
    }

    // ---------- Biblioteca ----------

    fun loadLibrary(force: Boolean = false) {
        if (loaded && !force) return
        loaded = true
        viewModelScope.launch {
            _loading.value = true
            _songs.value = runCatching {
                repo.loadSongs(settingsStore.settings.value.minDurationSec)
            }.getOrDefault(emptyList())
            _loading.value = false
        }
    }

    fun setMinDuration(seconds: Int) {
        settingsStore.update { it.copy(minDurationSec = seconds) }
        loadLibrary(force = true)
    }

    // ---------- Conexão com o serviço de reprodução ----------

    private fun connectToService() {
        val ctx = getApplication<Application>()
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            val c = runCatching { future.get() }.getOrNull() ?: return@addListener
            controller = c
            c.addListener(object : Player.Listener {
                override fun onEvents(player: Player, events: Player.Events) {
                    refresh(includeQueue = events.contains(Player.EVENT_TIMELINE_CHANGED))
                }
            })
            refresh(includeQueue = true)
        }, ContextCompat.getMainExecutor(ctx))
    }

    private fun refresh(includeQueue: Boolean) {
        val c = controller ?: return
        val item = c.currentMediaItem
        val md = c.mediaMetadata
        val old = _player.value
        _player.value = PlayerUiState(
            hasMedia = item != null,
            mediaId = item?.mediaId,
            title = md.title?.toString() ?: "",
            artist = md.artist?.toString() ?: "",
            album = md.albumTitle?.toString() ?: "",
            artUri = md.artworkUri,
            isPlaying = c.isPlaying,
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
            durationMs = c.duration.coerceAtLeast(0),
            speed = c.playbackParameters.speed,
            queue = if (includeQueue) (0 until c.mediaItemCount).map { c.getMediaItemAt(it) } else old.queue,
            queueIndex = c.currentMediaItemIndex,
        )
    }

    fun positionMs(): Long = controller?.currentPosition ?: 0L

    // ---------- Controles ----------

    fun playSongs(list: List<Song>, startIndex: Int, shuffle: Boolean = false) {
        val c = controller ?: return
        if (list.isEmpty()) return
        c.setMediaItems(list.map { it.toMediaItem() }, startIndex, 0L)
        c.shuffleModeEnabled = shuffle
        c.prepare()
        c.play()
    }

    fun shuffleAll(list: List<Song>) {
        if (list.isEmpty()) return
        playSongs(list, Random.nextInt(list.size), shuffle = true)
    }

    fun playNext(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            playSongs(listOf(song), 0)
        } else {
            c.addMediaItem(c.currentMediaItemIndex + 1, song.toMediaItem())
        }
    }

    fun addToQueue(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) playSongs(listOf(song), 0) else c.addMediaItem(song.toMediaItem())
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) {
            c.pause()
        } else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            if (c.playbackState == Player.STATE_ENDED) c.seekToDefaultPosition()
            c.play()
        }
    }

    fun next() { controller?.seekToNext() }
    fun previous() { controller?.seekToPrevious() }
    fun seekTo(ms: Long) { controller?.seekTo(ms) }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun setSpeed(speed: Float) {
        controller?.playbackParameters = PlaybackParameters(speed)
    }

    fun playQueueIndex(index: Int) {
        controller?.let { it.seekTo(index, 0L); it.play() }
    }

    fun removeFromQueue(index: Int) {
        controller?.removeMediaItem(index)
    }

    fun toggleFavorite(songId: Long) = playlistStore.toggleFavorite(songId)

    // ---------- Timer para dormir ----------

    fun setSleepTimer(minutes: Int?) {
        sleepJob?.cancel()
        if (minutes == null) {
            _sleepTimerEnd.value = null
            return
        }
        val durationMs = minutes * 60_000L
        _sleepTimerEnd.value = System.currentTimeMillis() + durationMs
        sleepJob = viewModelScope.launch {
            delay(durationMs)
            controller?.pause()
            _sleepTimerEnd.value = null
        }
    }

    override fun onCleared() {
        controller?.release()
        controller = null
        super.onCleared()
    }
}
