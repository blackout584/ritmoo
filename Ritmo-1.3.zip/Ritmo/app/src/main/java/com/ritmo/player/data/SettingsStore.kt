package com.ritmo.player.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode { SYSTEM, LIGHT, DARK }

enum class AppThemeId(val label: String) {
    DEFAULT("Padrão"),
    MIDNIGHT("Meia-noite"),
    NEON("Neon"),
    SUNSET("Pôr do sol"),
    OCEAN("Oceano"),
    FOREST("Floresta"),
}

enum class PlayMode(val label: String) {
    ONE("Repetir esta música"),
    SHUFFLE("Aleatório"),
    ALL("Repetir tudo"),
    ORDER("Tocar em ordem"),
}

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accent: Int = 0,
    val dynamicColor: Boolean = true,
    val minDurationSec: Int = 10,
    val vinylArt: Boolean = true,
    val visualizer: Boolean = true,
    val songSort: SongSort = SongSort.TITLE_ASC,
    val themeId: AppThemeId = AppThemeId.DEFAULT,
    val wallpaperPath: String? = null,
    val wallpaperDim: Float = 0.55f,
    val wallpaperBlur: Float = 0f,
    val playMode: PlayMode = PlayMode.ORDER,
)

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    fun update(transform: (AppSettings) -> AppSettings) {
        val s = transform(_settings.value)
        prefs.edit()
            .putString("theme", s.themeMode.name)
            .putInt("accent", s.accent)
            .putBoolean("dynamic", s.dynamicColor)
            .putInt("minDuration", s.minDurationSec)
            .putBoolean("vinyl", s.vinylArt)
            .putBoolean("visualizer", s.visualizer)
            .putString("songSort", s.songSort.name)
            .putString("themeId", s.themeId.name)
            .putString("wallpaperPath", s.wallpaperPath)
            .putFloat("wallpaperDim", s.wallpaperDim)
            .putFloat("wallpaperBlur", s.wallpaperBlur)
            .putString("playMode", s.playMode.name)
            .apply()
        _settings.value = s
    }

    private inline fun <reified E : Enum<E>> enumPref(key: String, default: E): E =
        runCatching { enumValueOf<E>(prefs.getString(key, null) ?: default.name) }.getOrDefault(default)

    private fun load() = AppSettings(
        themeMode = enumPref("theme", ThemeMode.SYSTEM),
        accent = prefs.getInt("accent", 0),
        dynamicColor = prefs.getBoolean("dynamic", true),
        minDurationSec = prefs.getInt("minDuration", 10),
        vinylArt = prefs.getBoolean("vinyl", true),
        visualizer = prefs.getBoolean("visualizer", true),
        songSort = enumPref("songSort", SongSort.TITLE_ASC),
        themeId = enumPref("themeId", AppThemeId.DEFAULT),
        wallpaperPath = prefs.getString("wallpaperPath", null),
        wallpaperDim = prefs.getFloat("wallpaperDim", 0.55f),
        wallpaperBlur = prefs.getFloat("wallpaperBlur", 0f),
        playMode = enumPref("playMode", PlayMode.ORDER),
    )
}
