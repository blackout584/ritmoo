package com.ritmo.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.data.Song
import java.text.Normalizer

private fun normalizeKey(s: String): String =
    Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .replace(Regex("[^a-z0-9]"), "")

/** Grupos da mesma música: nome e artista iguais (sem acento/maiúscula) e duração com até 3 s de diferença. */
fun findDuplicateGroups(songs: List<Song>): List<List<Song>> =
    songs.groupBy { normalizeKey(it.title) + "|" + normalizeKey(it.artist) }
        .values
        .filter { it.size > 1 }
        .flatMap { same ->
            val clusters = mutableListOf<MutableList<Song>>()
            same.sortedBy { it.durationMs }.forEach { s ->
                val last = clusters.lastOrNull()
                if (last != null && s.durationMs - last.first().durationMs <= 3_000) last += s
                else clusters += mutableListOf(s)
            }
            clusters
        }
        .filter { it.size > 1 }

@Composable
fun DuplicatesScreen(vm: MainViewModel, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val songs by vm.songs.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val actions = rememberMediaActions(vm)
    val groups = remember(songs) { findDuplicateGroups(songs) }
    // Qualidade e tamanho de cada cópia (lido do arquivo)
    val info by produceState<Map<Long, FileInfo>?>(null, groups) {
        value = groups.flatten().associate { it.id to readFileInfo(context, it) }
    }
    val selected = remember { mutableStateMapOf<Long, Boolean>() }
    val keepers = remember(groups, info) {
        val i = info ?: return@remember emptyMap<Int, Long>()
        groups.mapIndexed { gi, g ->
            gi to g.maxWith(compareBy<Song>({ i[it.id]?.bitrateKbps ?: 0 }, { i[it.id]?.sizeBytes ?: 0L })).id
        }.toMap()
    }
    // Já marca para apagar as cópias que não são a melhor
    LaunchedEffect(keepers) {
        if (keepers.isNotEmpty() && selected.isEmpty()) {
            groups.forEachIndexed { gi, g -> g.forEach { s -> selected[s.id] = s.id != keepers[gi] } }
        }
    }
    val toDelete = groups.flatten().filter { selected[it.id] == true }
    val freeBytes = toDelete.sumOf { info?.get(it.id)?.sizeBytes ?: 0L }

    Column(Modifier.fillMaxSize()) {
        SimpleTopBar("Músicas duplicadas", onBack = onBack)
        when {
            groups.isEmpty() -> Text(
                "Nenhuma música duplicada. Tudo em ordem! 🎉",
                modifier = Modifier.padding(24.dp),
            )
            info == null -> Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            else -> {
                Text(
                    "${groups.size} músicas com cópias" + if (freeBytes > 0) " · ${prettySize(freeBytes)} podem ser liberados" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    items(groups.size) { gi ->
                        val g = groups[gi]
                        Column(
                            Modifier
                                .padding(vertical = 6.dp)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                                .padding(10.dp)
                        ) {
                            Text(g.first().title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${g.first().artist} · ${g.size} cópias",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            g.forEach { s ->
                                val fi = info?.get(s.id)
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { selected[s.id] = selected[s.id] != true }
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Checkbox(checked = selected[s.id] == true, onCheckedChange = { selected[s.id] = it })
                                    ArtImage(s.artUri, Modifier.size(38.dp).clip(RoundedCornerShape(6.dp)), corner = 6.dp)
                                    Column(Modifier.weight(1f).padding(start = 10.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(s.folderName, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                                            if (keepers[gi] == s.id) {
                                                Text(
                                                    "manter",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                    modifier = Modifier
                                                        .padding(start = 6.dp)
                                                        .clip(RoundedCornerShape(50))
                                                        .background(MaterialTheme.colorScheme.primaryContainer)
                                                        .padding(horizontal = 6.dp, vertical = 1.dp),
                                                )
                                            }
                                        }
                                        Text(
                                            listOfNotNull(
                                                fi?.format,
                                                fi?.bitrateKbps?.takeIf { it > 0 }?.let { "$it kbps" },
                                                fi?.sizeBytes?.takeIf { it > 0 }?.let { prettySize(it) },
                                            ).joinToString(" · "),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                Button(
                    onClick = {
                        // Nas playlists, troca a cópia apagada pela que fica
                        groups.forEachIndexed { gi, g ->
                            val keep = g.firstOrNull { selected[it.id] != true }?.id ?: keepers[gi]
                            if (keep != null) g.filter { selected[it.id] == true && it.id != keep }
                                .forEach { vm.playlistStore.replaceSong(it.id, keep) }
                        }
                        actions.delete(toDelete)
                    },
                    enabled = toDelete.isNotEmpty(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                ) {
                    Icon(Icons.Rounded.Delete, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (toDelete.size == 1) "Apagar 1 cópia marcada" else "Apagar ${toDelete.size} cópias marcadas")
                }
                Spacer(Modifier.height(4.dp))
            }
        }
    }
}
