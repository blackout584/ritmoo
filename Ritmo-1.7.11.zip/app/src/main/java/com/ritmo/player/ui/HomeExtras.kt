package com.ritmo.player.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------------- Saudação ----------------

/** "Boa noite" + emoji, conforme a hora. */
fun greetingNow(): Pair<String, String> =
    when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
        in 5..11 -> "Bom dia" to "🌅"
        in 12..17 -> "Boa tarde" to "☀️"
        in 18..23 -> "Boa noite" to "🌙"
        else -> "Boa madrugada" to "✨"
    }

/** Pergunta (ou troca) o nome para a saudação. */
@Composable
fun AskNameDialog(initial: String, firstTime: Boolean, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Text("👋", fontSize = 28.sp) },
        title = {
            Text(
                if (firstTime) "Como você quer ser chamado?" else "Seu nome",
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        },
        text = {
            Column {
                Text(
                    "Para o Ritmo te dar bom dia",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { if (it.length <= 24) name = it },
                    singleLine = true,
                    placeholder = { Text("Seu nome") },
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            Button(onClick = { onSave(name.trim()) }) { Text("Salvar") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(if (firstTime) "Agora não" else "Cancelar") }
        },
    )
}

/** Linha da saudação no Início: "Boa noite, Blanck 🌙". Tocar troca o nome. */
@Composable
fun GreetingLine(vm: MainViewModel) {
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val (hello, emoji) = remember { greetingNow() }
    var editing by remember { mutableStateOf(false) }
    Row(
        Modifier.clip(RoundedCornerShape(8.dp)).clickable { editing = true },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            if (settings.userName.isBlank()) "$hello " else "$hello, ",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (settings.userName.isNotBlank()) {
            Text(
                settings.userName + " ",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
            )
        }
        Text(emoji, style = MaterialTheme.typography.bodySmall)
    }
    if (editing) {
        AskNameDialog(
            initial = settings.userName,
            firstTime = false,
            onSave = { n -> vm.settingsStore.update { it.copy(userName = n, askedName = true) }; editing = false },
            onDismiss = { editing = false },
        )
    }
}

// ---------------- Procurar músicas novas ----------------

@Composable
fun ScanCard(vm: MainViewModel, onOpen: (Detail) -> Unit) {
    val scan by vm.scan.collectAsStateWithLifecycle()
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val songs by vm.songs.collectAsStateWithLifecycle()
    val shape = RoundedCornerShape(14.dp)
    val accent = MaterialTheme.colorScheme.primary
    Column(
        Modifier
            .padding(horizontal = 14.dp, vertical = 4.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
            .animateContentSize()
    ) {
        when (val s = scan) {
            is ScanUi.Idle -> Row(
                Modifier.fillMaxWidth().clickable { vm.scanForNewMusic() }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Search, null, tint = accent)
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text("Procurar músicas novas", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                    Text(
                        (if (settings.lastScan > 0) "Última vez: ${whenText(settings.lastScan)} · " else "") + "${songs.size} músicas",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Icon(Icons.Rounded.ChevronRight, null)
            }
            is ScanUi.Scanning -> Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Search, null, tint = accent)
                    Text(
                        "Procurando músicas novas…",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f).padding(start = 12.dp),
                    )
                    Text("${(s.progress * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
                }
                LinearProgressIndicator(
                    progress = { s.progress },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                )
                if (s.folder.isNotBlank()) {
                    Text(
                        "Pasta: ${s.folder}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }
            is ScanUi.Done -> Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.CheckCircle, null, tint = accent)
                    Text(
                        when (s.newSongs.size) {
                            0 -> "Tudo em dia: nenhuma música nova"
                            1 -> "1 música nova encontrada"
                            else -> "${s.newSongs.size} músicas novas encontradas"
                        },
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(start = 12.dp),
                    )
                }
                s.newSongs.take(5).forEach { song ->
                    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        ArtImage(song.artUri, Modifier.size(32.dp).clip(RoundedCornerShape(6.dp)), corner = 6.dp)
                        Text(
                            song.title,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(start = 10.dp),
                        )
                    }
                }
                if (s.newSongs.size > 5) {
                    Text(
                        "+ ${s.newSongs.size - 5} músicas",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
                if (s.duplicates > 0) {
                    Text(
                        "${s.duplicates} ${if (s.duplicates == 1) "música duplicada" else "músicas duplicadas"} · Ver",
                        color = accent,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .padding(top = 8.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { vm.dismissScan(); onOpen(Detail.Duplicates) }
                            .padding(2.dp),
                    )
                }
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (s.newSongs.isNotEmpty()) {
                        TextButton(onClick = { vm.playSongs(s.newSongs, 0); vm.dismissScan() }) { Text("Tocar novas") }
                    }
                    TextButton(onClick = { vm.dismissScan() }) { Text("Fechar") }
                }
            }
        }
    }
}

private fun whenText(time: Long): String {
    val now = Calendar.getInstance()
    val then = Calendar.getInstance().apply { timeInMillis = time }
    val hour = SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date(time))
    return when {
        now.get(Calendar.YEAR) == then.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == then.get(Calendar.DAY_OF_YEAR) -> "hoje, $hour"
        now.get(Calendar.YEAR) == then.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) - then.get(Calendar.DAY_OF_YEAR) == 1 -> "ontem, $hour"
        else -> SimpleDateFormat("dd/MM", Locale("pt", "BR")).format(Date(time))
    }
}
