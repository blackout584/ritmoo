package com.ritmo.player.ui

import androidx.compose.material.icons.rounded.DragIndicator
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.zIndex
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.ritmo.player.data.AppSettings
import com.ritmo.player.data.AppThemeId
import com.ritmo.player.data.FontStyleId
import com.ritmo.player.data.ThemeMode
import com.ritmo.player.data.UiSize
import com.ritmo.player.data.WallpaperStore
import com.ritmo.player.ui.theme.accentColors
import com.ritmo.player.ui.theme.accentNames
import com.ritmo.player.ui.theme.fontFamilyFor
import com.ritmo.player.ui.theme.highlightNames
import com.ritmo.player.ui.theme.highlightOptions
import com.ritmo.player.ui.theme.isThemed
import com.ritmo.player.ui.theme.presetFor
import com.ritmo.player.ui.theme.textColorNames
import com.ritmo.player.ui.theme.textColorOptions
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.roundToInt

/** Desenha o fundo do app: papel de parede, degradê do tema ou a cor normal. */
@Composable
fun AppBackground(settings: AppSettings, wallpaper: Uri?, content: @Composable () -> Unit) {
    val preset = presetFor(settings.themeId)
    Box(Modifier.fillMaxSize()) {
        when {
            wallpaper != null -> {
                AsyncImage(
                    model = wallpaper,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().blur((settings.wallpaperBlur * 25).dp),
                )
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = settings.wallpaperDim)))
            }
            preset != null -> Box(
                Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(preset.top, preset.bottom)))
            )
            else -> Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background))
        }
        content()
    }
}

fun AppSettings.wallpaperUri(): Uri? =
    wallpaperPath?.let { File(it) }?.takeIf { it.exists() }?.let { Uri.fromFile(it) }

/** Fundo liso do tema (sem papel de parede), usado em Configurações e nas prévias. */
@Composable
fun solidThemeBackground(settings: AppSettings): Brush {
    val preset = presetFor(settings.themeId)
    return when {
        preset != null -> Brush.verticalGradient(listOf(preset.top, preset.bottom))
        !settings.isThemed() -> SolidColor(MaterialTheme.colorScheme.background)
        MaterialTheme.colorScheme.onSurface.luminance() > 0.5f -> SolidColor(Color(0xFF141218))
        else -> SolidColor(Color(0xFFFEF7FF))
    }
}

/** Visuais prontos: tema + fonte + cor de destaque de uma vez. */
private data class Combo(val name: String, val theme: AppThemeId, val font: FontStyleId, val highlight: Int)

private val combos = listOf(
    Combo("Noite", AppThemeId.BLACK, FontStyleId.MODERN, -1),
    Combo("Praia", AppThemeId.OCEAN, FontStyleId.ELEGANT, 4),
    Combo("Retrô", AppThemeId.MIDNIGHT, FontStyleId.PIXEL, 1),
    Combo("Festa", AppThemeId.NEON, FontStyleId.FUTURISTIC, 0),
    Combo("Entardecer", AppThemeId.SUNSET, FontStyleId.HANDWRITTEN, 3),
    Combo("Natureza", AppThemeId.FOREST, FontStyleId.CLASSIC, 2),
)

private val tabNames = listOf("Tema", "Fundo", "Cores", "Letras", "Tamanho", "Abas")

@Composable
fun ThemesScreen(vm: MainViewModel, onBack: () -> Unit) {
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val player by vm.player.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var saving by remember { mutableStateOf(false) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var confirmReset by remember { mutableStateOf(false) }
    var recents by remember { mutableStateOf(WallpaperStore.recent(context)) }
    val wallpaper = settings.wallpaperUri()

    BackHandler(onBack = onBack)

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            saving = true
            scope.launch {
                val path = WallpaperStore.save(context, uri)
                if (path != null) vm.settingsStore.update { it.copy(wallpaperPath = path) }
                recents = WallpaperStore.recent(context)
                saving = false
            }
        }
    }
    val pickImage = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }

    Column(Modifier.fillMaxSize()) {
        SimpleTopBar("Personalizar", onBack = onBack, actions = {
            TextButton(onClick = { confirmReset = true }) {
                Icon(Icons.Rounded.RestartAlt, null, Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Restaurar")
            }
        })
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            PreviewCard(settings, wallpaper, player.title.ifBlank { "Sua música" })

            Spacer(Modifier.height(14.dp))
            SectionLabel("Combinações prontas")
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                combos.forEach { c ->
                    ComboCard(c, selected = settings.themeId == c.theme && settings.fontStyle == c.font) {
                        vm.settingsStore.update {
                            it.copy(themeId = c.theme, fontStyle = c.font, highlight = c.highlight, textColor = 0)
                        }
                    }
                }
            }

            // Abas
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                tabNames.forEachIndexed { i, name ->
                    val sel = tab == i
                    Text(
                        name,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                        color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                            .clickable { tab = i }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                }
            }
            Spacer(Modifier.height(12.dp))

            when (tab) {
                0 -> ThemeTab(settings) { id -> vm.settingsStore.update { it.copy(themeId = id) } }
                1 -> BackgroundTab(vm, settings, wallpaper, recents, saving, pickImage)
                2 -> ColorsTab(vm, settings, wallpaper)
                3 -> FontsTab(vm, settings, player.title, player.artist)
                4 -> SizeTab(vm, settings)
                else -> TabsTab(vm, settings)
            }
            Spacer(Modifier.height(28.dp))
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Restaurar o visual padrão?") },
            text = { Text("Tema, fundo, cores, letras e tamanhos voltam ao padrão. As imagens já usadas continuam guardadas.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.settingsStore.update {
                        it.copy(
                            themeId = AppThemeId.DEFAULT,
                            wallpaperPath = null,
                            wallpaperDim = 0.55f,
                            wallpaperBlur = 0f,
                            wallpaperInPlayer = false,
                            highlight = -1,
                            textColor = 0,
                            fontStyle = FontStyleId.DEFAULT,
                            fontScale = 1f,
                            uiSize = UiSize.NORMAL,
                            themeMode = ThemeMode.SYSTEM,
                            animatedPlayerBg = true,
                        )
                    }
                    confirmReset = false
                }) { Text("Restaurar") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancelar") } },
        )
    }
}

// ---------------- Prévia do app ----------------

@Composable
private fun PreviewCard(settings: AppSettings, wallpaper: Uri?, songTitle: String) {
    val primary = MaterialTheme.colorScheme.primary
    val onBg = MaterialTheme.colorScheme.onSurface
    Row(verticalAlignment = Alignment.CenterVertically) {
        // Mini celular com a cara do app
        Box(
            Modifier
                .width(96.dp)
                .height(164.dp)
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, onBg.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                .background(solidThemeBackground(settings)),
        ) {
            if (wallpaper != null) {
                AsyncImage(
                    model = wallpaper,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().blur((settings.wallpaperBlur * 8).dp),
                )
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = settings.wallpaperDim)))
            }
            Column(Modifier.fillMaxSize().padding(7.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Box(Modifier.fillMaxWidth().height(9.dp).clip(RoundedCornerShape(50)).background(onBg.copy(alpha = 0.15f)))
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    listOf(Color(0xFF993556), Color(0xFF534AB7), Color(0xFF0F6E56)).forEach {
                        Box(Modifier.weight(1f).height(13.dp).clip(RoundedCornerShape(3.dp)).background(it))
                    }
                }
                repeat(4) { i ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(14.dp).clip(RoundedCornerShape(3.dp)).background(onBg.copy(alpha = 0.25f)))
                        Box(
                            Modifier.padding(start = 4.dp).fillMaxWidth(if (i == 1) 0.9f else 0.7f).height(5.dp)
                                .clip(RoundedCornerShape(50)).background(if (i == 1) primary else onBg.copy(alpha = 0.7f))
                        )
                    }
                }
                Spacer(Modifier.weight(1f))
                Box(Modifier.fillMaxWidth().height(16.dp).clip(RoundedCornerShape(50)).background(primary.copy(alpha = 0.5f)))
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("Seu visual", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(songTitle, style = MaterialTheme.typography.bodyMedium, color = primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            val lines = listOf(
                "Tema ${settings.themeId.label}",
                if (wallpaper != null) "Com papel de parede" else "Sem papel de parede",
                "Destaque " + if (settings.highlight == -1) "automático" else highlightNames.getOrElse(settings.highlight) { "" }.lowercase(),
                "Fonte ${settings.fontStyle.label}",
                "Interface ${settings.uiSize.label}",
            )
            lines.forEach {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
    }
}

@Composable
private fun ComboCard(combo: Combo, selected: Boolean, onClick: () -> Unit) {
    val preset = presetFor(combo.theme)
    val top = preset?.top ?: Color(0xFF2A2D3A)
    val bottom = preset?.bottom ?: Color(0xFF1A1C24)
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier
            .width(108.dp)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(top, bottom)))
            .border(if (selected) 2.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.15f), shape)
            .clickable(onClick = onClick)
            .padding(10.dp)
    ) {
        Text(
            combo.name,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontFamily = fontFamilyFor(combo.font) ?: FontFamily.Default,
            fontSize = 16.sp,
            maxLines = 1,
        )
        Text(
            "${combo.theme.label} · ${combo.font.label}",
            color = Color.White.copy(alpha = 0.7f),
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            val hl = highlightOptions.getOrNull(combo.highlight) ?: (preset?.primary ?: Color.White)
            Box(Modifier.size(12.dp).clip(CircleShape).background(hl))
            Box(Modifier.size(12.dp).clip(CircleShape).background(preset?.secondary ?: Color.Gray))
        }
    }
}

// ---------------- Abas ----------------

@Composable
private fun ThemeTab(settings: AppSettings, onSelect: (AppThemeId) -> Unit) {
    AppThemeId.entries.chunked(3).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            row.forEach { id ->
                ThemeCard(id, settings.themeId == id, Modifier.weight(1f)) { onSelect(id) }
            }
            repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

@Composable
private fun BackgroundTab(
    vm: MainViewModel,
    settings: AppSettings,
    wallpaper: Uri?,
    recents: List<File>,
    saving: Boolean,
    pickImage: () -> Unit,
) {
    var dim by remember(settings.wallpaperDim) { mutableFloatStateOf(settings.wallpaperDim) }
    var blur by remember(settings.wallpaperBlur) { mutableFloatStateOf(settings.wallpaperBlur) }

    if (wallpaper != null) {
        Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(16.dp))) {
            AsyncImage(
                model = wallpaper,
                contentDescription = "Papel de parede atual",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().blur((blur * 25).dp),
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim)))
            Text("Prévia", color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.Center))
        }
        Spacer(Modifier.height(12.dp))
    } else {
        Text(
            "Escolha uma foto da galeria para o fundo do app.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp),
        )
    }

    SectionLabel(if (recents.isEmpty()) "Escolher imagem" else "Últimas imagens")
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        // Botão + para escolher outra foto
        Box(
            Modifier
                .size(70.dp)
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                .clickable(enabled = !saving, onClick = pickImage),
            contentAlignment = Alignment.Center,
        ) {
            if (saving) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
            else Icon(Icons.Rounded.Add, "Escolher imagem", tint = MaterialTheme.colorScheme.primary)
        }
        recents.forEach { file ->
            val sel = file.absolutePath == settings.wallpaperPath
            AsyncImage(
                model = file,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(70.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(if (sel) 3.dp else 0.dp, if (sel) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(12.dp))
                    .clickable {
                        WallpaperStore.touch(file)
                        vm.settingsStore.update { it.copy(wallpaperPath = file.absolutePath) }
                    },
            )
        }
    }

    if (wallpaper != null) {
        Spacer(Modifier.height(10.dp))
        Text("Escurecer: ${(dim * 100).roundToInt()}%")
        Slider(
            value = dim,
            onValueChange = { dim = it },
            onValueChangeFinished = { vm.settingsStore.update { it.copy(wallpaperDim = dim) } },
            valueRange = 0.15f..0.85f,
        )
        Text("Desfoque: ${(blur * 100).roundToInt()}%")
        Slider(
            value = blur,
            onValueChange = { blur = it },
            onValueChangeFinished = { vm.settingsStore.update { it.copy(wallpaperBlur = blur) } },
        )
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            Text(
                "O desfoque só funciona no Android 12 ou mais novo.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        SwitchRow("Mostrar no player", "O papel de parede também atrás da tela da música", settings.wallpaperInPlayer) { on ->
            vm.settingsStore.update { it.copy(wallpaperInPlayer = on) }
        }
        TextButton(onClick = { vm.settingsStore.update { it.copy(wallpaperPath = null) } }) {
            Icon(Icons.Rounded.Delete, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.error)
            Spacer(Modifier.width(6.dp))
            Text("Tirar o papel de parede", color = MaterialTheme.colorScheme.error)
        }
    }
}

@Composable
private fun ColorsTab(vm: MainViewModel, settings: AppSettings, wallpaper: Uri?) {
    if (settings.isThemed()) {
        SectionLabel("Cor de destaque")
        Text(
            "Botões, barrinhas e ícones ativos",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        ColorRow(
            colors = highlightOptions,
            names = highlightNames,
            selected = settings.highlight,
            autoLabel = "Automática",
            onSelect = { i -> vm.settingsStore.update { it.copy(highlight = i) } },
        )
        Spacer(Modifier.height(14.dp))
        SectionLabel("Cor das letras")
        ColorRow(
            colors = textColorOptions,
            names = textColorNames,
            selected = settings.textColor,
            autoLabel = if (wallpaper != null && presetFor(settings.themeId) == null) "Cor da foto" else "Cor do tema",
            autoFirst = false,
            onSelect = { i -> vm.settingsStore.update { it.copy(textColor = i) } },
        )
    } else {
        SectionLabel("Modo")
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            listOf(
                ThemeMode.SYSTEM to "Sistema",
                ThemeMode.LIGHT to "Claro",
                ThemeMode.DARK to "Escuro",
                ThemeMode.AUTO_TIME to "Pelo horário",
            ).forEach { (mode, label) ->
                FilterChip(
                    selected = settings.themeMode == mode,
                    onClick = { vm.settingsStore.update { it.copy(themeMode = mode) } },
                    label = { Text(label) },
                )
            }
        }
        Text(
            "Pelo horário: claro de dia, escuro à noite",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        val dynamicAvailable = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
        if (dynamicAvailable) {
            SwitchRow("Cores do celular", "Usa as cores do papel de parede do celular (Material You)", settings.dynamicColor) { on ->
                vm.settingsStore.update { it.copy(dynamicColor = on) }
            }
        }
        if (!dynamicAvailable || !settings.dynamicColor) {
            Spacer(Modifier.height(10.dp))
            SectionLabel("Cor de destaque")
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                accentColors.forEachIndexed { i, color ->
                    val sel = settings.accent == i
                    Box(
                        Modifier.size(38.dp).clip(CircleShape).background(color)
                            .border(if (sel) 3.dp else 0.dp, if (sel) MaterialTheme.colorScheme.onSurface else Color.Transparent, CircleShape)
                            .clickable { vm.settingsStore.update { it.copy(accent = i) } },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (sel) Icon(Icons.Rounded.Check, accentNames[i], Modifier.size(18.dp), tint = Color.White)
                    }
                }
            }
        }
        Text(
            "Escolha um tema ou um papel de parede para ver mais cores.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    Spacer(Modifier.height(14.dp))
    SectionLabel("Cores do player")
    SegmentedChoice(
        options = listOf("Do tema", "Da capa"),
        selected = if (settings.playerColorsFromTheme) 0 else 1,
        onSelect = { i -> vm.settingsStore.update { it.copy(playerColorsFromTheme = i == 0) } },
    )
    Text(
        if (settings.playerColorsFromTheme) "O player usa as cores do tema e o destaque escolhido"
        else "O player muda de cor a cada música, de acordo com a capa",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 4.dp),
    )
    if (!settings.playerColorsFromTheme) {
        SwitchRow("Fundo animado", "A capa da música desfocada, se mexendo no fundo do player", settings.animatedPlayerBg) { on ->
            vm.settingsStore.update { it.copy(animatedPlayerBg = on) }
        }
    }
}

@Composable
private fun FontsTab(vm: MainViewModel, settings: AppSettings, title: String, artist: String) {
    // Prévia escrita na fonte escolhida
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
            .padding(14.dp)
    ) {
        Text(title.ifBlank { "Ritmo" }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(
            listOf(artist.ifBlank { "Artista" }, "Início", "Músicas", "Artistas").joinToString(" · "),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
    Spacer(Modifier.height(10.dp))
    FontStyleId.entries.chunked(4).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { style ->
                FontCard(style, settings.fontStyle == style, Modifier.weight(1f)) {
                    vm.settingsStore.update { it.copy(fontStyle = style) }
                }
            }
            repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

@Composable
private fun SizeTab(vm: MainViewModel, settings: AppSettings) {
    SectionLabel("Tamanho da interface")
    Text(
        "Capas, listas, botões e espaços",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Spacer(Modifier.height(8.dp))
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
            .padding(3.dp)
    ) {
        UiSize.entries.forEach { size ->
            val sel = settings.uiSize == size
            Text(
                size.label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(50))
                    .background(if (sel) MaterialTheme.colorScheme.primary else Color.Transparent)
                    .clickable { vm.settingsStore.update { it.copy(uiSize = size) } }
                    .padding(vertical = 8.dp),
            )
        }
    }

    Spacer(Modifier.height(18.dp))
    var scale by remember(settings.fontScale) { mutableFloatStateOf(settings.fontScale) }
    SectionLabel("Tamanho das letras: ${(scale * 100).roundToInt()}%")
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("A", style = MaterialTheme.typography.bodySmall)
        Slider(
            value = scale,
            onValueChange = { scale = it },
            onValueChangeFinished = { vm.settingsStore.update { it.copy(fontScale = scale) } },
            valueRange = 0.85f..1.3f,
            steps = 8,
            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
        )
        Text("A", style = MaterialTheme.typography.titleLarge)
    }

    Spacer(Modifier.height(12.dp))
    SectionLabel("Prévia")
    repeat(3) { i ->
        Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f)))
            Column(Modifier.padding(start = 12.dp)) {
                Text("Música ${i + 1}", style = MaterialTheme.typography.bodyLarge)
                Text("Artista | Álbum", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

// ---------------- Peças ----------------

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onChange(!checked) }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(bottom = 4.dp),
    )
}

/** Fileira de bolinhas de cor. O índice -1 é a opção automática. */
@Composable
private fun ColorRow(
    colors: List<Color>,
    names: List<String>,
    selected: Int,
    autoLabel: String,
    onSelect: (Int) -> Unit,
    autoFirst: Boolean = true,
) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val auto: @Composable () -> Unit = {
            val isSel = selected == -1
            Box(
                Modifier.size(38.dp).clip(CircleShape)
                    .border(if (isSel) 3.dp else 1.dp, if (isSel) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline, CircleShape)
                    .clickable { onSelect(-1) },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.AutoAwesome, autoLabel, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurface)
            }
        }
        if (autoFirst) auto()
        colors.forEachIndexed { i, color ->
            val isSel = selected == i
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(color)
                    .border(if (isSel) 3.dp else 0.dp, if (isSel) MaterialTheme.colorScheme.onSurface else Color.Transparent, CircleShape)
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) {
                if (isSel) {
                    Icon(
                        Icons.Rounded.Check, names.getOrElse(i) { "" },
                        tint = if (color.luminance() > 0.5f) Color.Black else Color.White,
                        modifier = Modifier.size(18.dp),
                    )
                }
            }
        }
        if (!autoFirst) auto()
    }
    val label = if (selected == -1) autoLabel else names.getOrElse(selected) { "" }
    Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun FontCard(style: FontStyleId, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier
            .clip(shape)
            .background(if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
            .border(if (selected) 2.dp else 0.dp, if (selected) MaterialTheme.colorScheme.primary else Color.Transparent, shape)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Aa", fontFamily = fontFamilyFor(style) ?: FontFamily.Default, fontSize = 22.sp, maxLines = 1)
        Text(
            style.label,
            style = MaterialTheme.typography.labelSmall,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** Cartão de tema com uma miniatura da tela. */
@Composable
private fun ThemeCard(id: AppThemeId, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val preset = presetFor(id)
    val top = preset?.top ?: MaterialTheme.colorScheme.surfaceContainerHigh
    val bottom = preset?.bottom ?: MaterialTheme.colorScheme.surfaceContainerLow
    val primary = preset?.primary ?: MaterialTheme.colorScheme.primary
    val shape = RoundedCornerShape(12.dp)
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(0.78f)
                .clip(shape)
                .background(Brush.verticalGradient(listOf(top, bottom)))
                .border(if (selected) 2.dp else 1.dp, if (selected) primary else Color.White.copy(alpha = 0.12f), shape)
                .clickable(onClick = onClick)
                .padding(7.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Box(Modifier.fillMaxWidth().height(30.dp).clip(RoundedCornerShape(6.dp)).background(Color.White.copy(alpha = 0.18f)))
                Box(Modifier.fillMaxWidth(0.8f).height(5.dp).clip(CircleShape).background(primary))
                Box(Modifier.fillMaxWidth(0.6f).height(4.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.45f)))
                Box(Modifier.fillMaxWidth(0.7f).height(4.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.3f)))
            }
            if (selected) {
                Text(
                    "Aplicado",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF633806),
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .offset((-1).dp, 1.dp)
                        .clip(RoundedCornerShape(50))
                        .background(Color(0xFFFAEEDA))
                        .padding(horizontal = 6.dp, vertical = 1.dp),
                )
            }
        }
        Text(
            id.label,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (selected) FontWeight.Bold else null,
            color = if (selected) primary else MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}

@Composable
private fun SegmentedChoice(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
            .padding(3.dp)
    ) {
        options.forEachIndexed { i, label ->
            val sel = selected == i
            Text(
                label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(50))
                    .background(if (sel) MaterialTheme.colorScheme.primary else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(vertical = 8.dp),
            )
        }
    }
}

/** Aba "Abas": arrastar para mudar a ordem e esconder as que não usa. */
@Composable
private fun TabsTab(vm: MainViewModel, settings: AppSettings) {
    var order by remember(settings.tabOrder) { mutableStateOf(settings.tabOrder) }
    var dragging by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    val haptics = androidx.compose.ui.platform.LocalHapticFeedback.current
    val rowHeight = 56.dp
    val rowPx = with(androidx.compose.ui.platform.LocalDensity.current) { (rowHeight + 6.dp).toPx() }
    val visibleCount = order.count { it !in settings.hiddenTabs }

    Text(
        "Segure ⠿ e arraste para mudar a ordem. A primeira aba é a que abre ao iniciar.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(bottom = 8.dp),
    )
    Column {
        order.forEach { id ->
            androidx.compose.runtime.key(id) {
                val isDrag = dragging == id
                val hidden = id in settings.hiddenTabs
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(rowHeight)
                        .zIndex(if (isDrag) 1f else 0f)
                        .graphicsLayer { translationY = if (isDrag) dragOffset else 0f }
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isDrag) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                            else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)
                        )
                        .padding(end = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        Icons.Rounded.DragIndicator,
                        "Arrastar",
                        modifier = Modifier
                            .size(48.dp)
                            .padding(12.dp)
                            .pointerInput(id) {
                                detectDragGestures(
                                    onDragStart = {
                                        haptics.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                                        dragging = id
                                        dragOffset = 0f
                                    },
                                    onDragEnd = {
                                        dragging = null
                                        dragOffset = 0f
                                        val newOrder = order
                                        vm.settingsStore.update { it.copy(tabOrder = newOrder) }
                                    },
                                    onDragCancel = { dragging = null; dragOffset = 0f },
                                ) { change, amount ->
                                    change.consume()
                                    dragOffset += amount.y
                                    val idx = order.indexOf(id)
                                    if (dragOffset > rowPx / 2 && idx < order.size - 1) {
                                        order = order.toMutableList().apply { removeAt(idx); add(idx + 1, id) }
                                        dragOffset -= rowPx
                                    } else if (dragOffset < -rowPx / 2 && idx > 0) {
                                        order = order.toMutableList().apply { removeAt(idx); add(idx - 1, id) }
                                        dragOffset += rowPx
                                    }
                                }
                            },
                    )
                    Text(
                        tabTitle(id) + if (hidden) " (escondida)" else "",
                        color = if (hidden) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f),
                    )
                    Switch(
                        checked = !hidden,
                        enabled = hidden || visibleCount > 1,
                        onCheckedChange = { show ->
                            vm.settingsStore.update {
                                it.copy(hiddenTabs = if (show) it.hiddenTabs - id else it.hiddenTabs + id)
                            }
                        },
                    )
                }
                Spacer(Modifier.height(6.dp))
            }
        }
    }
}
