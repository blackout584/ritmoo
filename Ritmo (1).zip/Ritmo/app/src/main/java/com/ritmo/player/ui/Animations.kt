package com.ritmo.player.ui

import android.net.Uri
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.palette.graphics.Palette
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

// ---------------- Cores tiradas da capa ----------------

data class ArtColors(val background: Color, val accent: Color)

val PlayerBottomColor = Color(0xFF0B0B0E)

/** Extrai as cores da capa do álbum (fundo escuro + cor de destaque viva). */
@Composable
fun rememberArtColors(uri: Uri?, fallbackAccent: Color): ArtColors {
    val context = LocalContext.current
    val extracted by produceState<ArtColors?>(initialValue = null, uri) {
        value = withContext(Dispatchers.Default) {
            runCatching {
                if (uri == null) return@runCatching null
                val request = ImageRequest.Builder(context)
                    .data(uri)
                    .allowHardware(false)
                    .size(160)
                    .build()
                val result = context.imageLoader.execute(request) as? SuccessResult
                    ?: return@runCatching null
                val palette = Palette.from(result.drawable.toBitmap()).generate()
                val bg = palette.darkMutedSwatch?.rgb
                    ?: palette.darkVibrantSwatch?.rgb
                    ?: palette.dominantSwatch?.rgb
                    ?: return@runCatching null
                val accent = palette.vibrantSwatch?.rgb
                    ?: palette.lightVibrantSwatch?.rgb
                    ?: palette.dominantSwatch?.rgb
                ArtColors(Color(bg), accent?.let { Color(it) } ?: fallbackAccent)
            }.getOrNull()
        }
    }
    val base = extracted ?: ArtColors(Color(0xFF2A2D3A), fallbackAccent)
    return ArtColors(
        background = lerp(base.background, Color.Black, 0.25f),
        accent = brighten(base.accent),
    )
}

private fun brighten(c: Color): Color =
    if (c.luminance() < 0.3f) lerp(c, Color.White, 0.45f) else c

// ---------------- Capa em forma de disco de vinil ----------------

@Composable
fun VinylArt(uri: Uri?, isPlaying: Boolean, modifier: Modifier = Modifier) {
    val rotation = remember { Animatable(0f) }
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (isActive) {
                rotation.animateTo(
                    rotation.value + 360f,
                    animationSpec = tween(durationMillis = 9000, easing = LinearEasing),
                )
                rotation.snapTo(rotation.value % 360f)
            }
        } else {
            // Desacelera devagar, como um disco de verdade parando.
            rotation.animateTo(
                rotation.value + 25f,
                animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
            )
        }
    }
    val scale by animateFloatAsState(
        if (isPlaying) 1f else 0.94f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "vinylScale",
    )

    Box(
        modifier
            .aspectRatio(1f)
            .scale(scale)
            .shadow(24.dp, CircleShape)
            .clip(CircleShape)
            .background(Color(0xFF111114))
            .rotate(rotation.value),
        contentAlignment = Alignment.Center,
    ) {
        // Sulcos do disco
        Canvas(Modifier.fillMaxSize()) {
            val maxR = size.minDimension / 2f
            var r = maxR * 0.97f
            var i = 0
            while (r > maxR * 0.45f) {
                drawCircle(
                    color = Color.White.copy(alpha = if (i % 3 == 0) 0.08f else 0.035f),
                    radius = r,
                    style = Stroke(width = 1.2f),
                )
                r -= maxR * 0.025f
                i++
            }
            // Reflexo de luz
            drawCircle(
                brush = Brush.sweepGradient(
                    listOf(
                        Color.Transparent,
                        Color.White.copy(alpha = 0.07f),
                        Color.Transparent,
                        Color.White.copy(alpha = 0.07f),
                        Color.Transparent,
                    )
                ),
                radius = maxR,
            )
        }
        // Rótulo central com a capa
        ArtImage(uri, Modifier.fillMaxSize(0.62f).clip(CircleShape), corner = 999.dp)
        // Furo do meio
        Box(
            Modifier.size(14.dp).clip(CircleShape).background(Color(0xFF111114))
        )
    }
}

/** Capa quadrada que "respira": cresce quando toca e encolhe ao pausar. */
@Composable
fun BreathingArt(uri: Uri?, isPlaying: Boolean, modifier: Modifier = Modifier) {
    val scale by animateFloatAsState(
        if (isPlaying) 1f else 0.86f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "artScale",
    )
    ArtImage(
        uri,
        modifier
            .aspectRatio(1f)
            .scale(scale)
            .shadow(24.dp, RoundedCornerShape(20.dp)),
        corner = 20.dp,
    )
}

// ---------------- Barras que dançam ----------------

@Composable
fun VisualizerBars(levels: FloatArray, color: Color, modifier: Modifier = Modifier, height: Dp = 56.dp) {
    Row(
        modifier.fillMaxWidth().height(height),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        levels.forEachIndexed { i, target ->
            val level by animateFloatAsState(
                targetValue = target,
                animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium),
                label = "bar$i",
            )
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight(0.06f + 0.94f * level)
                    .clip(RoundedCornerShape(50))
                    .background(
                        Brush.verticalGradient(
                            listOf(color, color.copy(alpha = 0.55f), color)
                        )
                    )
            )
        }
    }
}

// ---------------- Botões com "pulinho" ----------------

@Composable
fun BouncyIconButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = false,
    content: @Composable () -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.82f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "press",
    )
    val m = modifier.graphicsLayer { scaleX = scale; scaleY = scale }
    if (filled) {
        FilledIconButton(onClick = onClick, modifier = m, interactionSource = interaction) { content() }
    } else {
        IconButton(onClick = onClick, modifier = m, interactionSource = interaction) { content() }
    }
}

/** Ícone de play/pause que se transforma com animação. */
@Composable
fun AnimatedPlayIcon(isPlaying: Boolean, modifier: Modifier = Modifier) {
    AnimatedContent(
        targetState = isPlaying,
        transitionSpec = {
            (scaleIn(initialScale = 0.4f) + fadeIn()) togetherWith (scaleOut(targetScale = 0.4f) + fadeOut())
        },
        label = "playIcon",
    ) { playing ->
        Icon(
            if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
            if (playing) "Pausar" else "Tocar",
            modifier,
        )
    }
}
