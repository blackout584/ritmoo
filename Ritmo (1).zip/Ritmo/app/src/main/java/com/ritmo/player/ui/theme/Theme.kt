package com.ritmo.player.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.ritmo.player.data.AppSettings
import com.ritmo.player.data.ThemeMode

val accentColors = listOf(
    Color(0xFF4F7DF3), // azul
    Color(0xFFE8505B), // vermelho
    Color(0xFF2BB673), // verde
    Color(0xFFF2A93B), // laranja
    Color(0xFF9B5DE5), // roxo
    Color(0xFF14B8C4), // ciano
)
val accentNames = listOf("Azul", "Vermelho", "Verde", "Laranja", "Roxo", "Ciano")

@Composable
fun RitmoTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val context = LocalContext.current
    val scheme = if (settings.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        val accent = accentColors[settings.accent.coerceIn(accentColors.indices)]
        if (dark) {
            darkColorScheme(
                primary = accent,
                secondary = accent,
                tertiary = accent,
                background = Color(0xFF0F1013),
                surface = Color(0xFF0F1013),
                onPrimary = Color.White,
            )
        } else {
            lightColorScheme(primary = accent, secondary = accent, tertiary = accent, onPrimary = Color.White)
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
