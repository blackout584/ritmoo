@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.ritmo.player.ui

import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import com.ritmo.player.ui.theme.presetFor
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Share
import androidx.compose.foundation.border
import androidx.compose.ui.graphics.lerp
import android.widget.Toast
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.material.icons.rounded.DragIndicator
import androidx.compose.material.icons.rounded.Save
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.zIndex
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Checkroom
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.SmartDisplay
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.launch
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.vector.ImageVector
import com.ritmo.player.data.AppThemeId
import com.ritmo.player.data.PlayMode
import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.layout.Box
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.core.content.ContextCompat
import com.ritmo.player.playback.AudioEffects
import com.ritmo.player.playback.AudioVisualizer
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import com.ritmo.player.data.FAVORITES_ID
import kotlinx.coroutines.delay

// ---------------- Mini player (barra inferior) ----------------

@Composable
fun MiniPlayer(state: PlayerUiState, vm: MainViewModel, onClick: () -> Unit) {
    val position by rememberPlaybackPosition(vm)
    // Cor do mini player tirada da capa da música
    val artColors = rememberArtColors(state.artUri, MaterialTheme.colorScheme.primary)
    val container by animateColorAsState(
        lerp(artColors.accent, artColors.background, 0.45f),
        tween(700),
        label = "miniColor",
    )
    val tr = LocalPlayerTransition.current
    val miniScope = rememberCoroutineScope()
    if (tr != null) androidx.compose.runtime.SideEffect { tr.miniColor = container }
    Surface(
        onClick = onClick,
        color = container,
        contentColor = Color.White,
        shape = RoundedCornerShape(28.dp),
        shadowElevation = 6.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .onGloballyPositioned { if (tr != null) tr.miniBox = it.rectInRoot() }
            .then(
                if (tr == null) Modifier else Modifier.pointerInput(Unit) {
                    // Arrastar o mini player pra cima abre o player junto com o dedo
                    detectVerticalDragGestures(
                        onDragStart = { tr.dragging = true },
                        onDragEnd = {
                            tr.dragging = false
                            miniScope.launch {
                                if (tr.p > 0.15f) { onClick(); tr.animateTo(1f) } else tr.animateTo(0f)
                            }
                        },
                        onDragCancel = { tr.dragging = false; miniScope.launch { tr.animateTo(0f) } },
                    ) { change, amount ->
                        change.consume()
                        miniScope.launch {
                            tr.progress.snapTo((tr.p - amount / (tr.screenHeight * 0.85f)).coerceIn(0f, 1f))
                        }
                    }
                }
            ),
    ) {
        Row(
            Modifier.padding(start = 6.dp, end = 4.dp, top = 5.dp, bottom = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // Disquinho girando, agora inteiro dentro do quadro
            // Ícone muda conforme o estilo do reprodutor (capa, disco, CD ou fita)
            val miniSettings by vm.settingsStore.settings.collectAsStateWithLifecycle()
            Box(
                Modifier
                    .onGloballyPositioned { if (tr != null) tr.miniArt = it.rectInRoot() }
                    .graphicsLayer { alpha = if (tr != null && tr.p > 0.002f) 0f else 1f }
            ) {
                MiniStyleIcon(miniSettings.playerStyle, state.artUri, state.isPlaying)
            }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(
                    state.title,
                    maxLines = 1,
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.basicMarquee(),
                )
                Text(
                    state.artist,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.8f),
                )
                LinearProgressIndicator(
                    progress = {
                        if (state.durationMs > 0) (position.toFloat() / state.durationMs).coerceIn(0f, 1f) else 0f
                    },
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp).height(2.dp).clip(RoundedCornerShape(50)),
                    color = Color.White,
                    trackColor = Color.White.copy(alpha = 0.25f),
                    gapSize = 0.dp,
                    drawStopIndicator = {},
                )
            }
            BouncyIconButton(onClick = { vm.togglePlay() }, modifier = Modifier.size(40.dp)) {
                Box(
                    Modifier.size(32.dp).border(1.5.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    AnimatedPlayIcon(state.isPlaying, Modifier.size(18.dp))
                }
            }
            BouncyIconButton(onClick = { vm.next() }, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Rounded.SkipNext, "Próxima", Modifier.size(22.dp))
            }
        }
    }
}

// ---------------- Tela "Tocando agora" ----------------

private data class TrackKey(val id: String?, val artUri: Uri?, val index: Int)

@Composable
fun NowPlayingScreen(vm: MainViewModel, onClose: () -> Unit, onOpenDetail: (Detail) -> Unit = {}) {
    val s by vm.player.collectAsStateWithLifecycle()
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val playlists by vm.playlistStore.playlists.collectAsStateWithLifecycle()
    val sleepEnd by vm.sleepTimerEnd.collectAsStateWithLifecycle()
    val sleepAtEnd by vm.sleepAtEnd.collectAsStateWithLifecycle()
    val songId = s.mediaId?.toLongOrNull()
    val isFavorite = songId != null &&
        playlists.firstOrNull { it.id == FAVORITES_ID }?.songIds?.contains(songId) == true

    var showQueue by remember { mutableStateOf(false) }
    var showSpeed by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    var showAddToPlaylist by remember { mutableStateOf(false) }
    var showLyrics by rememberSaveable { mutableStateOf(false) }
    var showMore by remember { mutableStateOf(false) }
    var showEq by remember { mutableStateOf(false) }
    var showStyles by remember { mutableStateOf(false) }
    // Ações do menu ⋮ (compartilhar, detalhes, editar, mover, apagar)
    var songAction by remember { mutableStateOf("") }
    val allSongs by vm.songs.collectAsStateWithLifecycle()
    val currentSong = remember(s.mediaId, allSongs) { allSongs.firstOrNull { it.id.toString() == s.mediaId } }
    val mediaActions = rememberMediaActions(vm)
    val scope = rememberCoroutineScope()
    // Deslizar para baixo encolhe o player de volta pro mini player
    val tr = LocalPlayerTransition.current
    val dragY = remember { Animatable(0f) }
    // Deslizar a capa para o lado troca de música
    val dragX = remember { Animatable(0f) }

    if (!s.hasMedia) {
        LaunchedEffect(Unit) { onClose() }
        return
    }

    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(10_000)
        }
    }

    // Cores da capa, com transição suave entre músicas.
    // No tema Preto (sem papel de parede) o player também fica todo preto.
    val allBlack = settings.themeId == AppThemeId.BLACK && settings.wallpaperPath == null
    // "Do tema": o player usa as cores do tema e o destaque escolhido; "Da capa": cores da música
    val themeColors = settings.playerColorsFromTheme && !allBlack
    val appPrimary = MaterialTheme.colorScheme.primary
    val themePreset = presetFor(settings.themeId)
    val fromArt = rememberArtColors(s.artUri, appPrimary)
    val artColors = when {
        allBlack -> ArtColors(Color.Black, appPrimary)
        themeColors -> ArtColors(themePreset?.top ?: lerp(appPrimary, Color.Black, 0.72f), appPrimary)
        else -> fromArt
    }
    val bottomColor = when {
        allBlack -> Color.Black
        themeColors -> themePreset?.bottom ?: lerp(appPrimary, Color.Black, 0.9f)
        else -> PlayerBottomColor
    }
    val bgColor by animateColorAsState(artColors.background, tween(900), label = "bg")
    val accent by animateColorAsState(artColors.accent, tween(900), label = "accent")

    // Barras que dançam
    val context = LocalContext.current
    var micGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        micGranted = it
    }
    val sessionId by AudioEffects.sessionIdFlow.collectAsStateWithLifecycle()
    val showBars = settings.visualizer && micGranted
    DisposableEffect(showBars, sessionId) {
        if (showBars) AudioVisualizer.start(sessionId)
        onDispose { AudioVisualizer.stop() }
    }
    val levels by AudioVisualizer.levels.collectAsStateWithLifecycle()

    val playerScheme = darkColorScheme(
        primary = accent,
        onPrimary = if (accent.luminance() > 0.5f) Color.Black else Color.White,
        primaryContainer = accent.copy(alpha = 0.25f),
        onPrimaryContainer = Color.White,
        secondaryContainer = accent.copy(alpha = 0.22f),
        onSecondaryContainer = Color.White,
        background = PlayerBottomColor,
        surface = Color(0xFF17181D),
        surfaceContainerLow = Color(0xFF17181D),
        surfaceContainerHigh = Color(0xFF202128),
    )

    MaterialTheme(colorScheme = playerScheme) {
        Surface(
            Modifier
                .fillMaxSize()
                .graphicsLayer { translationY = if (tr == null) dragY.value else 0f }
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragStart = { tr?.dragging = true },
                        onDragEnd = {
                            tr?.dragging = false
                            scope.launch {
                                if (tr != null) {
                                    if (tr.p < 0.82f) onClose() else tr.animateTo(1f)
                                } else {
                                    if (dragY.value > size.height * 0.18f) onClose() else dragY.animateTo(0f)
                                }
                            }
                        },
                        onDragCancel = {
                            tr?.dragging = false
                            scope.launch { if (tr != null) tr.animateTo(1f) else dragY.animateTo(0f) }
                        },
                    ) { change, amount ->
                        change.consume()
                        scope.launch {
                            if (tr != null) {
                                tr.progress.snapTo((tr.p - amount / (size.height * 0.85f)).coerceIn(0f, 1f))
                            } else {
                                dragY.snapTo((dragY.value + amount).coerceAtLeast(0f))
                            }
                        }
                    }
                },
            color = bottomColor,
            contentColor = Color.White,
            shape = RoundedCornerShape(topStart = if (dragY.value > 0f) 28.dp else 0.dp, topEnd = if (dragY.value > 0f) 28.dp else 0.dp),
        ) {
        Box(Modifier.fillMaxSize()) {
            val playerWallpaper = if (settings.wallpaperInPlayer) settings.wallpaperUri() else null
            if (playerWallpaper != null) {
                coil.compose.AsyncImage(
                    model = playerWallpaper,
                    contentDescription = null,
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().blur((settings.wallpaperBlur * 25).dp),
                )
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = maxOf(settings.wallpaperDim, 0.45f))))
            } else if (settings.animatedPlayerBg && !allBlack && !themeColors) {
                AnimatedArtBackground(s.artUri, bgColor, bottomColor)
            } else {
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(bgColor, bottomColor))))
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        // Conteúdo aparece no fim da abertura (a capa vem voando separada)
                        alpha = if (tr == null) 1f else ((tr.p - 0.55f) / 0.45f).coerceIn(0f, 1f)
                    }
                    .systemBarsPadding()
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    BouncyIconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Fechar", tint = Color.White) }
                    Spacer(Modifier.weight(1f))
                    BouncyIconButton(onClick = { showStyles = true }) {
                        Icon(Icons.Rounded.Checkroom, "Estilos do reprodutor", tint = Color.White)
                    }
                    BouncyIconButton(onClick = { showEq = true }) {
                        Icon(Icons.Rounded.Tune, "Equalizador", tint = Color.White)
                    }
                    Box {
                        BouncyIconButton(onClick = { showMore = true }) {
                            Icon(Icons.Rounded.MoreVert, "Mais opções", tint = Color.White)
                        }
                        DropdownMenu(expanded = showMore, onDismissRequest = { showMore = false }) {
                            if (currentSong != null) {
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Rounded.Share, null) },
                                    text = { Text("Compartilhar") },
                                    onClick = { showMore = false; mediaActions.share(listOf(currentSong)) },
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Rounded.Info, null) },
                                    text = { Text("Detalhes") },
                                    onClick = { showMore = false; songAction = "details" },
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Rounded.Edit, null) },
                                    text = { Text("Editar informações") },
                                    onClick = { showMore = false; songAction = "edit" },
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Rounded.DriveFileMove, null) },
                                    text = { Text("Mover para pasta") },
                                    onClick = { showMore = false; songAction = "move" },
                                )
                                HorizontalDivider()
                            }
                            DropdownMenuItem(
                                leadingIcon = { Icon(Icons.Rounded.SmartDisplay, null) },
                                text = { Text("Abrir no YouTube") },
                                onClick = { showMore = false; openInYouTube(context, s.title, s.artist) },
                            )
                            DropdownMenuItem(
                                leadingIcon = { Icon(Icons.Rounded.MusicNote, null) },
                                text = { Text("Abrir no YouTube Music") },
                                onClick = { showMore = false; openInYouTubeMusic(context, s.title, s.artist) },
                            )
                            if (currentSong != null) {
                                HorizontalDivider()
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Rounded.Delete, null, tint = MaterialTheme.colorScheme.error) },
                                    text = { Text("Apagar do celular", color = MaterialTheme.colorScheme.error) },
                                    onClick = { showMore = false; songAction = "delete" },
                                )
                            }
                        }
                    }
                }

                if (showLyrics) {
                    LaunchedEffect(Unit) { tr?.fullArt = androidx.compose.ui.geometry.Rect.Zero }
                    Spacer(Modifier.height(8.dp))
                    LyricsPanel(vm, s.mediaId, accent, Modifier.fillMaxWidth().weight(1.6f))
                } else {
                Spacer(Modifier.weight(1f))

                // Capa: desliza para o lado ao trocar de música (ou arraste com o dedo)
                AnimatedContent(
                    targetState = TrackKey(s.mediaId, s.artUri, s.queueIndex),
                    contentKey = { it.id },
                    transitionSpec = {
                        val forward = targetState.index >= initialState.index
                        val dir = if (forward) 1 else -1
                        (slideInHorizontally(tween(450)) { w -> dir * w } + fadeIn(tween(450)))
                            .togetherWith(slideOutHorizontally(tween(450)) { w -> -dir * w } + fadeOut(tween(300)))
                            .using(SizeTransform(clip = false))
                    },
                    label = "art",
                    modifier = Modifier
                        .fillMaxWidth()
                        .graphicsLayer {
                            translationX = dragX.value
                            rotationZ = dragX.value / 60f
                        }
                        .pointerInput(Unit) {
                            detectHorizontalDragGestures(
                                onDragEnd = {
                                    val dx = dragX.value
                                    scope.launch {
                                        when {
                                            dx < -size.width * 0.22f -> { vm.next(); dragX.snapTo(0f) }
                                            dx > size.width * 0.22f -> { vm.previous(); dragX.snapTo(0f) }
                                            else -> dragX.animateTo(0f)
                                        }
                                    }
                                },
                                onDragCancel = { scope.launch { dragX.animateTo(0f) } },
                            ) { change, amount ->
                                change.consume()
                                scope.launch { dragX.snapTo(dragX.value + amount) }
                            }
                        },
                ) { key ->
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        PlayerStyleArt(
                            style = settings.playerStyle,
                            uri = key.artUri,
                            isPlaying = s.isPlaying,
                            accent = accent,
                            pulse = bassPulse(levels),
                            showPulse = showBars,
                            modifier = Modifier
                                .fillMaxWidth(0.78f)
                                .onGloballyPositioned {
                                    if (tr != null && dragX.value == 0f) tr.fullArt = it.rectInRoot()
                                }
                                .graphicsLayer { alpha = if (tr != null && tr.p < 0.998f) 0f else 1f },
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))

                when {
                    showBars -> VisualizerBars(levels, accent, Modifier.fillMaxWidth(0.7f), height = 28.dp)
                    settings.visualizer -> TextButton(onClick = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }) {
                        Icon(Icons.Rounded.GraphicEq, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Ativar barras que dançam")
                    }
                    else -> Spacer(Modifier.height(28.dp))
                }
                }

                Spacer(Modifier.height(10.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    AnimatedContent(
                        targetState = Pair(s.title, s.artist to s.album),
                        transitionSpec = {
                            (slideInVertically { it / 2 } + fadeIn()) togetherWith (slideOutVertically { -it / 2 } + fadeOut())
                        },
                        label = "titles",
                        modifier = Modifier.weight(1f),
                    ) { (title, sub) ->
                        Column {
                            Text(
                                title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1,
                                modifier = Modifier.basicMarquee(),
                            )
                            Text(
                                listOf(sub.first, sub.second).filter { it.isNotBlank() }.joinToString(" • "),
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.7f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                    BouncyIconButton(onClick = { songId?.let { vm.toggleFavorite(it) } }) {
                        val heartScale by animateFloatAsState(
                            if (isFavorite) 1.15f else 1f,
                            spring(dampingRatio = Spring.DampingRatioHighBouncy),
                            label = "heart",
                        )
                        Icon(
                            if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                            "Favorita",
                            tint = if (isFavorite) accent else Color.White,
                            modifier = Modifier.scale(heartScale),
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))
                SeekBar(vm, s.durationMs)
                Spacer(Modifier.height(4.dp))

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    val inactive = Color.White.copy(alpha = 0.6f)
                    PlayModeButton(
                        current = currentPlayMode(s),
                        accent = accent,
                        onSelect = { vm.setPlayMode(it) },
                    )
                    BouncyIconButton(onClick = { vm.previous() }, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Rounded.SkipPrevious, "Anterior", Modifier.size(30.dp), tint = Color.White)
                    }
                    BouncyIconButton(onClick = { vm.togglePlay() }, filled = true, modifier = Modifier.size(62.dp)) {
                        AnimatedPlayIcon(s.isPlaying, Modifier.size(32.dp))
                    }
                    BouncyIconButton(onClick = { vm.next() }, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Rounded.SkipNext, "Próxima", Modifier.size(30.dp), tint = Color.White)
                    }
                    BouncyIconButton(onClick = { showQueue = true }) {
                        Icon(Icons.AutoMirrored.Rounded.QueueMusic, "Fila", tint = inactive)
                    }
                }

                Spacer(Modifier.weight(1f))

                Row(
                    Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    val end = sleepEnd
                    PlayerToolButton(Icons.Rounded.Speed, formatSpeed(s.speed), active = s.speed != 1f, accent) { showSpeed = true }
                    PlayerToolButton(
                        Icons.Rounded.Timer,
                        when {
                            sleepAtEnd -> "Fim da música"
                            end == null -> "Timer"
                            else -> "${((end - now) / 60_000 + 1).coerceAtLeast(1)} min"
                        },
                        active = end != null || sleepAtEnd,
                        accent,
                    ) { showSleep = true }
                    PlayerToolButton(Icons.Rounded.Subtitles, "Letra", active = showLyrics, accent) { showLyrics = !showLyrics }
                    PlayerToolButton(Icons.AutoMirrored.Rounded.PlaylistAdd, "Playlist", active = false, accent) { showAddToPlaylist = true }
                }
            }
        }
        }

        if (showQueue) QueueSheet(s, vm) { showQueue = false }
        val cs = currentSong
        if (cs != null) when (songAction) {
            "details" -> SongDetailsSheet(vm, cs, onDismiss = { songAction = "" }, onOpenFolder = {
                onClose()
                onOpenDetail(Detail.Folder(cs.folderPath, cs.folderName))
            })
            "edit" -> EditSongDialog(vm, cs) { songAction = "" }
            "move" -> MoveDialog(vm, onPick = { dir -> mediaActions.move(listOf(cs), dir); songAction = "" }, onDismiss = { songAction = "" })
            "delete" -> ConfirmDeleteDialog(1, onConfirm = {
                songAction = ""
                mediaActions.delete(listOf(cs))
            }, onDismiss = { songAction = "" })
        }
        if (showStyles) {
            PlayerStylesSheet(
                current = settings.playerStyle,
                artUri = s.artUri,
                onSelect = { st -> vm.settingsStore.update { it.copy(playerStyle = st) } },
                onDismiss = { showStyles = false },
            )
        }
        if (showEq) {
            ModalBottomSheet(onDismissRequest = { showEq = false }) {
                Box(Modifier.fillMaxWidth().fillMaxHeight(0.85f)) { EqualizerScreen() }
            }
        }
        if (showSpeed) SpeedDialog(s.speed, onSelect = { vm.setSpeed(it); showSpeed = false }) { showSpeed = false }
        if (showSleep) {
            SleepDialog(
                active = sleepEnd != null,
                atEnd = sleepAtEnd,
                onSelect = { value ->
                    when (value) {
                        null -> { vm.setSleepTimer(null); vm.setSleepAtEnd(false) }
                        -1 -> vm.setSleepAtEnd(true)
                        else -> vm.setSleepTimer(value)
                    }
                    showSleep = false
                },
            ) { showSleep = false }
        }
        if (showAddToPlaylist && songId != null) AddToPlaylistDialog(vm, listOf(songId)) { showAddToPlaylist = false }
    }
}

@Composable
private fun SeekBar(vm: MainViewModel, durationMs: Long) {
    val position by rememberPlaybackPosition(vm)
    var dragging by remember { mutableStateOf<Float?>(null) }
    val duration = durationMs.coerceAtLeast(1)
    val fraction = dragging ?: (position.toFloat() / duration).coerceIn(0f, 1f)

    Column(Modifier.fillMaxWidth()) {
        Slider(
            value = fraction,
            onValueChange = { dragging = it },
            onValueChangeFinished = {
                dragging?.let { vm.seekTo((it * duration).toLong()) }
                dragging = null
            },
        )
        Row(Modifier.fillMaxWidth()) {
            Text(
                formatTime(if (dragging != null) (fraction * duration).toLong() else position),
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.weight(1f),
            )
            Text(formatTime(durationMs), style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun QueueSheet(s: PlayerUiState, vm: MainViewModel, onDismiss: () -> Unit) {
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = (s.queueIndex - 1).coerceAtLeast(0))
    var saving by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val haptics = LocalHapticFeedback.current
    val density = LocalDensity.current

    // Arrastar: posição original, dedo (em px, a partir do topo da lista) e onde vai cair
    var dragFrom by remember { mutableStateOf<Int?>(null) }
    var fingerY by remember { mutableFloatStateOf(0f) }
    var target by remember { mutableStateOf<Int?>(null) }
    fun indexAt(y: Float): Int? =
        listState.layoutInfo.visibleItemsInfo.firstOrNull { y >= it.offset && y < it.offset + it.size }?.index

    // Rolagem automática quando o dedo chega perto das bordas (mais rápido quanto mais perto)
    LaunchedEffect(dragFrom) {
        if (dragFrom == null) return@LaunchedEffect
        val edge = with(density) { 90.dp.toPx() }
        while (dragFrom != null) {
            val h = listState.layoutInfo.viewportSize.height.toFloat()
            val speed = when {
                fingerY < edge -> -((edge - fingerY) / edge).coerceIn(0f, 1f) * 45f
                fingerY > h - edge -> ((fingerY - (h - edge)) / edge).coerceIn(0f, 1f) * 45f
                else -> 0f
            }
            if (speed != 0f) {
                listState.scrollBy(speed)
                indexAt(fingerY.coerceIn(0f, h - 1f))?.let { target = it }
            }
            delay(16)
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Row(
            Modifier.fillMaxWidth().padding(start = 24.dp, end = 12.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Fila de reprodução (${s.queue.size})",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = { saving = true }, enabled = s.queue.isNotEmpty()) {
                Icon(Icons.Rounded.Save, null, Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Salvar como playlist")
            }
        }
        Text(
            "Segure uma música e arraste para mudar a ordem. Deslize para o lado para tocar a seguir.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 24.dp),
        )
        Box(Modifier.fillMaxWidth()) {
            LazyColumn(
                state = listState,
                userScrollEnabled = dragFrom == null,
                modifier = Modifier
                    .fillMaxWidth()
                    .pointerInput(s.queue.size, s.queueIndex) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { pos ->
                                val i = indexAt(pos.y)
                                if (i != null) {
                                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                    dragFrom = i
                                    target = i
                                    fingerY = pos.y
                                }
                            },
                            onDrag = { change, amount ->
                                if (dragFrom != null) {
                                    change.consume()
                                    val h = listState.layoutInfo.viewportSize.height.toFloat()
                                    fingerY = (fingerY + amount.y).coerceIn(0f, h)
                                    indexAt(fingerY.coerceIn(0f, h - 1f))?.let { target = it }
                                }
                            },
                            onDragEnd = {
                                val f = dragFrom
                                val t = target
                                if (f != null && t != null && f != t) {
                                    vm.moveQueueItem(f, t.coerceIn(0, s.queue.size - 1))
                                }
                                dragFrom = null
                                target = null
                            },
                            onDragCancel = { dragFrom = null; target = null },
                        )
                    },
            ) {
                itemsIndexed(s.queue, key = { i, item -> "${item.mediaId}_$i" }) { i, item ->
                    val current = i == s.queueIndex
                    val isDragged = dragFrom == i
                    val isTarget = target == i && dragFrom != null && dragFrom != i
                    val swipe = rememberSwipeToDismissBoxState(
                        confirmValueChange = { value ->
                            if (value == SwipeToDismissBoxValue.StartToEnd && !current) {
                                val to = if (i < s.queueIndex) s.queueIndex else s.queueIndex + 1
                                vm.moveQueueItem(i, to.coerceIn(0, s.queue.size - 1))
                                Toast.makeText(context, "Vai tocar a seguir", Toast.LENGTH_SHORT).show()
                            }
                            false
                        },
                    )
                    SwipeToDismissBox(
                        state = swipe,
                        enableDismissFromEndToStart = false,
                        enableDismissFromStartToEnd = !current && dragFrom == null,
                        backgroundContent = {
                            Row(
                                Modifier.fillMaxSize().background(MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)).padding(start = 24.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(Icons.AutoMirrored.Rounded.QueueMusic, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Tocar a seguir", fontWeight = FontWeight.SemiBold)
                            }
                        },
                    ) {
                        QueueRow(
                            item = item,
                            current = current,
                            containerColor = when {
                                isTarget -> MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                                current -> MaterialTheme.colorScheme.primaryContainer
                                else -> MaterialTheme.colorScheme.surfaceContainerLow
                            },
                            modifier = Modifier
                                .graphicsLayer { alpha = if (isDragged) 0.3f else 1f }
                                .clickable { vm.playQueueIndex(i) },
                            onRemove = if (current) null else ({ vm.removeFromQueue(i) }),
                        )
                    }
                }
            }

            // A música "levantada" segue o dedo, mesmo quando a lista rola
            val from = dragFrom
            if (from != null && from in s.queue.indices) {
                val rowPx = with(density) { 64.dp.toPx() }
                QueueRow(
                    item = s.queue[from],
                    current = false,
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                    modifier = Modifier
                        .zIndex(2f)
                        .graphicsLayer {
                            translationY = fingerY - rowPx / 2
                            shadowElevation = 16f
                            scaleX = 1.02f
                            scaleY = 1.02f
                        }
                        .clip(RoundedCornerShape(12.dp)),
                    onRemove = null,
                )
            }
        }
    }

    if (saving) {
        NameDialog(
            title = "Salvar fila como playlist",
            initial = "",
            confirmLabel = "Salvar",
            onConfirm = { name ->
                vm.saveQueueAsPlaylist(name)
                saving = false
                Toast.makeText(context, "Playlist \"$name\" criada", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { saving = false },
        )
    }
}

@Composable
private fun QueueRow(
    item: androidx.media3.common.MediaItem,
    current: Boolean,
    containerColor: Color,
    modifier: Modifier,
    onRemove: (() -> Unit)?,
) {
    Row(
        modifier
            .fillMaxWidth()
            .height(64.dp)
            .background(containerColor)
            .padding(start = 16.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ArtImage(item.mediaMetadata.artworkUri, Modifier.size(42.dp))
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                item.mediaMetadata.title?.toString() ?: "",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = if (current) FontWeight.Bold else null,
            )
            Text(
                item.mediaMetadata.artist?.toString() ?: "",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (onRemove != null) {
            IconButton(onClick = onRemove) { Icon(Icons.Rounded.Close, "Remover da fila") }
        }
        Icon(Icons.Rounded.DragIndicator, "Segure para arrastar", Modifier.size(40.dp).padding(8.dp))
    }
}

@Composable
private fun SpeedDialog(current: Float, onSelect: (Float) -> Unit, onDismiss: () -> Unit) {
    val options = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
    OptionsDialog("Velocidade", options.map { formatSpeed(it) }, options.indexOf(current), { onSelect(options[it]) }, onDismiss)
}

@Composable
private fun SleepDialog(active: Boolean, atEnd: Boolean, onSelect: (Int?) -> Unit, onDismiss: () -> Unit) {
    // -1 = no fim desta música
    val minutes = listOf<Int?>(null, -1, 5, 10, 15, 30, 45, 60, 90)
    val labels = minutes.map {
        when (it) {
            null -> "Desligado"
            -1 -> "No fim desta música"
            else -> "$it minutos"
        }
    }
    OptionsDialog(
        "Parar a música depois de",
        labels,
        when {
            atEnd -> 1
            active -> -1
            else -> 0
        },
        { onSelect(minutes[it]) },
        onDismiss,
    )
}

@Composable
private fun OptionsDialog(
    title: String,
    labels: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                labels.forEachIndexed { i, label ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onSelect(i) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = i == selected, onClick = { onSelect(i) })
                        Text(label)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fechar") } },
    )
}


// ---------------- Modo de reprodução ----------------

fun currentPlayMode(s: PlayerUiState): PlayMode = when {
    s.repeatMode == Player.REPEAT_MODE_ONE -> PlayMode.ONE
    s.shuffle -> PlayMode.SHUFFLE
    s.repeatMode == Player.REPEAT_MODE_ALL -> PlayMode.ALL
    else -> PlayMode.ORDER
}

private fun PlayMode.icon(): ImageVector = when (this) {
    PlayMode.ONE -> Icons.Rounded.RepeatOne
    PlayMode.SHUFFLE -> Icons.Rounded.Shuffle
    PlayMode.ALL -> Icons.Rounded.Repeat
    PlayMode.ORDER -> Icons.AutoMirrored.Rounded.ArrowForward
}

/** Botão da esquerda: ao tocar, abre o menu com os modos de reprodução. */
@Composable
private fun PlayModeButton(current: PlayMode, accent: Color, onSelect: (PlayMode) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val active = current != PlayMode.ORDER
    val bg by animateColorAsState(
        if (active) accent.copy(alpha = 0.22f) else Color.Transparent,
        label = "modeBg",
    )
    Box {
        BouncyIconButton(
            onClick = { open = true },
            modifier = Modifier.clip(CircleShape).background(bg),
        ) {
            Crossfade(targetState = current, label = "modeIcon") { mode ->
                Icon(
                    mode.icon(),
                    "Modo de reprodução: ${mode.label}",
                    tint = if (active) accent else Color.White.copy(alpha = 0.6f),
                )
            }
        }
        DropdownMenu(
            expanded = open,
            onDismissRequest = { open = false },
            shape = RoundedCornerShape(16.dp),
        ) {
            Text(
                "Modo de reprodução",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            )
            listOf(PlayMode.ONE, PlayMode.SHUFFLE, PlayMode.ALL, PlayMode.ORDER).forEach { mode ->
                val selected = mode == current
                DropdownMenuItem(
                    leadingIcon = { Icon(mode.icon(), null, tint = if (selected) accent else MaterialTheme.colorScheme.onSurface) },
                    text = {
                        Text(
                            mode.label,
                            color = if (selected) accent else MaterialTheme.colorScheme.onSurface,
                            fontWeight = if (selected) FontWeight.SemiBold else null,
                        )
                    },
                    trailingIcon = { if (selected) Icon(Icons.Rounded.Check, null, tint = accent) },
                    onClick = {
                        onSelect(mode)
                        open = false
                    },
                    modifier = if (selected) Modifier.background(accent.copy(alpha = 0.15f)) else Modifier,
                )
            }
        }
    }
}

@Composable
private fun PlayerToolButton(
    icon: ImageVector,
    label: String,
    active: Boolean,
    accent: Color,
    onClick: () -> Unit,
) {
    val tint = if (active) accent else Color.White.copy(alpha = 0.75f)
    Column(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(20.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = tint, maxLines = 1)
    }
}
