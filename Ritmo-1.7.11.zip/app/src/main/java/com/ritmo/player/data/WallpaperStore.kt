package com.ritmo.player.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Copia a foto escolhida para dentro do app (reduzida), para usar como papel de parede. */
object WallpaperStore {

    private const val KEEP = 6

    /** Guarda a foto nova e mantém só as últimas imagens usadas. */
    suspend fun save(context: Context, source: Uri): String? {
        val path = saveImage(context, source, "wallpaper_${System.currentTimeMillis()}.jpg", 1080)
        recent(context).drop(KEEP).forEach { it.delete() }
        return path
    }

    /** Imagens já usadas como papel de parede, da mais nova para a mais antiga. */
    fun recent(context: Context): List<File> =
        context.filesDir.listFiles { f -> f.name.startsWith("wallpaper_") }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()

    /** Marca uma imagem como usada agora (para ela ir para o começo da lista). */
    fun touch(file: File) {
        file.setLastModified(System.currentTimeMillis())
    }

    fun delete(path: String) {
        File(path).takeIf { it.name.startsWith("wallpaper_") }?.delete()
    }

    /** Copia uma imagem para dentro do app, reduzida para no máximo [maxSide] pixels. */
    suspend fun saveImage(
        context: Context,
        source: Uri,
        fileName: String,
        maxSide: Int,
        onBeforeWrite: () -> Unit = {},
    ): String? = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(source)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= maxSide && bounds.outHeight / (sample * 2) >= maxSide) sample *= 2
            val bitmap = resolver.openInputStream(source)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return@runCatching null
            onBeforeWrite()
            val file = File(context.filesDir, fileName)
            file.parentFile?.mkdirs()
            file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            file.absolutePath
        }.getOrNull()
    }

    fun clear(context: Context) {
        context.filesDir.listFiles { f -> f.name.startsWith("wallpaper_") }?.forEach { it.delete() }
    }
}
