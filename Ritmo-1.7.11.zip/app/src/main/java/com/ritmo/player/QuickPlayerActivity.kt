package com.ritmo.player

import android.Manifest
import android.content.ComponentName
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.SaveAlt
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.ritmo.player.data.SettingsStore
import com.ritmo.player.playback.PlaybackService
import com.ritmo.player.ui.theme.RitmoTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Player rápido: abre por cima do WhatsApp (ou de outro app) quando você escolhe
 * "Abrir com Ritmo" ou compartilha um áudio com o Ritmo.
 */
class QuickPlayerActivity : ComponentActivity() {

    companion object {
        const val EXTRA_PATH = "com.ritmo.player.EXTRA_PATH"
        const val EXTRA_TITLE = "com.ritmo.player.EXTRA_TITLE"
        private val SPEEDS = listOf(1f, 1.5f, 2f)
    }

    private var player: ExoPlayer? = null
    private var mainController: MediaController? = null
    private var resumeMainOnExit = false
    private var handedOff = false
    private var audioUri: Uri? = null
    private var title by mutableStateOf("Áudio")
    private var saving by mutableStateOf(false)
    private var pendingSave: (() -> Unit)? = null

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val action = pendingSave
        pendingSave = null
        if (ok) action?.invoke() else toast("Sem permissão para salvar")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = extractUri(intent)
        if (uri == null) {
            toast("Não consegui abrir esse áudio")
            finish()
            return
        }
        audioUri = uri
        title = displayName(uri)

        // Pausa a música do Ritmo enquanto o áudio toca (volta depois)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            val c = runCatching { future.get() }.getOrNull() ?: return@addListener
            mainController = c
            if (c.isPlaying) {
                resumeMainOnExit = true
                c.pause()
            }
        }, ContextCompat.getMainExecutor(this))

        player = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_SPEECH).build(),
                false,
            )
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            play()
        }

        setContent {
            val settings by SettingsStore.get(this).settings.collectAsStateWithLifecycle()
            RitmoTheme(settings) {
                QuickPlayerUi()
            }
        }
    }

    @Composable
    private fun QuickPlayerUi() {
        val p = player ?: return
        var isPlaying by remember { mutableStateOf(true) }
        var position by remember { mutableLongStateOf(0L) }
        var duration by remember { mutableLongStateOf(0L) }
        var seeking by remember { mutableStateOf(false) }
        var seekValue by remember { mutableFloatStateOf(0f) }
        var speedIndex by remember { mutableStateOf(0) }

        LaunchedEffect(Unit) {
            while (true) {
                isPlaying = p.isPlaying || (p.playWhenReady && p.playbackState == Player.STATE_BUFFERING)
                if (!seeking) position = p.currentPosition
                duration = p.duration.takeIf { it > 0 } ?: 0L
                if (p.playbackState == Player.STATE_ENDED && p.playWhenReady) {
                    p.pause()
                    p.seekTo(0)
                }
                delay(200)
            }
        }

        val primary = MaterialTheme.colorScheme.primary
        Box(
            Modifier
                .fillMaxSize()
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { finish() },
            contentAlignment = Alignment.BottomCenter,
        ) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                tonalElevation = 6.dp,
                shadowElevation = 12.dp,
                modifier = Modifier
                    .navigationBarsPadding()
                    .padding(12.dp)
                    .fillMaxWidth()
                    // Toques no cartão não fecham a janela
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(46.dp).clip(CircleShape).background(primary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Rounded.GraphicEq, null, tint = primary)
                        }
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${fmt(position)} / ${fmt(duration)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        IconButton(onClick = { finish() }) { Icon(Icons.Rounded.Close, "Fechar") }
                    }

                    Slider(
                        value = if (seeking) seekValue else if (duration > 0) position.toFloat() / duration else 0f,
                        onValueChange = { seeking = true; seekValue = it },
                        onValueChangeFinished = {
                            p.seekTo((seekValue * duration).toLong())
                            position = (seekValue * duration).toLong()
                            seeking = false
                        },
                        colors = SliderDefaults.colors(thumbColor = primary, activeTrackColor = primary),
                    )

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconButton(onClick = { p.seekTo((p.currentPosition - 10_000).coerceAtLeast(0)) }) {
                            Icon(Icons.Rounded.Replay10, "Voltar 10 segundos")
                        }
                        Box(
                            Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(primary)
                                .clickable { if (p.isPlaying) p.pause() else p.play() },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                if (isPlaying) "Pausar" else "Tocar",
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(32.dp),
                            )
                        }
                        IconButton(onClick = { p.seekTo((p.currentPosition + 10_000).coerceAtMost(p.duration.coerceAtLeast(0))) }) {
                            Icon(Icons.Rounded.Forward10, "Avançar 10 segundos")
                        }
                        Text(
                            "${SPEEDS[speedIndex].let { if (it == 1f) "1" else it.toString() }}x",
                            fontWeight = FontWeight.Bold,
                            color = primary,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(primary.copy(alpha = 0.18f))
                                .clickable {
                                    speedIndex = (speedIndex + 1) % SPEEDS.size
                                    p.playbackParameters = PlaybackParameters(SPEEDS[speedIndex])
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                        )
                    }

                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilledTonalButton(onClick = { openInRitmo() }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Rounded.OpenInNew, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Abrir no Ritmo", maxLines = 1)
                        }
                        FilledTonalButton(onClick = { save() }, enabled = !saving, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Rounded.SaveAlt, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (saving) "Salvando…" else "Salvar", maxLines = 1)
                        }
                    }
                }
            }
        }
    }

    // ---------------- Ações ----------------

    /** Copia o áudio para dentro do app e toca no player completo do Ritmo. */
    private fun openInRitmo() {
        val uri = audioUri ?: return
        lifecycleScope.launch {
            val file = withContext(Dispatchers.IO) { copyToCache(uri) }
            if (file == null) {
                toast("Não consegui abrir no Ritmo")
                return@launch
            }
            handedOff = true
            player?.pause()
            startActivity(
                Intent(this@QuickPlayerActivity, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra(EXTRA_PATH, file.absolutePath)
                    .putExtra(EXTRA_TITLE, title)
            )
            finish()
        }
    }

    /** Salva uma cópia em Música/Ritmo para aparecer na biblioteca. */
    private fun save() {
        val uri = audioUri ?: return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingSave = { save() }
            permissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        saving = true
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { saveToMusic(uri) }.getOrDefault(false) }
            saving = false
            toast(if (ok) "Salvo em Música/Ritmo" else "Não foi possível salvar")
        }
    }

    private fun saveToMusic(source: Uri): Boolean {
        val name = fileName(source)
        val mime = contentResolver.getType(source) ?: "audio/*"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, name)
                put(MediaStore.Audio.Media.MIME_TYPE, mime)
                put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/Ritmo")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val target = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            contentResolver.openOutputStream(target)?.use { out ->
                contentResolver.openInputStream(source)?.use { it.copyTo(out) } ?: return false
            } ?: return false
            values.clear()
            values.put(MediaStore.Audio.Media.IS_PENDING, 0)
            contentResolver.update(target, values, null, null)
            true
        } else {
            @Suppress("DEPRECATION")
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), "Ritmo").apply { mkdirs() }
            var file = File(dir, name)
            var n = 1
            while (file.exists()) {
                file = File(dir, name.substringBeforeLast('.') + " ($n)." + name.substringAfterLast('.', "mp3"))
                n++
            }
            file.outputStream().use { out -> contentResolver.openInputStream(source)?.use { it.copyTo(out) } ?: return false }
            android.media.MediaScannerConnection.scanFile(this, arrayOf(file.path), null, null)
            true
        }
    }

    private fun copyToCache(source: Uri): File? = runCatching {
        val dir = File(cacheDir, "audios_de_fora").apply { mkdirs() }
        // Guarda só os últimos áudios para não encher o celular
        dir.listFiles()?.sortedByDescending { it.lastModified() }?.drop(10)?.forEach { it.delete() }
        val file = File(dir, "${System.currentTimeMillis()}_${fileName(source)}")
        file.outputStream().use { out -> contentResolver.openInputStream(source)?.use { it.copyTo(out) } ?: return null }
        file
    }.getOrNull()

    // ---------------- Ajudantes ----------------

    @Suppress("DEPRECATION")
    private fun extractUri(intent: Intent?): Uri? = when (intent?.action) {
        Intent.ACTION_VIEW -> intent.data
        Intent.ACTION_SEND -> if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            intent.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri
        } ?: intent.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
        else -> null
    }

    private fun fileName(uri: Uri): String {
        val raw = runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/') ?: "audio"
        val clean = raw.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        return if ('.' in clean) clean else "$clean.${extensionFor(uri)}"
    }

    private fun extensionFor(uri: Uri): String = when (contentResolver.getType(uri)) {
        "audio/ogg", "application/ogg", "audio/opus" -> "opus"
        "audio/mp4", "audio/m4a", "audio/aac" -> "m4a"
        "audio/wav", "audio/x-wav" -> "wav"
        else -> "mp3"
    }

    /** Nome bonito para mostrar: mensagens de voz do WhatsApp viram "Áudio do WhatsApp". */
    private fun displayName(uri: Uri): String {
        val name = fileName(uri)
        val base = name.substringBeforeLast('.')
        return when {
            name.startsWith("PTT-", ignoreCase = true) || name.endsWith(".opus", ignoreCase = true) -> "Áudio do WhatsApp"
            else -> base.ifBlank { "Áudio" }
        }
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        player?.release()
        player = null
        // Volta a música do Ritmo de onde parou (a não ser que o áudio foi para o player completo)
        if (resumeMainOnExit && !handedOff) mainController?.play()
        mainController?.release()
        mainController = null
        super.onDestroy()
    }
}
