package com.ritmo.player.data

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.File

data class SongEdit(
    val title: String? = null,
    val artist: String? = null,
    val album: String? = null,
    val coverPath: String? = null,
)

/** Edições de nome, artista, álbum e capa. Ficam só dentro do Ritmo (o arquivo original não muda). */
class SongEditsStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("song_edits", Context.MODE_PRIVATE)
    private var edits: Map<Long, SongEdit> = load()

    fun get(id: Long): SongEdit? = edits[id]

    fun apply(songs: List<Song>): List<Song> = songs.map { s ->
        val e = edits[s.id] ?: return@map s
        s.copy(
            title = e.title?.takeIf { it.isNotBlank() } ?: s.title,
            artist = e.artist?.takeIf { it.isNotBlank() } ?: s.artist,
            album = e.album?.takeIf { it.isNotBlank() } ?: s.album,
            customArt = e.coverPath?.let { File(it) }?.takeIf { it.exists() }?.let { Uri.fromFile(it) },
        )
    }

    fun save(id: Long, edit: SongEdit) {
        edits = edits + (id to edit)
        persist()
    }

    fun clear(id: Long) {
        edits[id]?.coverPath?.let { File(it).delete() }
        edits = edits - id
        persist()
    }

    private fun persist() {
        val o = JSONObject()
        edits.forEach { (id, e) ->
            o.put(id.toString(), JSONObject().apply {
                e.title?.let { put("t", it) }
                e.artist?.let { put("ar", it) }
                e.album?.let { put("al", it) }
                e.coverPath?.let { put("c", it) }
            })
        }
        prefs.edit().putString("data", o.toString()).apply()
    }

    private fun load(): Map<Long, SongEdit> = runCatching {
        val o = JSONObject(prefs.getString("data", "{}") ?: "{}")
        o.keys().asSequence().associate { key ->
            val e = o.getJSONObject(key)
            key.toLong() to SongEdit(
                title = e.optString("t").ifEmpty { null },
                artist = e.optString("ar").ifEmpty { null },
                album = e.optString("al").ifEmpty { null },
                coverPath = e.optString("c").ifEmpty { null },
            )
        }
    }.getOrDefault(emptyMap())
}
