package com.ritmo.player.ui

import android.os.Build
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Speaker
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.data.FAVORITES_ID
import com.ritmo.player.data.MusicRepository
import com.ritmo.player.data.SettingsStore
import com.ritmo.player.playback.AudioEffects

// ======================= Configurações novas da 1.8 =======================

@Composable
private fun SwitchItem(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(subtitle) },
        trailingContent = { Switch(checked = checked, onCheckedChange = onChange) },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
    )
}

/** Em Configurações → Animações. */
@Composable
fun AnimationExtras18(vm: MainViewModel) {
    val s by vm.settingsStore.settings.collectAsStateWithLifecycle()
    SwitchItem(
        "Capa pula na batida",
        "A capa dá um pulinho a cada grave (precisa das barras que dançam ligadas)",
        s.beatPulse,
    ) { on -> vm.settingsStore.update { it.copy(beatPulse = on) } }
    SwitchItem(
        "Relógio no carregador",
        "Celular deitado e carregando, com música tocando, vira um relógio com a capa",
        s.chargerClock,
    ) { on -> vm.settingsStore.update { it.copy(chargerClock = on) } }
}

/** Em Configurações → Biblioteca. */
@Composable
fun LibraryExtras18(vm: MainViewModel) {
    val s by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val online by vm.online.collectAsStateWithLifecycle()
    SwitchItem(
        "Separar artistas juntos",
        "\"A, B feat. C\" aparece em cada artista (o arquivo não muda)",
        s.splitArtists,
    ) { on -> vm.settingsStore.update { it.copy(splitArtists = on) } }
    SwitchItem(
        "Buscar letra na internet",
        "Quando a música não tem letra, procura a sincronizada (LRCLIB)",
        s.autoLyrics,
    ) { on -> vm.settingsStore.update { it.copy(autoLyrics = on) } }
    SwitchItem(
        "Buscar capa na internet",
        "Quando a música não tem capa, procura uma (Apple Music / Deezer)",
        s.autoCovers,
    ) { on -> vm.settingsStore.update { it.copy(autoCovers = on) } }
    SwitchItem(
        "Buscar só no Wi-Fi",
        "Não gasta seus dados móveis",
        s.onlineWifiOnly,
    ) { on -> vm.settingsStore.update { it.copy(onlineWifiOnly = on) } }

    val o = online
    Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
        when {
            o == null -> OutlinedButton(
                onClick = { vm.fetchAllOnline() },
                enabled = s.autoLyrics || s.autoCovers,
            ) { Text("Buscar letra e capa para todas") }
            !o.finished -> {
                Text("Procurando… ${o.done} de ${o.total}", style = MaterialTheme.typography.bodyMedium)
                LinearProgressIndicator(
                    progress = { if (o.total > 0) o.done.toFloat() / o.total else 0f },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                )
                Text(
                    "${o.lyrics} letras e ${o.covers} capas encontradas até agora",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                TextButton(onClick = { vm.cancelOnline() }) { Text("Parar") }
            }
            else -> {
                Text(
                    "Pronto: ${o.lyrics} letras e ${o.covers} capas novas",
                    style = MaterialTheme.typography.bodyMedium,
                )
                TextButton(onClick = { vm.cancelOnline() }) { Text("OK") }
            }
        }
    }
}

// ======================= Equalizador por fone =======================

@Composable
fun PerDeviceEqSection() {
    val context = LocalContext.current
    val store = remember { SettingsStore.get(context) }
    val s by store.settings.collectAsStateWithLifecycle()
    val output by AudioEffects.output.collectAsStateWithLifecycle()
    var refresh by remember { mutableIntStateOf(0) }
    val saved = remember(refresh, output) { AudioEffects.savedProfiles(context) }

    Text(
        "Por fone",
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 4.dp),
    )
    SwitchItem(
        "Um ajuste para cada fone",
        "Lembra o ajuste de cada fone e do alto-falante, e troca sozinho ao conectar",
        s.eqPerDevice,
    ) { on ->
        store.update { it.copy(eqPerDevice = on) }
        AudioEffects.setPerDevice(context, on)
        refresh++
    }
    if (s.eqPerDevice) {
        output?.let { out ->
            Text(
                "Agora: ${out.label}",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            )
        }
        saved.forEach { p ->
            ListItem(
                leadingContent = {
                    Icon(
                        when {
                            p.key.startsWith("bt:") -> Icons.Rounded.Bluetooth
                            p.key == "wired" -> Icons.Rounded.Headphones
                            else -> Icons.Rounded.Speaker
                        },
                        null,
                    )
                },
                headlineContent = { Text(p.label) },
                supportingContent = { Text(if (p.key == output?.key) "Em uso" else "Ajuste guardado") },
                trailingContent = {
                    if (p.key != output?.key) {
                        IconButton(onClick = { AudioEffects.forgetProfile(context, p.key); refresh++ }) {
                            Icon(Icons.Rounded.Close, "Esquecer")
                        }
                    }
                },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
            )
        }
    }
}

// ======================= Lixeira =======================

@Composable
fun TrashScreen(vm: MainViewModel, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val actions = rememberMediaActions(vm)
    var items by remember { mutableStateOf<List<MusicRepository.TrashedSong>?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(reload) { items = vm.loadTrashed() }
    var confirmEmpty by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        SimpleTopBar("Lixeira", onBack = onBack, actions = {
            val list = items.orEmpty()
            if (list.isNotEmpty()) {
                TextButton(onClick = { confirmEmpty = true }) {
                    Text("Esvaziar", color = MaterialTheme.colorScheme.error)
                }
            }
        })
        val list = items
        when {
            Build.VERSION.SDK_INT < Build.VERSION_CODES.R ->
                EmptyMessage("A lixeira precisa do Android 11 ou mais novo. Neste celular, apagar é direto.")
            list == null -> Box(Modifier.fillMaxSize())
            list.isEmpty() -> EmptyMessage("A lixeira está vazia. Músicas apagadas ficam aqui por 30 dias.")
            else -> {
                Text(
                    "Somem de vez depois de 30 dias",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                LazyColumn(Modifier.fillMaxSize()) {
                    items(list, key = { it.id }) { t ->
                        val days = ((t.expiresAt * 1000 - System.currentTimeMillis()) / 86_400_000L).coerceAtLeast(0)
                        ListItem(
                            headlineContent = { Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            supportingContent = {
                                Text("${t.artist} · ${if (days <= 1) "some amanhã" else "$days dias"}", maxLines = 1, overflow = TextOverflow.Ellipsis)
                            },
                            trailingContent = {
                                Row {
                                    IconButton(onClick = { actions.restore(listOf(t.uri)) { reload++ } }) {
                                        Icon(Icons.Rounded.Restore, "Restaurar", tint = MaterialTheme.colorScheme.primary)
                                    }
                                    IconButton(onClick = { actions.deleteForever(listOf(t.uri)) { reload++ } }) {
                                        Icon(Icons.Rounded.Delete, "Apagar de vez", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            },
                        )
                    }
                }
            }
        }
    }
    if (confirmEmpty) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmEmpty = false },
            title = { Text("Esvaziar a lixeira?") },
            text = { Text("As músicas serão apagadas de vez. Isso não pode ser desfeito.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmEmpty = false
                    actions.deleteForever(items.orEmpty().map { it.uri }) { reload++ }
                }) { Text("Esvaziar", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmEmpty = false }) { Text("Cancelar") } },
        )
    }
}

// ======================= Modo carro =======================

@Composable
fun CarModeScreen(vm: MainViewModel, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val s by vm.player.collectAsStateWithLifecycle()
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val playlists by vm.playlistStore.playlists.collectAsStateWithLifecycle()
    val songs by vm.songs.collectAsStateWithLifecycle()
    val output by AudioEffects.output.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val songId = s.mediaId?.toLongOrNull()
    val isFavorite = songId != null &&
        playlists.firstOrNull { it.id == FAVORITES_ID }?.songIds?.contains(songId) == true

    // Tela sempre acesa no modo carro
    DisposableEffect(Unit) {
        val window = (context as? ComponentActivity)?.window
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    Column(
        Modifier.fillMaxSize().background(Color(0xFF0E0F13)).verticalScroll(rememberScrollState()).padding(20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.DirectionsCar, null, tint = Color.White)
            Spacer(Modifier.width(10.dp))
            Text("Modo carro", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onBack) { Text("Sair", color = Color.White, fontSize = 18.sp) }
        }
        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            ArtImage(s.artUri, Modifier.size(96.dp).clip(RoundedCornerShape(16.dp)), corner = 16.dp)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    s.title.ifBlank { "Nada tocando" },
                    color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
                Text(s.artist, color = Color.White.copy(alpha = 0.65f), fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Spacer(Modifier.height(28.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BigCarButton(Icons.Rounded.SkipPrevious, "Anterior", Color(0xFF2C2B33), Modifier.weight(1f)) { vm.previous() }
            BigCarButton(
                if (s.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                if (s.isPlaying) "Pausar" else "Tocar",
                MaterialTheme.colorScheme.primary,
                Modifier.weight(1f),
            ) { if (s.hasMedia) vm.togglePlay() else vm.shuffleAll(songs) }
            BigCarButton(Icons.Rounded.SkipNext, "Próxima", Color(0xFF2C2B33), Modifier.weight(1f)) { vm.next() }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            WideCarButton(
                if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                if (isFavorite) "Curtida" else "Curtir",
                Modifier.weight(1f),
            ) { songId?.let { vm.toggleFavorite(it) } }
            WideCarButton(Icons.Rounded.Shuffle, "Aleatório", Modifier.weight(1f)) { vm.shuffleAll(songs) }
        }

        // Bluetooth do carro: abre o modo carro sozinho ao conectar (com o app aberto)
        Spacer(Modifier.height(28.dp))
        val bt = output?.takeIf { it.key.startsWith("bt:") }
        if (bt != null && bt.label !in settings.carDevices) {
            OutlinedButton(onClick = { vm.settingsStore.update { it.copy(carDevices = it.carDevices + bt.label) } }) {
                Text("Marcar \"${bt.label}\" como carro", color = Color.White)
            }
            Text(
                "Quando conectar nele com o Ritmo aberto, o modo carro abre sozinho",
                color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
        settings.carDevices.forEach { name ->
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                Icon(Icons.Rounded.Bluetooth, null, tint = Color.White.copy(alpha = 0.7f))
                Spacer(Modifier.width(8.dp))
                Text("$name (carro)", color = Color.White.copy(alpha = 0.8f), modifier = Modifier.weight(1f))
                IconButton(onClick = { vm.settingsStore.update { it.copy(carDevices = it.carDevices - name) } }) {
                    Icon(Icons.Rounded.Close, "Desmarcar", tint = Color.White.copy(alpha = 0.7f))
                }
            }
        }
    }
}

@Composable
private fun BigCarButton(icon: ImageVector, label: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .height(120.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(color)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, label, Modifier.size(56.dp), tint = Color.White)
    }
}

@Composable
private fun WideCarButton(icon: ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier
            .height(72.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF2C2B33))
            .clickable(onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, Modifier.size(28.dp), tint = Color.White)
        Spacer(Modifier.width(10.dp))
        Text(label, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
}
