package com.ritmo.player.playback

import android.content.ComponentName
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken

/** Botão do Ritmo no painel rápido: tocar/pausar sem abrir o app. */
class RitmoTileService : TileService() {

    override fun onStartListening() {
        updateTile()
    }

    override fun onClick() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            val c = runCatching { future.get() }.getOrNull() ?: return@addListener
            if (c.isPlaying) {
                c.pause()
            } else if (c.mediaItemCount > 0) {
                c.prepare()
                c.play()
            } else {
                // Nada na fila: pede ao Ritmo para continuar a última música
                WidgetUpdater.sendPlayPause(this)
            }
            updateTile()
            c.release()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun updateTile() {
        val tile = qsTile ?: return
        tile.state = if (WidgetUpdater.isPlaying) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "Ritmo"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = WidgetUpdater.currentTitle ?: "Tocar"
        }
        tile.updateTile()
    }
}
