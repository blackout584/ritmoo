package com.ritmo.player.update

import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.ritmo.player.data.SettingsStore
import com.ritmo.player.data.UpdateInfo
import com.ritmo.player.data.Updater
import kotlinx.coroutines.runBlocking

/**
 * Aviso instantâneo (Firebase): o GitHub manda um recado quando o APK fica pronto
 * e o Ritmo mostra a notificação na hora, mesmo fechado.
 * Só funciona depois que o Firebase é configurado; sem ele, nada aqui roda.
 */
class RitmoMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(message: RemoteMessage) {
        val data = message.data
        if (data["type"] != "update") return
        if (!SettingsStore.get(this).settings.value.autoUpdateCheck) return
        val version = data["version"].orEmpty()
        val installed = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }.getOrNull()
        if (version.isNotBlank() && version == installed) return

        // Confere no GitHub para pegar o link certo; se não der, usa o que veio no recado
        val info = runBlocking { Updater.fetchLatest() }
            ?: data["url"]?.let { UpdateInfo("Ritmo $version", it, System.currentTimeMillis()) }
            ?: return
        UpdateNotifier.notifyIfNew(this, info)
    }

    override fun onNewToken(token: String) {
        subscribe()
    }

    companion object {
        /** Entra no canal "updates". Sem Firebase configurado, não faz nada. */
        fun subscribe() {
            runCatching { FirebaseMessaging.getInstance().subscribeToTopic("updates") }
        }
    }
}
