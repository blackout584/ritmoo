package com.ritmo.player.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.ritmo.player.data.Song
import com.ritmo.player.data.SongEdit
import com.ritmo.player.data.WallpaperStore
import kotlinx.coroutines.launch
import java.io.File

/** Editar nome, artista, álbum e capa. Muda só dentro do Ritmo; o arquivo original continua igual. */
@Composable
fun EditSongDialog(vm: MainViewModel, song: Song, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val existing = remember(song.id) { vm.editsStore.get(song.id) }
    var title by remember { mutableStateOf(song.title) }
    var artist by remember { mutableStateOf(song.artist) }
    var album by remember { mutableStateOf(song.album) }
    var coverPath by remember { mutableStateOf(existing?.coverPath) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val path = WallpaperStore.saveImage(
                context, uri, "covers/cover_${song.id}_${System.currentTimeMillis()}.jpg", 600,
            )
            if (path != null) coverPath = path
        }
    }
    val preview: Uri? = coverPath?.let { File(it) }?.takeIf { it.exists() }?.let { Uri.fromFile(it) } ?: song.artUri

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Editar música") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ArtImage(preview, Modifier.size(72.dp), corner = 12.dp)
                    Spacer(Modifier.width(12.dp))
                    OutlinedButton(onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) { Text("Trocar capa") }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(title, { title = it }, label = { Text("Nome") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(artist, { artist = it }, label = { Text("Artista") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(album, { album = it }, label = { Text("Álbum") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text(
                    "As mudanças aparecem só no Ritmo. O arquivo da música não é alterado.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (existing != null) {
                    TextButton(onClick = { vm.clearEdit(song); onDismiss() }) { Text("Restaurar original") }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.saveEdit(song, SongEdit(title.trim(), artist.trim(), album.trim(), coverPath))
                onDismiss()
            }) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
