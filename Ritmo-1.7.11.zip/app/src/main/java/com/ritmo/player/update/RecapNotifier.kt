package com.ritmo.player.update

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.ritmo.player.MainActivity
import com.ritmo.player.R
import com.ritmo.player.data.MonthlyStatsStore
import java.util.Calendar

/** No dia 1 (a partir das 9h) avisa que a retrospectiva do mês que passou chegou. Uma vez por mês. */
object RecapNotifier {
    const val ACTION_OPEN_RECAP = "com.ritmo.player.OPEN_RECAP"
    const val EXTRA_MONTH = "com.ritmo.player.EXTRA_MONTH"
    private const val CHANNEL = "recap"
    private const val NOTIFICATION_ID = 4301

    fun checkAndNotify(context: Context) {
        val now = Calendar.getInstance()
        if (now.get(Calendar.DAY_OF_MONTH) > 7) return
        if (now.get(Calendar.DAY_OF_MONTH) == 1 && now.get(Calendar.HOUR_OF_DAY) < 9) return
        val month = MonthlyStatsStore.previousMonthKey()
        val prefs = context.getSharedPreferences("recap_notifier", Context.MODE_PRIVATE)
        if (prefs.getString("last", null) == month) return
        val stats = MonthlyStatsStore.get(context).months.value[month] ?: return
        if (stats.plays == 0) return
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, "Retrospectiva do mês", NotificationManager.IMPORTANCE_DEFAULT).apply {
                        description = "Avisa no dia 1 o que você mais ouviu no mês que passou"
                    }
                )
            }
        }
        val open = PendingIntent.getActivity(
            context, 3,
            Intent(context, MainActivity::class.java)
                .setAction(ACTION_OPEN_RECAP)
                .putExtra(EXTRA_MONTH, month)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val name = MonthlyStatsStore.label(month).substringBefore(" de ")
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_tile_note)
            .setContentTitle(
                com.ritmo.player.data.SettingsStore.get(context).settings.value.userName
                    .takeIf { it.isNotBlank() }?.let { "$it, sua retrospectiva de $name chegou" }
                    ?: "Sua retrospectiva de $name chegou"
            )
            .setContentText("Veja as músicas que mais tocaram no mês")
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification) }
        prefs.edit().putString("last", month).apply()
    }
}
