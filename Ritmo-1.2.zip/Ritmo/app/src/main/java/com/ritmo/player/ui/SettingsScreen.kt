package com.ritmo.player.ui

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.data.ThemeMode
import com.ritmo.player.ui.theme.accentColors
import com.ritmo.player.ui.theme.accentNames
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val songs by vm.songs.collectAsStateWithLifecycle()
    var minDuration by remember(settings.minDurationSec) { mutableFloatStateOf(settings.minDurationSec.toFloat()) }
    val dynamicAvailable = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    Column(Modifier.fillMaxSize()) {
        SimpleTopBar("Ajustes")
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {

            SectionTitle("Aparência")
            Text("Tema", Modifier.padding(horizontal = 16.dp))
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf(ThemeMode.SYSTEM to "Sistema", ThemeMode.LIGHT to "Claro", ThemeMode.DARK to "Escuro")
                    .forEach { (mode, label) ->
                        FilterChip(
                            selected = settings.themeMode == mode,
                            onClick = { vm.settingsStore.update { it.copy(themeMode = mode) } },
                            label = { Text(label) },
                        )
                    }
            }

            if (dynamicAvailable) {
                ListItem(
                    headlineContent = { Text("Cores do papel de parede") },
                    supportingContent = { Text("Usa as cores do seu celular (Material You)") },
                    trailingContent = {
                        Switch(
                            checked = settings.dynamicColor,
                            onCheckedChange = { on -> vm.settingsStore.update { it.copy(dynamicColor = on) } },
                        )
                    },
                )
            }

            if (!dynamicAvailable || !settings.dynamicColor) {
                Text("Cor de destaque", Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                Row(
                    Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    accentColors.forEachIndexed { i, color ->
                        val selected = settings.accent == i
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).background(color)
                                .border(
                                    width = if (selected) 3.dp else 0.dp,
                                    color = if (selected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                    shape = CircleShape,
                                )
                                .clickable { vm.settingsStore.update { it.copy(accent = i) } },
                            contentAlignment = Alignment.Center,
                        ) {
                            if (selected) Icon(Icons.Rounded.Check, accentNames[i], tint = Color.White)
                        }
                    }
                }
            }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            SectionTitle("Animações")
            ListItem(
                headlineContent = { Text("Barras que dançam") },
                supportingContent = { Text("Barras que pulam com o som na tela do player. Precisa da permissão de microfone, mas nada é gravado.") },
                trailingContent = {
                    Switch(
                        checked = settings.visualizer,
                        onCheckedChange = { on -> vm.settingsStore.update { it.copy(visualizer = on) } },
                    )
                },
            )
            ListItem(
                headlineContent = { Text("Capa em formato de disco") },
                supportingContent = { Text("A capa gira como um disco de vinil enquanto a música toca") },
                trailingContent = {
                    Switch(
                        checked = settings.vinylArt,
                        onCheckedChange = { on -> vm.settingsStore.update { it.copy(vinylArt = on) } },
                    )
                },
            )

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            SectionTitle("Biblioteca")
            Text(
                "Ignorar áudios com menos de ${minDuration.roundToInt()} segundos",
                Modifier.padding(horizontal = 16.dp),
            )
            Text(
                "Evita que toques de notificação e áudios do WhatsApp apareçam como música.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            Slider(
                value = minDuration,
                onValueChange = { minDuration = it },
                onValueChangeFinished = { vm.setMinDuration(minDuration.roundToInt()) },
                valueRange = 0f..120f,
                steps = 23,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            OutlinedButton(
                onClick = { vm.loadLibrary(force = true) },
                modifier = Modifier.padding(horizontal = 16.dp),
            ) { Text("Atualizar biblioteca (${songs.size} músicas)") }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            SectionTitle("Sobre")
            Text(
                "Ritmo 1.2 — player de música gratuito, sem anúncios.",
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
    )
}
