package com.ritmo.player.playback

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.os.Build
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class EqState(
    val available: Boolean = false,
    val enabled: Boolean = false,
    val bandFreqsHz: List<Int> = emptyList(),
    val bandLevels: List<Int> = emptyList(), // em milibéis (100 = 1 dB)
    val minLevel: Int = -1500,
    val maxLevel: Int = 1500,
    val presets: List<String> = emptyList(),
    val currentPreset: Int = -1, // -1 = personalizado
    val bassStrength: Int = 0,
    val bassSupported: Boolean = false,
    val virtualizerStrength: Int = 0,
    val virtualizerSupported: Boolean = false,
    val normalize: Boolean = false,
    val normalizeSupported: Boolean = false,
)

/** Equalizador, reforço de graves e som 3D. As configurações são salvas automaticamente. */
object AudioEffects {
    private var prefs: SharedPreferences? = null
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    private var virt: Virtualizer? = null
    private var dynamics: DynamicsProcessing? = null
    private var sessionId = 0

    private val _sessionId = MutableStateFlow(0)
    /** Sessão de áudio atual (usada também pelas barras que dançam). */
    val sessionIdFlow: StateFlow<Int> = _sessionId.asStateFlow()

    private val _state = MutableStateFlow(EqState())
    val state: StateFlow<EqState> = _state.asStateFlow()

    fun attach(context: Context, audioSessionId: Int) {
        if (audioSessionId == 0) return
        if (audioSessionId == sessionId && eq != null) return
        release()
        sessionId = audioSessionId
        appContext = context.applicationContext
        prefs = context.applicationContext.getSharedPreferences("effects", Context.MODE_PRIVATE)
        eq = runCatching { Equalizer(0, audioSessionId) }.getOrNull()
        bass = runCatching { BassBoost(0, audioSessionId) }.getOrNull()
        virt = runCatching { Virtualizer(0, audioSessionId) }.getOrNull()
        _sessionId.value = audioSessionId
        restore()
    }

    private fun restore() {
        val p = prefs ?: return
        val enabled = p.getBoolean("enabled", false)
        eq?.let { e ->
            val preset = p.getInt("preset", -1)
            if (preset in 0 until e.numberOfPresets) {
                runCatching { e.usePreset(preset.toShort()) }
            } else {
                for (i in 0 until e.numberOfBands) {
                    runCatching { e.setBandLevel(i.toShort(), p.getInt("band_$i", 0).toShort()) }
                }
            }
            runCatching { e.enabled = enabled }
        }
        applyBass(enabled)
        applyVirtualizer(enabled)
        applyNormalize()
        publish()
    }

    /**
     * Volume igual entre músicas: um compressor/limitador que segura as músicas muito altas
     * e levanta um pouco as baixas (Android 9 ou mais novo).
     */
    private fun applyNormalize() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return
        val on = prefs?.getBoolean("normalize", false) == true
        if (!on) {
            dynamics?.let { runCatching { it.enabled = false } }
            return
        }
        if (dynamics == null && sessionId != 0) {
            dynamics = runCatching {
                val config = DynamicsProcessing.Config.Builder(
                    DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                    2, false, 0, false, 0, false, 0, true,
                ).build()
                DynamicsProcessing(0, sessionId, config)
            }.getOrNull()
        }
        dynamics?.let { d ->
            runCatching {
                d.setLimiterAllChannelsTo(
                    DynamicsProcessing.Limiter(true, true, 0, 5f, 250f, 6f, -18f, 9f)
                )
                d.enabled = true
            }
        }
    }

    fun setNormalize(on: Boolean) {
        prefs?.edit()?.putBoolean("normalize", on)?.apply()
        applyNormalize()
        publish()
    }

    private fun applyBass(enabled: Boolean) {
        val b = bass ?: return
        val strength = prefs?.getInt("bass", 0) ?: 0
        if (b.strengthSupported) runCatching { b.setStrength(strength.toShort()) }
        runCatching { b.enabled = enabled && strength > 0 }
    }

    private fun applyVirtualizer(enabled: Boolean) {
        val v = virt ?: return
        val strength = prefs?.getInt("virt", 0) ?: 0
        if (v.strengthSupported) runCatching { v.setStrength(strength.toShort()) }
        runCatching { v.enabled = enabled && strength > 0 }
    }

    // ---------------- 1.8: um ajuste para cada fone ----------------

    /** Saída de som atual: chave ("bt:JBL", "wired", "speaker") e nome para mostrar. */
    data class Output(val key: String, val label: String)

    private val _output = MutableStateFlow<Output?>(null)
    val output: StateFlow<Output?> = _output.asStateFlow()
    private var perDevice = true
    private var appContext: Context? = null

    private fun profiles(ctx: Context) = ctx.getSharedPreferences("eq_profiles", Context.MODE_PRIVATE)

    /** Guarda o ajuste atual no perfil da saída atual. */
    private fun saveProfile() {
        val ctx = appContext ?: return
        val key = _output.value?.key ?: return
        if (!perDevice) return
        val p = ctx.getSharedPreferences("effects", Context.MODE_PRIVATE)
        val o = org.json.JSONObject()
        p.all.forEach { (k, v) ->
            when (v) {
                is Boolean -> o.put(k, v)
                is Int -> o.put(k, v)
            }
        }
        profiles(ctx).edit()
            .putString("p_$key", o.toString())
            .putString("l_$key", _output.value?.label ?: key)
            .apply()
    }

    /** Chamado pelo serviço quando conecta ou desconecta fone. Devolve true se trocou de ajuste. */
    fun onOutputChanged(context: Context, key: String, label: String, enabledPerDevice: Boolean): Boolean {
        val ctx = context.applicationContext
        appContext = ctx
        perDevice = enabledPerDevice
        val old = _output.value?.key
        if (old == key) return false
        if (old != null) saveProfile()
        _output.value = Output(key, label)
        if (!enabledPerDevice) return false
        val saved = profiles(ctx).getString("p_$key", null)
        if (saved == null) {
            // Primeira vez com essa saída: começa com o ajuste atual
            saveProfile()
            return false
        }
        runCatching {
            val o = org.json.JSONObject(saved)
            val edit = ctx.getSharedPreferences("effects", Context.MODE_PRIVATE).edit().clear()
            o.keys().forEach { k ->
                when (val v = o.get(k)) {
                    is Boolean -> edit.putBoolean(k, v)
                    is Int -> edit.putInt(k, v)
                    is Number -> edit.putInt(k, v.toInt())
                }
            }
            edit.commit()
        }
        if (eq != null) restore()
        return old != null
    }

    fun setPerDevice(context: Context, on: Boolean) {
        appContext = context.applicationContext
        perDevice = on
        if (on) saveProfile()
    }

    /** Saídas que já têm ajuste guardado: chave → nome. */
    fun savedProfiles(context: Context): List<Output> =
        profiles(context).all.keys.filter { it.startsWith("p_") }.map { k ->
            val key = k.removePrefix("p_")
            Output(key, profiles(context).getString("l_$key", key) ?: key)
        }.sortedBy { it.label.lowercase() }

    fun forgetProfile(context: Context, key: String) {
        profiles(context).edit().remove("p_$key").remove("l_$key").apply()
    }

    private fun publish() {
        val e = eq
        val p = prefs
        if (e == null || p == null) {
            _state.value = EqState(available = false)
            return
        }
        val n = e.numberOfBands.toInt()
        val range = e.bandLevelRange
        _state.value = EqState(
            available = true,
            enabled = p.getBoolean("enabled", false),
            bandFreqsHz = (0 until n).map { e.getCenterFreq(it.toShort()) / 1000 },
            bandLevels = (0 until n).map { e.getBandLevel(it.toShort()).toInt() },
            minLevel = range[0].toInt(),
            maxLevel = range[1].toInt(),
            presets = (0 until e.numberOfPresets).map { e.getPresetName(it.toShort()) },
            currentPreset = p.getInt("preset", -1),
            bassStrength = p.getInt("bass", 0),
            bassSupported = bass?.strengthSupported == true,
            virtualizerStrength = p.getInt("virt", 0),
            virtualizerSupported = virt?.strengthSupported == true,
            normalize = p.getBoolean("normalize", false),
            normalizeSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P,
        )
        saveProfile()
    }

    fun setEnabled(on: Boolean) {
        prefs?.edit()?.putBoolean("enabled", on)?.apply()
        eq?.let { runCatching { it.enabled = on } }
        applyBass(on)
        applyVirtualizer(on)
        publish()
    }

    fun setBandLevel(band: Int, level: Int) {
        val e = eq ?: return
        runCatching { e.setBandLevel(band.toShort(), level.toShort()) }
        prefs?.edit()?.putInt("band_$band", level)?.putInt("preset", -1)?.apply()
        publish()
    }

    fun usePreset(index: Int) {
        val e = eq ?: return
        runCatching { e.usePreset(index.toShort()) }
        val edit = prefs?.edit() ?: return
        for (i in 0 until e.numberOfBands) edit.putInt("band_$i", e.getBandLevel(i.toShort()).toInt())
        edit.putInt("preset", index).apply()
        publish()
    }

    fun resetFlat() {
        val e = eq ?: return
        val edit = prefs?.edit() ?: return
        for (i in 0 until e.numberOfBands) {
            runCatching { e.setBandLevel(i.toShort(), 0) }
            edit.putInt("band_$i", 0)
        }
        edit.putInt("preset", -1).apply()
        publish()
    }

    fun setBass(strength: Int) {
        prefs?.edit()?.putInt("bass", strength)?.apply()
        applyBass(prefs?.getBoolean("enabled", false) == true)
        publish()
    }

    fun setVirtualizer(strength: Int) {
        prefs?.edit()?.putInt("virt", strength)?.apply()
        applyVirtualizer(prefs?.getBoolean("enabled", false) == true)
        publish()
    }

    fun release() {
        runCatching { eq?.release() }
        runCatching { bass?.release() }
        runCatching { virt?.release() }
        runCatching { dynamics?.release() }
        dynamics = null
        eq = null
        bass = null
        virt = null
        sessionId = 0
        _sessionId.value = 0
        publish()
    }
}
