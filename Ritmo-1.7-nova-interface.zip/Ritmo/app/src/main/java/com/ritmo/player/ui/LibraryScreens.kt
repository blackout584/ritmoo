@file:OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.ritmo.player.ui

import android.net.Uri
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.unit.lerp
import com.ritmo.player.data.sortedFor
import kotlinx.coroutines.launch
import kotlin.math.abs
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.data.FAVORITES_ID
import com.ritmo.player.data.Song
import com.ritmo.player.data.SongSort

sealed interface Detail {
    data class Album(val albumId: Long, val name: String) : Detail
    data class Artist(val name: String) : Detail
    data class Folder(val path: String, val name: String) : Detail
    data class PlaylistDetail(val id: Long) : Detail
    data class Smart(val kind: SmartKind) : Detail
}

private data class AlbumInfo(val id: Long, val name: String, val artist: String, val artUri: Uri, val count: Int)

// ---------------- Tela principal ----------------

/** Páginas que abrem pelo menu lateral ou pelos cartões. */
enum class Page { SETTINGS, THEMES, EQUALIZER, PLAYLISTS, FOR_YOU, UPDATE, BACKUP }

@Composable
fun MainScreen(
    vm: MainViewModel,
    onOpen: (Detail) -> Unit,
    onOpenPage: (Page) -> Unit,
    onMenu: () -> Unit,
) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    val titles = listOf("Músicas", "YouTube", "Artistas", "Álbuns", "Pastas")
    val pagerState = rememberPagerState(pageCount = { titles.size })
    val pageState = rememberSaveableStateHolder()
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        // Topo: menu + busca geral
        Row(
            Modifier.fillMaxWidth().padding(start = 4.dp, end = 16.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onMenu) { Icon(Icons.Rounded.Tune, "Menu") }
            Row(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(28.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 14.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Search, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                androidx.compose.foundation.text.BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary),
                    modifier = Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 12.dp),
                    decorationBox = { inner ->
                        if (query.isEmpty()) {
                            Text(
                                "Buscar músicas, playlists e artistas",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        inner()
                    },
                )
                if (query.isNotEmpty()) {
                    Icon(
                        Icons.Rounded.Close, "Limpar",
                        modifier = Modifier.clip(CircleShape).clickable { query = "" }.padding(4.dp),
                    )
                }
            }
        }

        if (query.isNotBlank()) {
            SearchResults(vm, query, onOpen)
            return@Column
        }

        UpdateCard(vm, compact = true)
        ShortcutCards(vm, onOpen, onOpenPage)

        // Abas em pílula
        val tabsState = androidx.compose.foundation.lazy.rememberLazyListState()
        LaunchedEffect(pagerState.currentPage) {
            tabsState.animateScrollToItem((pagerState.currentPage - 1).coerceAtLeast(0))
        }
        androidx.compose.foundation.lazy.LazyRow(
            state = tabsState,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            items(titles.size) { i ->
                val selected = pagerState.currentPage == i
                val bg by animateColorAsState(
                    if (selected) MaterialTheme.colorScheme.onSurface else Color.Transparent, label = "pillBg",
                )
                val fg by animateColorAsState(
                    if (selected) MaterialTheme.colorScheme.surfaceContainerLow else MaterialTheme.colorScheme.onSurfaceVariant,
                    label = "pillFg",
                )
                Text(
                    titles[i],
                    color = fg,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier
                        .clip(RoundedCornerShape(24.dp))
                        .background(bg)
                        .clickable { scope.launch { pagerState.animateScrollToPage(i) } }
                        .padding(horizontal = 18.dp, vertical = 9.dp),
                )
            }
        }

        when {
            loading && songs.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            else -> HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                key = { it },
                // Na aba YouTube o arrastar é do site, então o deslizar entre abas fica desligado
                userScrollEnabled = pagerState.currentPage != 1,
            ) { page ->
                pageState.SaveableStateProvider(key = "page_$page") {
                    when (page) {
                        0 -> if (songs.isEmpty()) {
                            EmptyMessage("Nenhuma música encontrada no aparelho.\nCopie arquivos de áudio para o celular.")
                        } else SongsTab(songs, vm)
                        1 -> YouTubeScreen()
                        2 -> ArtistsTab(songs, vm, onOpen)
                        3 -> AlbumsTab(songs, vm, onOpen)
                        else -> FoldersTab(songs, vm, onOpen)
                    }
                }
            }
        }
    }
}

/** Os três cartões: Favoritas, Playlists e Recentes (fundo com a capa da última música). */
@Composable
private fun ShortcutCards(vm: MainViewModel, onOpen: (Detail) -> Unit, onOpenPage: (Page) -> Unit) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    val playlists by vm.playlistStore.playlists.collectAsStateWithLifecycle()
    val stats by vm.statsStore.stats.collectAsStateWithLifecycle()
    val byId = remember(songs) { songs.associateBy { it.id } }
    val favArt = remember(byId, playlists) {
        playlists.firstOrNull { it.id == FAVORITES_ID }?.songIds?.lastOrNull()?.let { byId[it]?.artUri }
    }
    val listArt = remember(byId, playlists) {
        playlists.firstOrNull { it.id != FAVORITES_ID && it.songIds.isNotEmpty() }?.songIds?.firstOrNull()?.let { byId[it]?.artUri }
    }
    val recentArt = remember(byId, stats) {
        stats.maxByOrNull { it.value.lastPlayed }?.key?.let { byId[it]?.artUri }
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        ShortcutCard("Favoritas", Icons.Rounded.Favorite, favArt, Color(0xFF3A3A3A), Modifier.weight(1f)) {
            onOpen(Detail.PlaylistDetail(FAVORITES_ID))
        }
        ShortcutCard("Playlists", Icons.Rounded.Album, listArt, Color(0xFF2F5D7C), Modifier.weight(1f)) {
            onOpenPage(Page.PLAYLISTS)
        }
        ShortcutCard("Recentes", Icons.Rounded.Schedule, recentArt, Color(0xFF6B5BC7), Modifier.weight(1f)) {
            onOpenPage(Page.FOR_YOU)
        }
    }
}

@Composable
private fun ShortcutCard(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    art: Uri?,
    color: Color,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    Box(
        modifier
            .height(86.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(color)
            .clickable(onClick = onClick),
    ) {
        if (art != null) {
            coil.compose.AsyncImage(
                model = art,
                contentDescription = null,
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
        Box(
            Modifier.fillMaxSize().background(
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    listOf(Color.Black.copy(alpha = 0.15f), Color.Black.copy(alpha = 0.6f))
                )
            )
        )
        Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) {
            Icon(icon, null, tint = Color.White)
            Text(label, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

/** Linha "Reprodução aleatória" usada nas abas Artistas, Álbuns e Pastas. */
@Composable
private fun ShuffleHeader(vm: MainViewModel, songs: List<Song>, subtitle: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(24.dp))
            .clickable(enabled = songs.isNotEmpty()) { vm.shuffleAll(songs) }
            .padding(4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.onSurface),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.PlayArrow, null, tint = MaterialTheme.colorScheme.surfaceContainerLow)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("Reprodução aleatória", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Linha de lista com capa, título, subtítulo e seta ›. */
@Composable
private fun ChevronRow(art: Uri?, round: Boolean, title: String, subtitle: String, onClick: () -> Unit) {
    ListItem(
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        modifier = Modifier.clickable(onClick = onClick),
        leadingContent = {
            ArtImage(art, Modifier.size(56.dp).clip(if (round) CircleShape else RoundedCornerShape(10.dp)), corner = if (round) 28.dp else 10.dp)
        },
        headlineContent = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium) },
        supportingContent = { Text(subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        trailingContent = { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null) },
    )
}

@Composable
private fun SongsTab(songs: List<Song>, vm: MainViewModel) {
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val ratings by vm.ratingsStore.ratings.collectAsStateWithLifecycle()
    val shown = remember(songs, settings.songSort, ratings) { songs.sortedFor(settings.songSort, ratings) }
    SongList(
        shown, vm,
        sortControl = { SortButton(settings.songSort) { vm.setSongSort(it) } },
        letterOf = when (settings.songSort) {
            SongSort.TITLE_ASC, SongSort.TITLE_DESC -> { s: Song -> firstLetter(s.title) }
            SongSort.ARTIST -> { s: Song -> firstLetter(s.artist) }
            else -> null
        },
    )
}

@Composable
private fun AlbumsTab(songs: List<Song>, vm: MainViewModel, onOpen: (Detail) -> Unit) {
    val albums = remember(songs) {
        songs.groupBy { it.albumId }.map { (id, list) ->
            val first = list.first()
            AlbumInfo(id, first.album, first.artist, first.artUri, list.size)
        }.sortedBy { it.name.lowercase() }
    }
    LazyColumn(Modifier.fillMaxSize()) {
        item { ShuffleHeader(vm, songs, "${albums.size} álbuns") }
        items(albums, key = { it.id }) { a ->
            ChevronRow(a.artUri, round = false, title = a.name, subtitle = a.artist) { onOpen(Detail.Album(a.id, a.name)) }
        }
    }
}

@Composable
private fun ArtistsTab(songs: List<Song>, vm: MainViewModel, onOpen: (Detail) -> Unit) {
    val artists = remember(songs) {
        songs.groupBy { it.artist }.map { (name, list) -> Triple(name, list.size, list.first().artUri) }
            .sortedBy { it.first.lowercase() }
    }
    LazyColumn(Modifier.fillMaxSize()) {
        item { ShuffleHeader(vm, songs, "${artists.size} artistas") }
        items(artists, key = { it.first }) { (name, count, art) ->
            ChevronRow(art, round = true, title = name, subtitle = "$count músicas") { onOpen(Detail.Artist(name)) }
        }
    }
}

@Composable
private fun FoldersTab(songs: List<Song>, vm: MainViewModel, onOpen: (Detail) -> Unit) {
    val folders = remember(songs) {
        songs.groupBy { it.folderPath }.map { (path, list) -> Triple(path, list.first().folderName, list.size) }
            .sortedBy { it.second.lowercase() }
    }
    LazyColumn(Modifier.fillMaxSize()) {
        item { ShuffleHeader(vm, songs, "${folders.size} pastas") }
        items(folders, key = { it.first }) { (path, name, count) ->
            ListItem(
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                modifier = Modifier.clickable { onOpen(Detail.Folder(path, name)) },
                leadingContent = {
                    Box(
                        Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Rounded.Folder, null) }
                },
                headlineContent = { Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium) },
                supportingContent = { Text("$count músicas • $path", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                trailingContent = { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null) },
            )
        }
    }
}

// ---------------- Playlists ----------------

@Composable
fun PlaylistsScreen(vm: MainViewModel, onOpen: (Detail) -> Unit, onBack: (() -> Unit)? = null) {
    if (onBack != null) androidx.activity.compose.BackHandler(onBack = onBack)
    val playlists by vm.playlistStore.playlists.collectAsStateWithLifecycle()
    var creating by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        SimpleTopBar("Playlists", onBack = onBack, actions = {
            IconButton(onClick = { creating = true }) { Icon(Icons.Rounded.Add, "Nova playlist") }
        })
        LazyColumn(Modifier.fillMaxSize()) {
            item(key = "smart") { SmartPlaylistGrid(vm, onOpen) }
            items(playlists, key = { it.id }) { p ->
                GroupRow(
                    icon = if (p.id == FAVORITES_ID) Icons.Rounded.Favorite else Icons.AutoMirrored.Rounded.QueueMusic,
                    title = p.name,
                    subtitle = "${p.songIds.size} músicas",
                    onClick = { onOpen(Detail.PlaylistDetail(p.id)) },
                )
            }
        }
    }
    if (creating) {
        NameDialog("Nova playlist", "", "Criar", onConfirm = {
            vm.playlistStore.create(it)
            creating = false
        }, onDismiss = { creating = false })
    }
}

// ---------------- Detalhes (álbum, artista, pasta, playlist) ----------------

@Composable
fun DetailScreen(detail: Detail, vm: MainViewModel, onBack: () -> Unit) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    val playlists by vm.playlistStore.playlists.collectAsStateWithLifecycle()
    val byId = remember(songs) { songs.associateBy { it.id } }
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }

    val playlist = (detail as? Detail.PlaylistDetail)?.let { d -> playlists.firstOrNull { it.id == d.id } }
    if (detail is Detail.PlaylistDetail && playlist == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val ratings by vm.ratingsStore.ratings.collectAsStateWithLifecycle()
    val stats by vm.statsStore.stats.collectAsStateWithLifecycle()
    val sortable = detail is Detail.Artist || detail is Detail.Folder
    val (title, list) = remember(detail, songs, playlist, settings.songSort, ratings, stats) {
        when (detail) {
            is Detail.Album -> detail.name to songs.filter { it.albumId == detail.albumId }.sortedBy { it.trackNumber }
            is Detail.Artist -> detail.name to songs.filter { it.artist == detail.name }.sortedFor(settings.songSort, ratings)
            is Detail.Folder -> detail.name to songs.filter { it.folderPath == detail.path }.sortedFor(settings.songSort, ratings)
            is Detail.Smart -> detail.kind.label to smartSongs(detail.kind, songs, stats)
            is Detail.PlaylistDetail -> playlist!!.name to playlist.songIds.mapNotNull { byId[it] }
        }
    }

    Column(Modifier.fillMaxSize()) {
        SimpleTopBar(title, onBack = onBack, actions = {
            if (playlist != null && playlist.id != FAVORITES_ID) {
                IconButton(onClick = { renaming = true }) { Icon(Icons.Rounded.Edit, "Renomear") }
                IconButton(onClick = { deleting = true }) { Icon(Icons.Rounded.Delete, "Excluir") }
            }
        })
        if (list.isEmpty()) {
            EmptyMessage(if (playlist != null) "Esta playlist está vazia.\nUse o menu ⋮ de uma música para adicioná-la." else "Nenhuma música aqui.")
        } else {
            SongList(
                list, vm,
                playlistId = playlist?.id,
                sortControl = {
                    if (sortable) SortButton(settings.songSort) { vm.setSongSort(it) }
                },
            )
        }
    }

    if (renaming && playlist != null) {
        NameDialog("Renomear playlist", playlist.name, "Salvar", onConfirm = {
            vm.playlistStore.rename(playlist.id, it)
            renaming = false
        }, onDismiss = { renaming = false })
    }
    if (deleting && playlist != null) {
        AlertDialog(
            onDismissRequest = { deleting = false },
            title = { Text("Excluir playlist?") },
            text = { Text("A playlist \"${playlist.name}\" será excluída. As músicas continuam no aparelho.") },
            confirmButton = {
                TextButton(onClick = { deleting = false; vm.playlistStore.delete(playlist.id) }) { Text("Excluir") }
            },
            dismissButton = { TextButton(onClick = { deleting = false }) { Text("Cancelar") } },
        )
    }
}
