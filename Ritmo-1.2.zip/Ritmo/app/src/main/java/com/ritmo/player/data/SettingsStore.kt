package com.ritmo.player.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accent: Int = 0,
    val dynamicColor: Boolean = true,
    val minDurationSec: Int = 10,
    val vinylArt: Boolean = true,
    val visualizer: Boolean = true,
    val songSort: SongSort = SongSort.TITLE_ASC,
)

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    fun update(transform: (AppSettings) -> AppSettings) {
        val s = transform(_settings.value)
        prefs.edit()
            .putString("theme", s.themeMode.name)
            .putInt("accent", s.accent)
            .putBoolean("dynamic", s.dynamicColor)
            .putInt("minDuration", s.minDurationSec)
            .putBoolean("vinyl", s.vinylArt)
            .putBoolean("visualizer", s.visualizer)
            .putString("songSort", s.songSort.name)
            .apply()
        _settings.value = s
    }

    private fun load() = AppSettings(
        themeMode = runCatching { ThemeMode.valueOf(prefs.getString("theme", null) ?: "SYSTEM") }
            .getOrDefault(ThemeMode.SYSTEM),
        accent = prefs.getInt("accent", 0),
        dynamicColor = prefs.getBoolean("dynamic", true),
        minDurationSec = prefs.getInt("minDuration", 10),
        vinylArt = prefs.getBoolean("vinyl", true),
        visualizer = prefs.getBoolean("visualizer", true),
        songSort = runCatching { SongSort.valueOf(prefs.getString("songSort", null) ?: "TITLE_ASC") }
            .getOrDefault(SongSort.TITLE_ASC),
    )
}
