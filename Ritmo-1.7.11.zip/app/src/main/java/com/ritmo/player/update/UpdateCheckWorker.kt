package com.ritmo.player.update

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.ritmo.player.data.SettingsStore
import com.ritmo.player.data.Updater
import java.util.concurrent.TimeUnit

/** Confere no GitHub, a cada 15 minutos (o menor intervalo do Android), se saiu versão nova. */
class UpdateCheckWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        // Retrospectiva do mês (dia 1)
        runCatching { RecapNotifier.checkAndNotify(ctx) }
        if (!SettingsStore.get(ctx).settings.value.autoUpdateCheck) return Result.success()
        val info = Updater.fetchLatest() ?: return Result.success()
        if (Updater.isNewer(ctx, info)) UpdateNotifier.notifyIfNew(ctx, info)
        return Result.success()
    }

    companion object {
        private const val NAME = "ritmo-update-check"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<UpdateCheckWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, request)
        }
    }
}
