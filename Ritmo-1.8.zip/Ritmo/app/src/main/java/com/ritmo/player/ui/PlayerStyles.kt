@file:OptIn(ExperimentalMaterial3Api::class)

package com.ritmo.player.ui

import android.net.Uri
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ritmo.player.data.PlayerStyle
import kotlinx.coroutines.isActive
import kotlin.math.cos
import kotlin.math.sin

// ---------------- Giro contínuo (discos e rolos) ----------------

@Composable
fun rememberSpin(isPlaying: Boolean, periodMs: Int = 9000): State<Float> {
    val rotation = remember { Animatable(0f) }
    LaunchedEffect(isPlaying, periodMs) {
        if (isPlaying) {
            while (isActive) {
                rotation.animateTo(rotation.value + 360f, tween(periodMs, easing = LinearEasing))
                rotation.snapTo(rotation.value % 360f)
            }
        } else {
            rotation.animateTo(rotation.value + 20f, tween(900, easing = FastOutSlowInEasing))
        }
    }
    return rotation.asState()
}

/** Força da batida (graves) a partir das barras do visualizador, de 0 a 1. */
fun bassPulse(levels: FloatArray): Float {
    if (levels.isEmpty()) return 0f
    val n = (levels.size / 4).coerceAtLeast(1)
    var sum = 0f
    for (i in 0 until n) sum += levels[i]
    return (sum / n).coerceIn(0f, 1f)
}

/** Anel que pulsa em volta dos discos, no ritmo da música. */
private fun Modifier.pulseRing(pulse: Float, color: Color, enabled: Boolean): Modifier =
    if (!enabled) this else drawBehind {
        val r = size.minDimension / 2f
        drawCircle(
            color = color.copy(alpha = 0.25f + 0.55f * pulse),
            radius = r * (1.01f + 0.07f * pulse),
            style = Stroke(width = r * 0.025f),
        )
    }

// ---------------- Capa de acordo com o estilo escolhido ----------------

@Composable
fun PlayerStyleArt(
    style: PlayerStyle,
    uri: Uri?,
    isPlaying: Boolean,
    accent: Color,
    modifier: Modifier = Modifier,
    pulse: Float = 0f,
    showPulse: Boolean = false,
    small: Boolean = false,
    beat: Boolean = false,
) {
    val p by animateFloatAsState(pulse, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium), label = "pulse")
    // 1.8: a capa inteira dá um "pulo" no grave
    val modifier = if (beat && showPulse) {
        modifier.graphicsLayer {
            val k = 1f + 0.06f * p
            scaleX = k; scaleY = k
        }
    } else modifier
    when (style) {
        PlayerStyle.PADRAO -> BreathingArt(uri, isPlaying, modifier)
        PlayerStyle.VINIL_CLASSICO -> Box(modifier.aspectRatio(1f)) {
            DiscWithArm(uri, isPlaying, Color(0xFF111114), Color.White, p, accent, showPulse, small)
        }
        PlayerStyle.VINIL_MODERNO -> Box(modifier.aspectRatio(1f)) {
            DiscWithArm(uri, isPlaying, lerp(accent, Color(0xFF0B1A3A), 0.55f), Color(0xFFE6F1FB), p, accent, showPulse, small)
        }
        PlayerStyle.CD -> CdPlayerArt(uri, isPlaying, p, accent, showPulse, small, modifier)
        PlayerStyle.CASSETE -> CassetteArt(uri, isPlaying, small, modifier)
        PlayerStyle.RADIO -> RadioArt(uri, isPlaying, small, modifier)
        PlayerStyle.WALKMAN -> WalkmanArt(uri, isPlaying, small, modifier)
    }
}

@Composable
private fun DiscWithArm(
    uri: Uri?,
    isPlaying: Boolean,
    discColor: Color,
    armColor: Color,
    pulse: Float,
    accent: Color,
    showPulse: Boolean,
    small: Boolean,
) {
    val spin by rememberSpin(isPlaying)
    val scale by animateFloatAsState(
        if (isPlaying) 1f else 0.95f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "discScale",
    )
    val armAngle by animateFloatAsState(if (isPlaying) 26f else 4f, tween(700), label = "arm")
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .fillMaxSize(0.9f)
                .scale(scale)
                .pulseRing(pulse, accent, showPulse)
                .shadow(if (small) 4.dp else 18.dp, CircleShape)
                .clip(CircleShape)
                .background(discColor)
                .rotate(spin),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val maxR = size.minDimension / 2f
                var r = maxR * 0.97f
                var i = 0
                while (r > maxR * 0.5f) {
                    drawCircle(
                        Color.White.copy(alpha = if (i % 3 == 0) 0.09f else 0.04f),
                        radius = r,
                        style = Stroke(width = 1.2f),
                    )
                    r -= maxR * 0.03f
                    i++
                }
            }
            ArtImage(uri, Modifier.fillMaxSize(0.56f).clip(CircleShape), corner = 999.dp, zoom = 1.4f)
            Box(Modifier.size(if (small) 4.dp else 12.dp).clip(CircleShape).background(discColor))
        }
        // Braço da agulha: encosta no disco quando toca e se afasta ao pausar
        Canvas(Modifier.fillMaxSize()) {
            val pivot = Offset(size.width * 0.93f, size.height * 0.07f)
            val len = size.height * 0.52f
            val w = size.minDimension * 0.022f
            rotate(armAngle, pivot) {
                drawLine(armColor, pivot, Offset(pivot.x, pivot.y + len), strokeWidth = w, cap = StrokeCap.Round)
                drawRoundRect(
                    armColor,
                    topLeft = Offset(pivot.x - w * 1.6f, pivot.y + len - w),
                    size = Size(w * 3.2f, w * 5f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(w),
                )
            }
            drawCircle(armColor, radius = w * 2.4f, center = pivot)
            drawCircle(discColor, radius = w * 1.1f, center = pivot)
        }
    }
}

@Composable
private fun CdPlayerArt(
    uri: Uri?,
    isPlaying: Boolean,
    pulse: Float,
    accent: Color,
    showPulse: Boolean,
    small: Boolean,
    modifier: Modifier,
) {
    val spin by rememberSpin(isPlaying, 5000)
    val body = Color(0xFF2C2A44)
    Box(
        modifier
            .aspectRatio(1f)
            .shadow(if (small) 4.dp else 18.dp, RoundedCornerShape(if (small) 12.dp else 28.dp))
            .clip(RoundedCornerShape(if (small) 12.dp else 28.dp))
            .background(body),
        contentAlignment = Alignment.Center,
    ) {
        // Caixinhas de som dos lados e botão de volume
        Canvas(Modifier.fillMaxSize()) {
            val dot = size.minDimension * 0.012f
            for (side in listOf(0.06f, 0.94f)) {
                for (row in 0 until 9) for (col in 0 until 2) {
                    drawCircle(
                        Color.White.copy(alpha = 0.18f),
                        radius = dot,
                        center = Offset(size.width * side + (col - 0.5f) * dot * 3.2f, size.height * (0.36f + row * 0.035f)),
                    )
                }
            }
            drawCircle(Color.White.copy(alpha = 0.25f), radius = size.minDimension * 0.04f, center = Offset(size.width * 0.86f, size.height * 0.88f), style = Stroke(size.minDimension * 0.008f))
            drawRoundRect(Color.White.copy(alpha = 0.2f), topLeft = Offset(size.width * 0.12f, size.height * 0.72f), size = Size(size.width * 0.012f, size.height * 0.12f))
        }
        Box(
            Modifier
                .fillMaxSize(0.76f)
                .pulseRing(pulse, accent, showPulse)
                .clip(CircleShape)
                .background(Color(0xFFB8BCC8))
                .rotate(spin),
            contentAlignment = Alignment.Center,
        ) {
            ArtImage(uri, Modifier.fillMaxSize(0.96f).clip(CircleShape), corner = 999.dp, zoom = 1.3f)
            Box(
                Modifier.fillMaxSize(0.2f).clip(CircleShape).background(Color(0xFFDADDE5))
                    .border(2.dp, Color.White.copy(alpha = 0.6f), CircleShape),
                contentAlignment = Alignment.Center,
            ) { Box(Modifier.fillMaxSize(0.4f).clip(CircleShape).background(body)) }
        }
    }
}

@Composable
private fun CassetteArt(uri: Uri?, isPlaying: Boolean, small: Boolean, modifier: Modifier) {
    val spin by rememberSpin(isPlaying, 2600)
    val body = Color(0xFF4A4A4A)
    val dark = Color(0xFF2E2E2E)
    val corner = if (small) 12.dp else 30.dp
    Box(
        modifier
            .aspectRatio(1.08f)
            .shadow(if (small) 4.dp else 18.dp, RoundedCornerShape(corner))
            .clip(RoundedCornerShape(corner))
            .background(body),
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = if (small) 6.dp else 18.dp, vertical = if (small) 6.dp else 18.dp)) {
            // Janela com a capa e os rolos
            Box(
                Modifier.fillMaxWidth().weight(0.66f).clip(RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center,
            ) {
                ArtImage(uri, Modifier.fillMaxSize(), corner = 4.dp, zoom = 1.2f)
                Row(
                    Modifier
                        .fillMaxWidth(0.88f)
                        .fillMaxHeight(0.42f)
                        .clip(RoundedCornerShape(50))
                        .background(Color(0x99333333)),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Reel(spin, Modifier.fillMaxHeight().aspectRatio(1f, matchHeightConstraintsFirst = true).padding(4.dp))
                    Reel(spin, Modifier.fillMaxHeight().aspectRatio(1f, matchHeightConstraintsFirst = true).padding(4.dp))
                }
            }
            // Parte de baixo em trapézio com os dois furos
            Box(
                Modifier
                    .fillMaxWidth()
                    .weight(0.34f)
                    .padding(top = if (small) 4.dp else 10.dp)
                    .clip(GenericShape { s, _ ->
                        moveTo(s.width * 0.1f, 0f); lineTo(s.width * 0.9f, 0f)
                        lineTo(s.width, s.height); lineTo(0f, s.height); close()
                    })
                    .background(Color(0xFF555555)),
                contentAlignment = Alignment.Center,
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(if (small) 3.dp else 10.dp)) {
                    repeat(2) {
                        Box(
                            Modifier.width(if (small) 14.dp else 46.dp).height(if (small) 5.dp else 18.dp)
                                .clip(RoundedCornerShape(50)).background(dark)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Reel(spin: Float, modifier: Modifier) {
    Canvas(modifier) {
        val r = size.minDimension / 2f
        drawCircle(Color(0xFF5A5A5A), r)
        drawCircle(Color(0xFF8A8A8A), r * 0.72f, style = Stroke(r * 0.22f))
        drawCircle(Color(0xFF2A2A2A), r * 0.5f)
        rotate(spin) {
            for (k in 0 until 6) {
                val a = Math.toRadians(k * 60.0)
                drawLine(
                    Color(0xFF9A9A9A),
                    center + Offset((cos(a) * r * 0.2f).toFloat(), (sin(a) * r * 0.2f).toFloat()),
                    center + Offset((cos(a) * r * 0.45f).toFloat(), (sin(a) * r * 0.45f).toFloat()),
                    strokeWidth = r * 0.08f,
                    cap = StrokeCap.Round,
                )
            }
        }
    }
}

// ---------------- Tela "Estilos do reprodutor" ----------------

@Composable
fun PlayerStylesSheet(
    current: PlayerStyle,
    artUri: Uri?,
    onSelect: (PlayerStyle) -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Text(
            "Estilos do reprodutor",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 20.dp, bottom = 8.dp),
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 14.dp, end = 14.dp, bottom = 28.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(PlayerStyle.entries) { st ->
                StylePreviewCard(st, artUri, st == current) { onSelect(st) }
            }
        }
    }
}

@Composable
private fun StylePreviewCard(style: PlayerStyle, artUri: Uri?, applied: Boolean, onClick: () -> Unit) {
    val bg = when (style) {
        PlayerStyle.PADRAO -> Color(0xFF1E3A5C)
        PlayerStyle.VINIL_MODERNO -> Color(0xFF3A6FC4)
        PlayerStyle.VINIL_CLASSICO -> Color(0xFF3A3A3A)
        PlayerStyle.CD -> Color(0xFF26233F)
        PlayerStyle.CASSETE -> Color(0xFF2E2E2E)
        PlayerStyle.RADIO -> Color(0xFF412402)
        PlayerStyle.WALKMAN -> Color(0xFF042C53)
    }
    val accent = MaterialTheme.colorScheme.primary
    Column {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(0.6f)
                .clip(RoundedCornerShape(14.dp))
                .background(bg)
                .then(if (applied) Modifier.border(2.dp, accent, RoundedCornerShape(14.dp)) else Modifier)
                .clickable(onClick = onClick)
                .padding(8.dp),
        ) {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    PlayerStyleArt(style, artUri, isPlaying = true, accent = accent, modifier = Modifier.fillMaxWidth(), small = true)
                }
                Spacer(Modifier.height(6.dp))
                Box(Modifier.fillMaxWidth(0.7f).height(5.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.85f)))
                Spacer(Modifier.height(3.dp))
                Box(Modifier.fillMaxWidth(0.4f).height(4.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.45f)))
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(2.dp).background(Color.White.copy(alpha = 0.25f))) {
                    Box(Modifier.fillMaxWidth(0.3f).height(2.dp).background(Color.White))
                }
                Spacer(Modifier.height(6.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.SkipPrevious, null, Modifier.size(12.dp), tint = Color.White)
                    Box(Modifier.size(20.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Pause, null, Modifier.size(12.dp), tint = Color.White)
                    }
                    Icon(Icons.Rounded.SkipNext, null, Modifier.size(12.dp), tint = Color.White)
                }
            }
            if (applied) {
                Text(
                    "Aplicado",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF633806),
                    modifier = Modifier
                        .offset((-2).dp, (-2).dp)
                        .clip(RoundedCornerShape(50))
                        .background(Color(0xFFFAEEDA))
                        .padding(horizontal = 6.dp, vertical = 1.dp),
                )
            }
        }
        Text(style.label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp, start = 2.dp))
    }
}


// ---------------- Ícone do mini player ----------------

/** Ícone pequeno do mini player no mesmo estilo do reprodutor. */
@Composable
fun MiniStyleIcon(style: PlayerStyle, uri: Uri?, isPlaying: Boolean) {
    when (style) {
        PlayerStyle.PADRAO -> ArtImage(uri, Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)), corner = 10.dp)
        PlayerStyle.VINIL_CLASSICO -> VinylArt(uri, isPlaying, Modifier.size(42.dp))
        PlayerStyle.VINIL_MODERNO -> MiniDisc(uri, isPlaying, Color(0xFF185FA5), Color(0xFF0C447C), 0.5f)
        PlayerStyle.CD -> MiniDisc(uri, isPlaying, Color(0xFFB8BCC8), Color(0xFFDADDE5), 0.86f, cdHole = true)
        PlayerStyle.CASSETE -> CassetteArt(uri, isPlaying, small = true, modifier = Modifier.width(46.dp))
        PlayerStyle.RADIO -> RadioArt(uri, isPlaying, small = true, modifier = Modifier.width(48.dp))
        PlayerStyle.WALKMAN -> WalkmanArt(uri, isPlaying, small = true, modifier = Modifier.width(36.dp))
    }
}

@Composable
private fun MiniDisc(uri: Uri?, isPlaying: Boolean, disc: Color, ring: Color, artFraction: Float, cdHole: Boolean = false) {
    val spin by rememberSpin(isPlaying, if (cdHole) 4000 else 8000)
    Box(
        Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(disc)
            .border(2.dp, ring, CircleShape)
            .rotate(spin),
        contentAlignment = Alignment.Center,
    ) {
        ArtImage(uri, Modifier.fillMaxSize(artFraction).clip(CircleShape), corner = 999.dp, zoom = 1.3f)
        Box(
            Modifier
                .size(if (cdHole) 10.dp else 6.dp)
                .clip(CircleShape)
                .background(if (cdHole) Color(0xFFDADDE5) else disc)
        )
    }
}


// ---------------- 1.8: Rádio antigo ----------------

@Composable
private fun RadioArt(uri: Uri?, isPlaying: Boolean, small: Boolean, modifier: Modifier) {
    val wood = Color(0xFF633806)
    val woodDark = Color(0xFF412402)
    val dial = Color(0xFFFAEEDA)
    val gold = Color(0xFFFAC775)
    // Ponteiro do dial passeando enquanto toca
    val t = rememberInfiniteTransition(label = "radio")
    val swing by t.animateFloat(
        0.15f, 0.85f,
        infiniteRepeatable(tween(5000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "needle",
    )
    val needle by animateFloatAsState(if (isPlaying) swing else 0.5f, tween(600), label = "needlePos")
    val spin by rememberSpin(isPlaying, 14000)
    val corner = if (small) 8.dp else 26.dp
    Box(
        modifier
            .aspectRatio(1.25f)
            .shadow(if (small) 3.dp else 18.dp, RoundedCornerShape(corner))
            .clip(RoundedCornerShape(corner))
            .background(wood)
            .padding(if (small) 4.dp else 14.dp),
    ) {
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            // Alto-falante redondo com a capa no meio
            Box(
                Modifier
                    .fillMaxHeight()
                    .aspectRatio(1f, matchHeightConstraintsFirst = true)
                    .clip(CircleShape)
                    .background(woodDark),
                contentAlignment = Alignment.Center,
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val r = size.minDimension / 2f
                    var rr = r * 0.95f
                    while (rr > r * 0.5f) {
                        drawCircle(Color.Black.copy(alpha = 0.25f), rr, style = Stroke(r * 0.03f))
                        rr -= r * 0.08f
                    }
                }
                ArtImage(uri, Modifier.fillMaxSize(0.5f).rotate(spin).clip(CircleShape), corner = 999.dp, zoom = 1.3f)
            }
            Spacer(Modifier.width(if (small) 3.dp else 12.dp))
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly) {
                // Dial com o ponteiro
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(if (small) 8.dp else 34.dp)
                        .clip(RoundedCornerShape(if (small) 2.dp else 6.dp))
                        .background(dial),
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        val n = 12
                        for (k in 0..n) {
                            val x = size.width * (0.06f + 0.88f * k / n)
                            val h = if (k % 3 == 0) size.height * 0.45f else size.height * 0.25f
                            drawLine(woodDark.copy(alpha = 0.6f), Offset(x, size.height - h), Offset(x, size.height), strokeWidth = size.height * 0.05f)
                        }
                        val x = size.width * (0.06f + 0.88f * needle)
                        drawLine(Color(0xFFE24B4A), Offset(x, 0f), Offset(x, size.height), strokeWidth = size.height * 0.08f)
                    }
                }
                // Botões redondos
                Row(horizontalArrangement = Arrangement.spacedBy(if (small) 2.dp else 10.dp)) {
                    repeat(2) {
                        Box(
                            Modifier.size(if (small) 6.dp else 26.dp).clip(CircleShape).background(gold)
                                .border(if (small) 1.dp else 2.dp, woodDark, CircleShape)
                        )
                    }
                }
            }
        }
    }
}

// ---------------- 1.8: Walkman ----------------

@Composable
private fun WalkmanArt(uri: Uri?, isPlaying: Boolean, small: Boolean, modifier: Modifier) {
    val body = Color(0xFF185FA5)
    val dark = Color(0xFF0C447C)
    val light = Color(0xFFB5D4F4)
    val spin by rememberSpin(isPlaying, 2200)
    val t = rememberInfiniteTransition(label = "walkman")
    val bars = (0 until 5).map { i ->
        t.animateFloat(
            0.2f, 1f,
            infiniteRepeatable(tween(380 + i * 110, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "bar$i",
        )
    }
    val corner = if (small) 6.dp else 24.dp
    Box(
        modifier
            .aspectRatio(0.78f)
            .shadow(if (small) 3.dp else 18.dp, RoundedCornerShape(corner))
            .clip(RoundedCornerShape(corner))
            .background(body)
            .padding(if (small) 3.dp else 14.dp),
    ) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(if (small) 2.dp else 10.dp)) {
            // Janela da fita com a capa e os rolos
            Box(
                Modifier.fillMaxWidth().weight(0.62f).clip(RoundedCornerShape(if (small) 2.dp else 10.dp)).background(light),
                contentAlignment = Alignment.Center,
            ) {
                ArtImage(uri, Modifier.fillMaxSize(), corner = if (small) 2.dp else 10.dp, zoom = 1.2f)
                Row(
                    Modifier.fillMaxWidth(0.84f).fillMaxHeight(0.4f).clip(RoundedCornerShape(50)).background(Color(0x99042C53)),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Reel(spin, Modifier.fillMaxHeight().aspectRatio(1f, matchHeightConstraintsFirst = true).padding(if (small) 1.dp else 4.dp))
                    Reel(spin, Modifier.fillMaxHeight().aspectRatio(1f, matchHeightConstraintsFirst = true).padding(if (small) 1.dp else 4.dp))
                }
            }
            // Barrinhas de som
            Row(
                Modifier.fillMaxWidth().weight(0.18f),
                horizontalArrangement = Arrangement.spacedBy(if (small) 1.dp else 5.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                bars.forEach { b ->
                    val h = if (isPlaying) b.value else 0.15f
                    Box(Modifier.weight(1f).fillMaxHeight(h).clip(RoundedCornerShape(2.dp)).background(light))
                }
            }
            // Botões
            Row(
                Modifier.fillMaxWidth().weight(0.2f),
                horizontalArrangement = Arrangement.spacedBy(if (small) 1.dp else 6.dp),
            ) {
                repeat(4) {
                    Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(if (small) 1.dp else 6.dp)).background(dark))
                }
            }
        }
    }
}
