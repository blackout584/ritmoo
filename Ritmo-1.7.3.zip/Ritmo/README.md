# Ritmo — player de música gratuito para Android

Inspirado nos recursos do Poweramp, feito do zero em Kotlin + Jetpack Compose + Media3 (ExoPlayer).

## O que já funciona (versão 1.0)
- Biblioteca: músicas, álbuns (com capas), artistas e pastas, com busca
- Player completo: tocar/pausar, anterior/próxima, barra de progresso, aleatório, repetir (todas / uma)
- Fila de reprodução: tocar a seguir, adicionar à fila e remover da fila
- Reprodução em segundo plano com notificação e controles na tela de bloqueio
- Pausa automática ao desconectar o fone
- Reprodução sem pausa entre faixas (gapless)
- Playlists: criar, renomear, excluir, adicionar e remover músicas, além da playlist "Favoritas"
- Equalizador: bandas ajustáveis, predefinições, reforço de graves e som 3D (salvos automaticamente)
- Velocidade de reprodução (0,5x a 2x)
- Timer para dormir
- Temas: claro, escuro, sistema, Material You e 6 cores de destaque
- Filtro para esconder áudios curtos (áudios do WhatsApp, toques)

## Novidades da versão 1.1 (animações)
- Barras que dançam com a música na tela do player
- Capa em formato de disco de vinil que gira (ou capa quadrada que "respira")
- Fundo do player com as cores da capa, mudando suavemente a cada música
- Capa deslizando ao trocar de música, botão de play animado e botões com "pulinho"
- Telas e abas com transições suaves e barrinhas animadas na música que está tocando
- Assinatura fixa: as próximas atualizações instalam por cima, sem apagar os dados

## Novidades da versão 1.2
- Arrastar para os lados na Biblioteca para trocar entre Músicas, Álbuns, Artistas e Pastas
- Ordenar músicas: A → Z, Z → A, adicionadas recentemente, adicionadas primeiro, por artista e por duração
- Correção: ao voltar de uma pasta, álbum, artista ou playlist, o app volta para onde você estava

## Novidades da versão 1.3
- Temas: Padrão, Meia-noite, Neon, Pôr do sol, Oceano e Floresta
- Papel de parede com foto da galeria, com ajuste de escurecer e desfoque
- Segurar uma música abre o modo de seleção: tocar, fila, playlist, compartilhar, mover e apagar
- Menu de modo de reprodução no botão aleatório: repetir uma, aleatório, repetir tudo, em ordem
- Zoom na capa do disco para esconder faixas pretas

## Novidades da versão 1.4
- Novo tema Preto: tudo preto, letras brancas (o player também fica preto)
- Tema e papel de parede funcionam juntos (o tema dá as cores, a foto fica no fundo)
- Cor de destaque e cor das letras personalizáveis
- 7 estilos de letra: Padrão, Moderna, Clássica, Manuscrita, Futurista, Pixel e Elegante
  (fontes de licença livre SIL OFL, licenças em app/src/main/assets/licencas-fontes)

## Novidades da versão 1.5
- Tela inicial "Para você": tocadas recentemente, mais ouvidas, adicionadas recentemente
- Player com fundo animado (capa desfocada), deslizar a capa para trocar e deslizar para baixo para fechar
- Letras: lidas do arquivo, de um .lrc ou coladas por você; letras com tempo acendem junto com a música
- Widget na tela inicial do celular
- Editar nome, artista, álbum e capa (só dentro do Ritmo)
- Transição suave entre músicas e volume igual entre músicas
- Abertura animada e 4 ícones de app para escolher
- Abre na hora (lista guardada), atualiza sozinho e continua de onde parou
- Rolagem rápida A–Z e APK otimizado

## Novidades da versão 1.6
- Aba YouTube: o site do YouTube dentro do Ritmo (o vídeo para ao sair da aba ou minimizar, regra do YouTube)
- "Abrir no YouTube" e "Abrir no YouTube Music" no menu das músicas e do player
- Equalizador mudou para Ajustes > Som e para o menu ⋮ do player

## Novidades da versão 1.7
- Atualização pelo próprio app (Ajustes > Atualização) e aviso de versão nova
- Backup e restauração (Ajustes > Backup)
- Fila: arrastar para reorganizar e salvar como playlist; timer "no fim desta música"
- Busca geral na aba Início (músicas, artistas, álbuns e playlists)
- Escolher pastas, playlists automáticas e notas com estrelas
- Tamanho das letras e tema automático pelo horário
- Atalhos no ícone (Aleatório, Favoritas, Continuar) e botão no painel rápido

## Nova interface (1.7)
- Tela principal com menu lateral, busca, cartões Favoritas/Playlists/Recentes e abas em pílula
  (Músicas, YouTube, Artistas, Álbuns, Pastas)
- Mini player flutuante com disco girando e cor da capa

## Próximas etapas sugeridas
- Crossfade (transição suave entre músicas)
- Letras de músicas
- Widget na tela inicial
- Android Auto
- Editor de tags (título, artista, capa)

## Como abrir e rodar
1. Instale o **Android Studio** (gratuito): https://developer.android.com/studio
2. Descompacte este .zip.
3. No Android Studio, use **File > Open** e selecione a pasta `Ritmo`.
4. Aguarde o Gradle sincronizar. Na primeira vez, ele baixa tudo o que precisa, o que pode levar alguns minutos.
   - Se aparecer uma sugestão para atualizar o Gradle ou o AGP, você pode aceitar.
5. No celular, ative as **Opções do desenvolvedor** e a **Depuração USB**:
   Configurações > Sobre o telefone > toque 7 vezes em "Número da versão".
6. Conecte o celular pelo cabo USB e clique no botão ▶ (Run) do Android Studio.

## Para publicar na Play Store
Use **Build > Generate Signed App Bundle / APK**, crie uma chave de assinatura (guarde-a bem!) e envie o arquivo `.aab` pelo Google Play Console (taxa única de US$ 25).

## Estrutura do projeto
```
app/src/main/java/com/ritmo/player/
├── MainActivity.kt          tela inicial e pedido de permissão
├── data/                    músicas, playlists e configurações
├── playback/                serviço de reprodução e equalizador
└── ui/                      telas (biblioteca, player, equalizador, ajustes)
```

## 1.7.2
- Aba Início de volta como primeira aba; cartões Favoritas/Playlists/Recentes recolhem ao rolar
- Player com 5 estilos (Padrão, Vinil Moderno, Vinil Clássico, CD, Cassete) no botão da camiseta
- Visualizador: barras e anel que pulsa com a batida
- Interface compacta em todo o app; Artistas e Álbuns em grade de 3 colunas
- Mini player corrigido (disco dentro do quadro)

## 1.7.3
- Tela Personalizar: prévia do app, combinações prontas, botão Restaurar e abas Tema, Fundo, Cores, Letras e Tamanho
- Tamanho da interface: Compacto, Normal ou Grande
- Últimas imagens de papel de parede guardadas; opção de mostrar o papel de parede no player
- Aba YouTube sem o mini player
- Configurações com o fundo liso do tema
