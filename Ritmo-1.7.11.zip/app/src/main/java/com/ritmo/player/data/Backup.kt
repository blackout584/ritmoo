package com.ritmo.player.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Backup: guarda num arquivo .zip as configurações, playlists, favoritas, notas, edições,
 * letras, capas, papel de parede e estatísticas.
 */
object Backup {

    suspend fun export(context: Context, target: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val out = context.contentResolver.openOutputStream(target) ?: return@runCatching false
            ZipOutputStream(out).use { zip ->
                val prefsDir = File(context.applicationInfo.dataDir, "shared_prefs")
                prefsDir.listFiles()?.filter { it.isFile && it.name.endsWith(".xml") }?.forEach {
                    add(zip, "shared_prefs/${it.name}", it)
                }
                context.filesDir.walkTopDown()
                    .filter { it.isFile && it.name != "library.json" && !it.name.endsWith(".apk") }
                    .forEach { add(zip, "files/" + it.relativeTo(context.filesDir).path, it) }
            }
            true
        }.getOrDefault(false)
    }

    private fun add(zip: ZipOutputStream, name: String, file: File) {
        zip.putNextEntry(ZipEntry(name))
        file.inputStream().use { it.copyTo(zip) }
        zip.closeEntry()
    }

    /** Coloca os arquivos do backup de volta. Depois disso o app precisa reiniciar. */
    suspend fun import(context: Context, source: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val dataDir = File(context.applicationInfo.dataDir).canonicalFile
            val filesDir = context.filesDir.canonicalFile
            var count = 0
            context.contentResolver.openInputStream(source)?.use { input ->
                ZipInputStream(input).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        val name = entry.name
                        val target = when {
                            name.startsWith("shared_prefs/") -> File(dataDir, name)
                            name.startsWith("files/") -> File(filesDir, name.removePrefix("files/"))
                            else -> null
                        }?.canonicalFile
                        // Segurança: só grava dentro da pasta do próprio app
                        if (target != null && !entry.isDirectory && target.path.startsWith(dataDir.path)) {
                            target.parentFile?.mkdirs()
                            target.outputStream().use { zip.copyTo(it) }
                            count++
                        }
                        entry = zip.nextEntry
                    }
                }
            }
            count > 0
        }.getOrDefault(false)
    }

    fun restartApp(context: Context) {
        val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)
            ?: Intent(context, com.ritmo.player.MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        context.startActivity(intent)
        Runtime.getRuntime().exit(0)
    }
}
