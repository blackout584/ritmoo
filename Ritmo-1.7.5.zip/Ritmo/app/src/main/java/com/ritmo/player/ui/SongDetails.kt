@file:OptIn(ExperimentalMaterial3Api::class)

package com.ritmo.player.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.media.MediaMetadataRetriever
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.PlaylistPlay
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.SmartDisplay
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.data.FAVORITES_ID
import com.ritmo.player.data.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Informações técnicas do arquivo, lidas sem travar a tela. */
private data class FileInfo(
    val sizeBytes: Long,
    val bitrateKbps: Int,
    val sampleRateHz: Int,
    val format: String,
)

private suspend fun readFileInfo(context: Context, song: Song): FileInfo = withContext(Dispatchers.IO) {
    var size = File(song.path).takeIf { it.exists() }?.length() ?: 0L
    if (size <= 0L) {
        runCatching {
            context.contentResolver.query(song.uri, arrayOf(MediaStore.Audio.Media.SIZE), null, null, null)?.use {
                if (it.moveToFirst()) size = it.getLong(0)
            }
        }
    }
    var bitrate = 0
    var sampleRate = 0
    var mime = ""
    runCatching {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(context, song.uri)
            bitrate = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 0) / 1000
            mime = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE).orEmpty()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                sampleRate = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_SAMPLERATE)?.toIntOrNull() ?: 0
            }
        } finally {
            r.release()
        }
    }
    val ext = song.path.substringAfterLast('.', "").uppercase()
    val format = ext.ifBlank { mime.substringAfter('/').uppercase() }.ifBlank { "Áudio" }
    FileInfo(size, bitrate, sampleRate, format)
}

private fun prettySize(bytes: Long): String = when {
    bytes <= 0 -> "—"
    bytes >= 1024L * 1024 -> String.format(Locale("pt", "BR"), "%.1f MB", bytes / 1024.0 / 1024.0)
    else -> "${bytes / 1024} KB"
}

private fun prettyDuration(ms: Long): String {
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

/** Janela com a pasta, o arquivo e os detalhes da música. */
@Composable
fun SongDetailsSheet(
    vm: MainViewModel,
    song: Song,
    onDismiss: () -> Unit,
    onOpenFolder: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    val stats by vm.statsStore.stats.collectAsStateWithLifecycle()
    val ratings by vm.ratingsStore.ratings.collectAsStateWithLifecycle()
    val info by produceState<FileInfo?>(null, song.id) { value = readFileInfo(context, song) }

    val folder = song.relativeDir?.trimEnd('/')?.ifBlank { "Armazenamento interno" } ?: song.folderPath
    val fileName = song.path.substringAfterLast('/').ifBlank { song.title }
    val plays = stats[song.id]?.count ?: 0
    val rating = ratings[song.id] ?: 0

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(start = 20.dp, end = 20.dp, bottom = 28.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ArtImage(song.artUri, Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)), corner = 10.dp)
                Column(Modifier.padding(start = 12.dp)) {
                    Text(song.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        "${song.artist} · ${song.album}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Spacer(Modifier.height(12.dp))

            DetailRow("Pasta", folder, highlight = true)
            DetailRow("Arquivo", fileName)
            val i = info
            DetailRow(
                "Formato",
                if (i == null) "…" else listOfNotNull(
                    i.format,
                    i.bitrateKbps.takeIf { it > 0 }?.let { "$it kbps" },
                    i.sampleRateHz.takeIf { it > 0 }?.let { String.format(Locale("pt", "BR"), "%.1f kHz", it / 1000.0) },
                ).joinToString(" · "),
            )
            DetailRow("Tamanho", if (i == null) "…" else prettySize(i.sizeBytes))
            DetailRow("Duração", prettyDuration(song.durationMs))
            if (song.dateAdded > 0) {
                DetailRow("Adicionada", SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date(song.dateAdded * 1000)))
            }
            DetailRow(
                "Tocada",
                (if (plays == 1) "1 vez" else "$plays vezes") + if (rating > 0) " · ${starsText(rating)}" else "",
            )
            if (song.path.isNotBlank()) {
                Text(
                    song.path,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 10.dp),
                )
            }

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilledTonalButton(
                    onClick = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("Caminho", song.path.ifBlank { song.uri.toString() }))
                        Toast.makeText(context, "Caminho copiado", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(Icons.Rounded.ContentCopy, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Copiar caminho", maxLines = 1)
                }
                if (onOpenFolder != null) {
                    FilledTonalButton(onClick = { onDismiss(); onOpenFolder() }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.Folder, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Ver pasta", maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String, highlight: Boolean = false) {
    Column {
        Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
            Text(
                value,
                style = MaterialTheme.typography.bodyMedium,
                color = if (highlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                fontWeight = if (highlight) FontWeight.SemiBold else null,
                textAlign = TextAlign.End,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).padding(start = 16.dp),
            )
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    }
}

/** Menu completo de uma música (usado ao segurar nos resultados da busca). */
@Composable
fun SongOptionsSheet(
    vm: MainViewModel,
    song: Song,
    onDismiss: () -> Unit,
    onOpenFolder: (() -> Unit)? = null,
) {
    val actions = rememberMediaActions(vm)
    val playlists by vm.playlistStore.playlists.collectAsStateWithLifecycle()
    var sub by remember { mutableStateOf("") }
    val fav = playlists.firstOrNull { it.id == FAVORITES_ID }?.songIds?.contains(song.id) == true

    when (sub) {
        "details" -> { SongDetailsSheet(vm, song, onDismiss, onOpenFolder); return }
        "edit" -> { EditSongDialog(vm, song, onDismiss); return }
        "playlist" -> { AddToPlaylistDialog(vm, listOf(song.id), onDismiss); return }
        "rate" -> {
            RatingDialog(
                current = vm.ratingsStore.ratings.value[song.id] ?: 0,
                onSelect = { vm.setRating(song.id, it); onDismiss() },
                onDismiss = onDismiss,
            )
            return
        }
        "move" -> { MoveDialog(vm, onPick = { dir -> actions.move(listOf(song), dir); onDismiss() }, onDismiss = onDismiss); return }
        "delete" -> { ConfirmDeleteDialog(1, onConfirm = { actions.delete(listOf(song)); onDismiss() }, onDismiss = onDismiss); return }
    }

    val context = LocalContext.current
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(bottom = 24.dp)) {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                ArtImage(song.artUri, Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)), corner = 8.dp)
                Column(Modifier.padding(start = 12.dp)) {
                    Text(song.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "${song.artist} · pasta ${song.folderName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            OptionItem(Icons.Rounded.PlayArrow, "Tocar agora") { vm.playSongs(listOf(song), 0); onDismiss() }
            OptionItem(Icons.AutoMirrored.Rounded.PlaylistPlay, "Tocar a seguir") { vm.playNext(song); onDismiss() }
            OptionItem(Icons.AutoMirrored.Rounded.QueueMusic, "Adicionar à fila") { vm.addToQueue(song); onDismiss() }
            OptionItem(Icons.AutoMirrored.Rounded.PlaylistAdd, "Adicionar a uma playlist") { sub = "playlist" }
            OptionItem(
                if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                if (fav) "Tirar dos favoritos" else "Favoritar",
            ) { vm.toggleFavorite(song.id); onDismiss() }
            OptionItem(Icons.Rounded.Star, "Dar nota") { sub = "rate" }
            OptionItem(Icons.Rounded.Share, "Compartilhar") { actions.share(listOf(song)); onDismiss() }
            OptionItem(Icons.Rounded.Info, "Detalhes") { sub = "details" }
            OptionItem(Icons.Rounded.Edit, "Editar informações") { sub = "edit" }
            OptionItem(Icons.Rounded.DriveFileMove, "Mover para pasta") { sub = "move" }
            OptionItem(Icons.Rounded.SmartDisplay, "Abrir no YouTube") { openInYouTube(context, song.title, song.artist); onDismiss() }
            OptionItem(Icons.Rounded.Delete, "Apagar do celular", danger = true) { sub = "delete" }
        }
    }
}

@Composable
private fun OptionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    danger: Boolean = false,
    onClick: () -> Unit,
) {
    val color = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(22.dp))
        Text(label, color = color, modifier = Modifier.padding(start = 16.dp))
    }
}
