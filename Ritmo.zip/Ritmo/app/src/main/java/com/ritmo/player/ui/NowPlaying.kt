@file:OptIn(ExperimentalMaterial3Api::class)

package com.ritmo.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import com.ritmo.player.data.FAVORITES_ID
import kotlinx.coroutines.delay

// ---------------- Mini player (barra inferior) ----------------

@Composable
fun MiniPlayer(state: PlayerUiState, vm: MainViewModel, onClick: () -> Unit) {
    val position by rememberPlaybackPosition(vm)
    Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column {
            LinearProgressIndicator(
                progress = {
                    if (state.durationMs > 0) (position.toFloat() / state.durationMs).coerceIn(0f, 1f) else 0f
                },
                modifier = Modifier.fillMaxWidth().height(2.dp),
                drawStopIndicator = {},
            )
            Row(
                Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ArtImage(state.artUri, Modifier.size(44.dp))
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(state.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text(
                        state.artist,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = { vm.togglePlay() }) {
                    Icon(
                        if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        if (state.isPlaying) "Pausar" else "Tocar",
                    )
                }
                IconButton(onClick = { vm.next() }) { Icon(Icons.Rounded.SkipNext, "Próxima") }
            }
        }
    }
}

// ---------------- Tela "Tocando agora" ----------------

@Composable
fun NowPlayingScreen(vm: MainViewModel, onClose: () -> Unit) {
    val s by vm.player.collectAsStateWithLifecycle()
    val playlists by vm.playlistStore.playlists.collectAsStateWithLifecycle()
    val sleepEnd by vm.sleepTimerEnd.collectAsStateWithLifecycle()
    val songId = s.mediaId?.toLongOrNull()
    val isFavorite = songId != null &&
        playlists.firstOrNull { it.id == FAVORITES_ID }?.songIds?.contains(songId) == true

    var showQueue by remember { mutableStateOf(false) }
    var showSpeed by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    var showAddToPlaylist by remember { mutableStateOf(false) }

    if (!s.hasMedia) {
        LaunchedEffect(Unit) { onClose() }
        return
    }

    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(10_000)
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Fechar") }
                Text(
                    "Tocando agora",
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.weight(1f),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
                IconButton(onClick = { showQueue = true }) { Icon(Icons.AutoMirrored.Rounded.QueueMusic, "Fila") }
            }

            Spacer(Modifier.weight(0.5f))
            ArtImage(s.artUri, Modifier.fillMaxWidth().aspectRatio(1f), corner = 20.dp)
            Spacer(Modifier.height(28.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        s.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        listOf(s.artist, s.album).filter { it.isNotBlank() }.joinToString(" • "),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                IconButton(onClick = { songId?.let { vm.toggleFavorite(it) } }) {
                    Icon(
                        if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        "Favorita",
                        tint = if (isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            SeekBar(vm, s.durationMs)
            Spacer(Modifier.height(8.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val active = MaterialTheme.colorScheme.primary
                val inactive = MaterialTheme.colorScheme.onSurfaceVariant
                IconButton(onClick = { vm.toggleShuffle() }) {
                    Icon(Icons.Rounded.Shuffle, "Aleatório", tint = if (s.shuffle) active else inactive)
                }
                IconButton(onClick = { vm.previous() }, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Rounded.SkipPrevious, "Anterior", Modifier.size(36.dp))
                }
                FilledIconButton(onClick = { vm.togglePlay() }, modifier = Modifier.size(76.dp)) {
                    Icon(
                        if (s.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        if (s.isPlaying) "Pausar" else "Tocar",
                        Modifier.size(40.dp),
                    )
                }
                IconButton(onClick = { vm.next() }, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Rounded.SkipNext, "Próxima", Modifier.size(36.dp))
                }
                IconButton(onClick = { vm.cycleRepeat() }) {
                    Icon(
                        if (s.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        "Repetir",
                        tint = if (s.repeatMode == Player.REPEAT_MODE_OFF) inactive else active,
                    )
                }
            }

            Spacer(Modifier.weight(1f))

            Row(
                Modifier.fillMaxWidth().padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                TextButton(onClick = { showSpeed = true }) {
                    Icon(Icons.Rounded.Speed, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(formatSpeed(s.speed))
                }
                TextButton(onClick = { showSleep = true }) {
                    Icon(Icons.Rounded.Timer, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    val end = sleepEnd
                    Text(if (end == null) "Timer" else "${((end - now) / 60_000 + 1).coerceAtLeast(1)} min")
                }
                TextButton(onClick = { showAddToPlaylist = true }) {
                    Icon(Icons.AutoMirrored.Rounded.PlaylistAdd, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Playlist")
                }
            }
        }
    }

    if (showQueue) QueueSheet(s, vm) { showQueue = false }
    if (showSpeed) SpeedDialog(s.speed, onSelect = { vm.setSpeed(it); showSpeed = false }) { showSpeed = false }
    if (showSleep) SleepDialog(active = sleepEnd != null, onSelect = { vm.setSleepTimer(it); showSleep = false }) { showSleep = false }
    if (showAddToPlaylist && songId != null) AddToPlaylistDialog(vm, listOf(songId)) { showAddToPlaylist = false }
}

@Composable
private fun SeekBar(vm: MainViewModel, durationMs: Long) {
    val position by rememberPlaybackPosition(vm)
    var dragging by remember { mutableStateOf<Float?>(null) }
    val duration = durationMs.coerceAtLeast(1)
    val fraction = dragging ?: (position.toFloat() / duration).coerceIn(0f, 1f)

    Column(Modifier.fillMaxWidth()) {
        Slider(
            value = fraction,
            onValueChange = { dragging = it },
            onValueChangeFinished = {
                dragging?.let { vm.seekTo((it * duration).toLong()) }
                dragging = null
            },
        )
        Row(Modifier.fillMaxWidth()) {
            Text(
                formatTime(if (dragging != null) (fraction * duration).toLong() else position),
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.weight(1f),
            )
            Text(formatTime(durationMs), style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun QueueSheet(s: PlayerUiState, vm: MainViewModel, onDismiss: () -> Unit) {
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = s.queueIndex.coerceAtLeast(0))
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Text(
            "Fila de reprodução (${s.queue.size})",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
        )
        LazyColumn(state = listState, modifier = Modifier.fillMaxWidth()) {
            itemsIndexed(s.queue) { i, item ->
                val current = i == s.queueIndex
                ListItem(
                    colors = ListItemDefaults.colors(
                        containerColor = if (current) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                    ),
                    headlineContent = {
                        Text(
                            item.mediaMetadata.title?.toString() ?: "",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontWeight = if (current) FontWeight.Bold else null,
                        )
                    },
                    supportingContent = {
                        Text(item.mediaMetadata.artist?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    },
                    leadingContent = { ArtImage(item.mediaMetadata.artworkUri, Modifier.size(40.dp)) },
                    trailingContent = {
                        if (!current) {
                            IconButton(onClick = { vm.removeFromQueue(i) }) { Icon(Icons.Rounded.Close, "Remover da fila") }
                        }
                    },
                    modifier = Modifier.clickable { vm.playQueueIndex(i) },
                )
            }
        }
    }
}

@Composable
private fun SpeedDialog(current: Float, onSelect: (Float) -> Unit, onDismiss: () -> Unit) {
    val options = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
    OptionsDialog("Velocidade", options.map { formatSpeed(it) }, options.indexOf(current), { onSelect(options[it]) }, onDismiss)
}

@Composable
private fun SleepDialog(active: Boolean, onSelect: (Int?) -> Unit, onDismiss: () -> Unit) {
    val minutes = listOf<Int?>(null, 5, 10, 15, 30, 45, 60, 90)
    val labels = minutes.map { if (it == null) "Desligado" else "$it minutos" }
    OptionsDialog(
        "Parar a música depois de",
        labels,
        if (active) -1 else 0,
        { onSelect(minutes[it]) },
        onDismiss,
    )
}

@Composable
private fun OptionsDialog(
    title: String,
    labels: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                labels.forEachIndexed { i, label ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onSelect(i) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = i == selected, onClick = { onSelect(i) })
                        Text(label)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fechar") } },
    )
}

