package com.ritmo.player.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import kotlinx.coroutines.delay
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.ritmo.player.R
import com.ritmo.player.data.AppSettings
import com.ritmo.player.data.AppThemeId
import com.ritmo.player.data.FontStyleId
import com.ritmo.player.data.ThemeMode

val accentColors = listOf(
    Color(0xFF4F7DF3), // azul
    Color(0xFFE8505B), // vermelho
    Color(0xFF2BB673), // verde
    Color(0xFFF2A93B), // laranja
    Color(0xFF9B5DE5), // roxo
    Color(0xFF14B8C4), // ciano
)
val accentNames = listOf("Azul", "Vermelho", "Verde", "Laranja", "Roxo", "Ciano")

/** Cores para as letras (usadas com tema pronto ou papel de parede). */
val textColorOptions = listOf(
    Color(0xFFFFFFFF), // branco
    Color(0xFFFAEEDA), // creme
    Color(0xFFFFD86B), // amarelo
    Color(0xFFF8B4CF), // rosa
    Color(0xFF9FE8DC), // ciano
    Color(0xFFC8E6A0), // verde
)
val textColorNames = listOf("Branco", "Creme", "Amarelo", "Rosa", "Ciano", "Verde")

/** Cores de destaque (botões, barrinhas, ícones ativos). */
val highlightOptions = listOf(
    Color(0xFFFF6FA5), // rosa
    Color(0xFF9D8CFF), // roxo
    Color(0xFF4FD8B0), // verde-água
    Color(0xFFFFA940), // laranja
    Color(0xFF5AA9FF), // azul
    Color(0xFFFF5C5C), // vermelho
    Color(0xFFFFD54A), // amarelo
)
val highlightNames = listOf("Rosa", "Roxo", "Verde-água", "Laranja", "Azul", "Vermelho", "Amarelo")

fun fontFamilyFor(style: FontStyleId): FontFamily? = when (style) {
    FontStyleId.DEFAULT -> null
    FontStyleId.MODERN -> FontFamily(
        Font(R.font.outfit_regular, FontWeight.Normal),
        Font(R.font.outfit_bold, FontWeight.Bold),
    )
    FontStyleId.CLASSIC -> FontFamily(
        Font(R.font.lora_regular, FontWeight.Normal),
        Font(R.font.lora_bold, FontWeight.Bold),
    )
    FontStyleId.HANDWRITTEN -> FontFamily(Font(R.font.nothing_you_could_do))
    FontStyleId.FUTURISTIC -> FontFamily(
        Font(R.font.tektur_regular, FontWeight.Normal),
        Font(R.font.tektur_medium, FontWeight.Medium),
    )
    FontStyleId.PIXEL -> FontFamily(Font(R.font.pixelify_sans))
    FontStyleId.ELEGANT -> FontFamily(Font(R.font.poiret_one))
}

/** Aplica a fonte escolhida em todos os tamanhos de texto do app. */
fun typographyFor(family: FontFamily?): Typography {
    val t = Typography()
    if (family == null) return t
    return Typography(
        displayLarge = t.displayLarge.copy(fontFamily = family),
        displayMedium = t.displayMedium.copy(fontFamily = family),
        displaySmall = t.displaySmall.copy(fontFamily = family),
        headlineLarge = t.headlineLarge.copy(fontFamily = family),
        headlineMedium = t.headlineMedium.copy(fontFamily = family),
        headlineSmall = t.headlineSmall.copy(fontFamily = family),
        titleLarge = t.titleLarge.copy(fontFamily = family),
        titleMedium = t.titleMedium.copy(fontFamily = family),
        titleSmall = t.titleSmall.copy(fontFamily = family),
        bodyLarge = t.bodyLarge.copy(fontFamily = family),
        bodyMedium = t.bodyMedium.copy(fontFamily = family),
        bodySmall = t.bodySmall.copy(fontFamily = family),
        labelLarge = t.labelLarge.copy(fontFamily = family),
        labelMedium = t.labelMedium.copy(fontFamily = family),
        labelSmall = t.labelSmall.copy(fontFamily = family),
    )
}

/** Cores de cada tema pronto: degradê do fundo, cor principal, secundária e cor das caixas. */
data class ThemePreset(
    val top: Color,
    val bottom: Color,
    val primary: Color,
    val secondary: Color,
    val container: Color,
)

fun presetFor(id: AppThemeId): ThemePreset? = when (id) {
    AppThemeId.DEFAULT -> null
    // Tudo preto, letras brancas e destaques em branco/cinza claro
    AppThemeId.BLACK -> ThemePreset(
        top = Color(0xFF000000), bottom = Color(0xFF000000),
        primary = Color(0xFFEDEDED), secondary = Color(0xFFBDBDBD), container = Color(0xFF0E0E0E),
    )
    AppThemeId.MIDNIGHT -> ThemePreset(
        top = Color(0xFF2A2468), bottom = Color(0xFF0B0A1F),
        primary = Color(0xFFB7B0FF), secondary = Color(0xFF7F9CFF), container = Color(0xFF1B1840),
    )
    AppThemeId.NEON -> ThemePreset(
        top = Color(0xFF1A0820), bottom = Color(0xFF020203),
        primary = Color(0xFFFF4FA3), secondary = Color(0xFF2EE6D6), container = Color(0xFF151018),
    )
    AppThemeId.SUNSET -> ThemePreset(
        top = Color(0xFF7A2A14), bottom = Color(0xFF1C0A07),
        primary = Color(0xFFFFB04A), secondary = Color(0xFFFF6B5A), container = Color(0xFF2E140D),
    )
    AppThemeId.OCEAN -> ThemePreset(
        top = Color(0xFF0E4A73), bottom = Color(0xFF04121F),
        primary = Color(0xFF4FD8CB), secondary = Color(0xFF6CB8FF), container = Color(0xFF0B2438),
    )
    AppThemeId.FOREST -> ThemePreset(
        top = Color(0xFF2B5216), bottom = Color(0xFF07120A),
        primary = Color(0xFFA6DB6E), secondary = Color(0xFFE3D27A), container = Color(0xFF13250D),
    )
}

/** Fundo transparente: o degradê do tema ou o papel de parede aparece por trás de tudo. */
fun themedScheme(primary: Color, secondary: Color, container: Color, text: Color = Color.White): ColorScheme = darkColorScheme(
    primary = primary,
    onPrimary = if (primary.luminance() > 0.5f) Color.Black else Color.White,
    primaryContainer = primary.copy(alpha = 0.28f),
    onPrimaryContainer = text,
    secondary = secondary,
    onSecondary = Color.Black,
    secondaryContainer = primary.copy(alpha = 0.22f),
    onSecondaryContainer = primary,
    tertiary = secondary,
    background = Color.Transparent,
    onBackground = text,
    surface = Color.Transparent,
    onSurface = text,
    surfaceVariant = Color.White.copy(alpha = 0.10f),
    onSurfaceVariant = text.copy(alpha = 0.72f),
    surfaceTint = primary,
    surfaceContainerLowest = container,
    surfaceContainerLow = container,
    surfaceContainer = container.copy(alpha = 0.94f),
    surfaceContainerHigh = lerp(container, Color.White, 0.06f),
    surfaceContainerHighest = lerp(container, Color.White, 0.10f),
    outline = Color.White.copy(alpha = 0.35f),
    outlineVariant = Color.White.copy(alpha = 0.15f),
)

/** O app está usando um tema pronto ou papel de parede (sempre escuro). */
fun AppSettings.isThemed(): Boolean = wallpaperPath != null || themeId != AppThemeId.DEFAULT

@Composable
fun isAppDark(settings: AppSettings): Boolean =
    settings.isThemed() || when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.AUTO_TIME -> isNightNow()
    }

/** Tema automático: escuro das 18h às 6h. Confere de novo a cada minuto. */
@Composable
private fun isNightNow(): Boolean {
    val night by produceState(initialValue = nightHour()) {
        while (true) {
            value = nightHour()
            delay(60_000)
        }
    }
    return night
}

private fun nightHour(): Boolean {
    val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return h >= 18 || h < 6
}

/**
 * @param wallpaperAccent cor de destaque e cor escura tiradas do papel de parede (quando houver).
 */
@Composable
fun RitmoTheme(
    settings: AppSettings,
    wallpaperAccent: Pair<Color, Color>? = null,
    content: @Composable () -> Unit,
) {
    val dark = isAppDark(settings)
    val context = LocalContext.current
    val preset = presetFor(settings.themeId)
    val chosenHighlight = highlightOptions.getOrNull(settings.highlight)

    val scheme = if (settings.isThemed()) {
        // Tema pronto e/ou papel de parede: os dois funcionam juntos.
        // O papel de parede é o fundo; as cores vêm do tema (ou da foto, no tema Padrão).
        val autoAccent = preset?.primary ?: wallpaperAccent?.first ?: Color(0xFFB7B0FF)
        val primary = chosenHighlight ?: autoAccent
        val secondary = if (chosenHighlight != null) chosenHighlight else preset?.secondary ?: primary
        val container = preset?.container
            ?: lerp(wallpaperAccent?.second ?: Color(0xFF15151A), Color.Black, 0.45f)
        val text = textColorOptions.getOrNull(settings.textColor) ?: lerp(autoAccent, Color.White, 0.55f)
        themedScheme(primary, secondary, container, text)
    } else {
        val base = if (settings.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        } else {
            val accent = accentColors[settings.accent.coerceIn(accentColors.indices)]
            if (dark) {
                darkColorScheme(
                    primary = accent,
                    secondary = accent,
                    tertiary = accent,
                    background = Color(0xFF0F1013),
                    surface = Color(0xFF0F1013),
                    onPrimary = Color.White,
                )
            } else {
                lightColorScheme(primary = accent, secondary = accent, tertiary = accent, onPrimary = Color.White)
            }
        }
        if (chosenHighlight != null) {
            base.copy(
                primary = chosenHighlight,
                onPrimary = if (chosenHighlight.luminance() > 0.5f) Color.Black else Color.White,
                secondary = chosenHighlight,
                tertiary = chosenHighlight,
                primaryContainer = chosenHighlight.copy(alpha = 0.25f),
                secondaryContainer = chosenHighlight.copy(alpha = 0.22f),
            )
        } else base
    }
    val typography = remember(settings.fontStyle) { typographyFor(fontFamilyFor(settings.fontStyle)) }
    MaterialTheme(colorScheme = scheme, typography = typography, content = content)
}
