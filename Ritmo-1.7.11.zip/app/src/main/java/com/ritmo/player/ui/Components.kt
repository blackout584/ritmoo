@file:OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.ritmo.player.ui

import android.net.Uri
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import kotlinx.coroutines.launch
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Checklist
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.PlaylistRemove
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Surface
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.animation.core.animateFloat
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.RowScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.ritmo.player.data.Song
import com.ritmo.player.data.SongSort
import kotlinx.coroutines.delay

fun formatTime(ms: Long): String {
    val totalSec = (ms / 1000).coerceAtLeast(0)
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

fun formatSpeed(speed: Float): String {
    val text = if (speed % 1f == 0f) speed.toInt().toString() else speed.toString()
    return text.replace('.', ',') + "x"
}

@Composable
fun SimpleTopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    TopAppBar(
        title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        navigationIcon = {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Voltar")
                }
            }
        },
        actions = actions,
        windowInsets = WindowInsets(0, 0, 0, 0),
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
    )
}

@Composable
fun ArtImage(uri: Uri?, modifier: Modifier = Modifier, corner: Dp = 8.dp, zoom: Float = 1f) {
    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            Icons.Rounded.MusicNote, null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxSize(0.45f),
        )
        if (uri != null) {
            AsyncImage(
                model = uri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = zoom; scaleY = zoom },
            )
        }
    }
}

@Composable
fun EmptyMessage(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(
            text,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** Posição atual da música, atualizada duas vezes por segundo. */
@Composable
fun rememberPlaybackPosition(vm: MainViewModel): State<Long> {
    val pos = remember { mutableLongStateOf(vm.positionMs()) }
    LaunchedEffect(Unit) {
        while (true) {
            pos.longValue = vm.positionMs()
            delay(500)
        }
    }
    return pos
}

@Composable
fun SongList(
    songs: List<Song>,
    vm: MainViewModel,
    playlistId: Long? = null,
    header: (@Composable () -> Unit)? = null,
    sortControl: (@Composable () -> Unit)? = null,
    /** Quando informado, mostra a barrinha A–Z do lado (letra de cada música). */
    letterOf: ((Song) -> String)? = null,
) {
    val player by vm.player.collectAsStateWithLifecycle()
    val ratings by vm.ratingsStore.ratings.collectAsStateWithLifecycle()
    val actions = rememberMediaActions(vm)
    val listState = rememberLazyListState()
    var editing by remember { mutableStateOf<Song?>(null) }

    // ----- Modo de seleção (segurar uma música) -----
    var selected by remember { mutableStateOf(emptySet<Long>()) }
    // O botão "selecionar" abre o modo de seleção mesmo sem nada marcado
    var selectMode by remember { mutableStateOf(false) }
    val selecting = selectMode || selected.isNotEmpty()
    val selectedSongs = remember(songs, selected) { songs.filter { it.id in selected } }
    var confirmDelete by remember { mutableStateOf<List<Song>?>(null) }
    var moving by remember { mutableStateOf<List<Song>?>(null) }
    var addToPlaylist by remember { mutableStateOf<List<Long>?>(null) }

    // Se uma música sumir (apagada/movida), tira da seleção
    LaunchedEffect(songs) {
        val ids = songs.map { it.id }.toSet()
        selected = selected.filter { it in ids }.toSet()
    }
    BackHandler(enabled = selecting) { selected = emptySet(); selectMode = false }

    fun toggle(id: Long) {
        selected = if (id in selected) selected - id else selected + id
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            state = listState,
            contentPadding = PaddingValues(
                top = if (selecting) 64.dp else 0.dp,
                bottom = if (selecting) 96.dp else 0.dp,
            ),
        ) {
            if (header != null) item(key = "header") { header() }
            item(key = "top") {
                // "▶ Reprodução aleatória" com ordenar e selecionar ao lado
                Row(
                    Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(24.dp))
                            .clickable(enabled = songs.isNotEmpty()) { vm.shuffleAll(songs) }
                            .padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier.size(32.dp).clip(CircleShape).background(MaterialTheme.colorScheme.onSurface),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Rounded.PlayArrow, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.surfaceContainerLow)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Reprodução aleatória", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                "${songs.size} músicas",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    sortControl?.invoke()
                    IconButton(onClick = { selectMode = true }, enabled = songs.isNotEmpty()) {
                        Icon(Icons.Rounded.Checklist, "Selecionar várias")
                    }
                }
            }
            itemsIndexed(songs, key = { i, s -> "${s.id}_$i" }) { i, song ->
                SongRow(
                    song = song,
                    isCurrent = player.mediaId == song.id.toString(),
                    isPlaying = player.isPlaying,
                    vm = vm,
                    playlistId = playlistId,
                    selecting = selecting,
                    isSelected = song.id in selected,
                    onClick = { if (selecting) toggle(song.id) else vm.playSongs(songs, i) },
                    onLongClick = { toggle(song.id) },
                    onShare = { actions.share(listOf(song)) },
                    onDelete = { confirmDelete = listOf(song) },
                    onEdit = { editing = song },
                    rating = ratings[song.id] ?: 0,
                    modifier = Modifier.animateItem(),
                )
            }
        }

        // Barrinha A–Z para pular direto para uma letra
        if (letterOf != null && !selecting && songs.size > 30) {
            FastScrollRail(
                songs = songs,
                letterOf = letterOf,
                itemOffset = (if (header != null) 1 else 0) + 1,
                listState = listState,
                modifier = Modifier.align(Alignment.CenterEnd),
            )
        }

        // Barra "3 selecionadas" no topo
        AnimatedVisibility(
            visible = selecting,
            enter = slideInVertically { -it } + fadeIn(),
            exit = slideOutVertically { -it } + fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter),
        ) {
            SelectionBar(
                count = selected.size,
                allSelected = selected.size == songs.size,
                onClose = { selected = emptySet(); selectMode = false },
                onToggleAll = {
                    selected = if (selected.size == songs.size) emptySet() else songs.map { it.id }.toSet()
                },
            )
        }

        // Barra de ações na parte de baixo
        AnimatedVisibility(
            visible = selecting,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter),
        ) {
            SelectionActions(
                inPlaylist = playlistId != null,
                onPlay = { vm.playSongs(selectedSongs, 0); selected = emptySet(); selectMode = false },
                onQueue = { vm.addAllToQueue(selectedSongs); selected = emptySet(); selectMode = false },
                onPlaylist = { addToPlaylist = selectedSongs.map { it.id } },
                onShare = { actions.share(selectedSongs) },
                onMove = { moving = selectedSongs },
                onDelete = { confirmDelete = selectedSongs },
                onRemoveFromPlaylist = {
                    playlistId?.let { id -> selectedSongs.forEach { vm.playlistStore.removeSong(id, it.id) } }
                    selected = emptySet(); selectMode = false
                },
            )
        }
    }

    confirmDelete?.let { list ->
        ConfirmDeleteDialog(
            count = list.size,
            onConfirm = {
                confirmDelete = null
                actions.delete(list)
                selected = emptySet(); selectMode = false
            },
            onDismiss = { confirmDelete = null },
        )
    }
    moving?.let { list ->
        MoveDialog(
            vm = vm,
            onPick = { dir ->
                moving = null
                actions.move(list, dir)
                selected = emptySet(); selectMode = false
            },
            onDismiss = { moving = null },
        )
    }
    editing?.let { song -> EditSongDialog(vm, song) { editing = null } }
    addToPlaylist?.let { ids ->
        AddToPlaylistDialog(vm, ids) {
            addToPlaylist = null
            selected = emptySet(); selectMode = false
        }
    }
}

@Composable
private fun SelectionBar(count: Int, allSelected: Boolean, onClose: () -> Unit, onToggleAll: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        contentColor = MaterialTheme.colorScheme.onSurface,
        shape = RoundedCornerShape(16.dp),
        shadowElevation = 6.dp,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Sair da seleção") }
            Text(
                if (count == 1) "1 selecionada" else "$count selecionadas",
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onToggleAll) {
                Icon(Icons.Rounded.DoneAll, null, Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text(if (allSelected) "Nenhuma" else "Todas")
            }
        }
    }
}

@Composable
private fun SelectionActions(
    inPlaylist: Boolean,
    onPlay: () -> Unit,
    onQueue: () -> Unit,
    onPlaylist: () -> Unit,
    onShare: () -> Unit,
    onMove: () -> Unit,
    onDelete: () -> Unit,
    onRemoveFromPlaylist: () -> Unit,
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        shape = RoundedCornerShape(20.dp),
        tonalElevation = 6.dp,
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth().padding(12.dp),
    ) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp, horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            ActionItem(Icons.Rounded.PlayArrow, "Tocar", onPlay, highlight = true)
            ActionItem(Icons.AutoMirrored.Rounded.QueueMusic, "Fila", onQueue)
            ActionItem(Icons.AutoMirrored.Rounded.PlaylistAdd, "Playlist", onPlaylist)
            ActionItem(Icons.Rounded.Share, "Enviar", onShare)
            ActionItem(Icons.Rounded.DriveFileMove, "Mover", onMove)
            if (inPlaylist) ActionItem(Icons.Rounded.PlaylistRemove, "Tirar", onRemoveFromPlaylist)
            ActionItem(Icons.Rounded.Delete, "Apagar", onDelete, danger = true)
        }
    }
}

@Composable
private fun ActionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    highlight: Boolean = false,
    danger: Boolean = false,
) {
    val tint = when {
        danger -> MaterialTheme.colorScheme.error
        highlight -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.onSurface
    }
    Column(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, label, tint = tint)
        Text(label, style = MaterialTheme.typography.labelSmall, color = tint)
    }
}

@Composable
fun SongRow(
    song: Song,
    isCurrent: Boolean,
    isPlaying: Boolean,
    vm: MainViewModel,
    playlistId: Long?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selecting: Boolean = false,
    isSelected: Boolean = false,
    onLongClick: () -> Unit = {},
    onShare: () -> Unit = {},
    onDelete: () -> Unit = {},
    onEdit: () -> Unit = {},
    rating: Int = 0,
) {
    var menu by remember { mutableStateOf(false) }
    var addDialog by remember { mutableStateOf(false) }
    var rateDialog by remember { mutableStateOf(false) }
    val haptics = LocalHapticFeedback.current
    val context = LocalContext.current
    val rowColor by animateColorAsState(
        if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
        label = "rowColor",
    )
    Row(
        modifier
            .fillMaxWidth()
            .background(rowColor)
            .combinedClickable(
                onClick = onClick,
                onLongClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLongClick()
                },
            )
            .padding(start = 14.dp, end = 2.dp, top = 5.dp, bottom = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
            Box(contentAlignment = Alignment.Center) {
                ArtImage(song.artUri, Modifier.size(42.dp))
                when {
                    selecting -> Box(
                        Modifier.size(42.dp).clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = if (isSelected) 0.55f else 0.25f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            if (isSelected) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                            null,
                            tint = if (isSelected) MaterialTheme.colorScheme.primary else Color.White,
                        )
                    }
                    // Mini barrinhas animadas na música que está tocando
                    isCurrent -> Box(
                        Modifier.size(42.dp).clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.45f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        PlayingIndicator(isPlaying, MaterialTheme.colorScheme.primary)
                    }
                }
            }
        Column(Modifier.weight(1f).padding(start = 12.dp, end = 4.dp)) {
            Text(
                song.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyLarge,
                color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                fontWeight = if (isCurrent) FontWeight.Bold else null,
            )
            Text(
                "${song.artist} | ${song.album}" + if (rating > 0) "  ${starsText(rating)}" else "",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
            if (!selecting) Box {
                IconButton(onClick = { menu = true }, modifier = Modifier.size(40.dp)) { Icon(Icons.Rounded.MoreVert, "Opções", Modifier.size(20.dp)) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Tocar a seguir") },
                        onClick = { vm.playNext(song); menu = false },
                    )
                    DropdownMenuItem(
                        text = { Text("Adicionar à fila") },
                        onClick = { vm.addToQueue(song); menu = false },
                    )
                    DropdownMenuItem(
                        text = { Text("Adicionar à playlist") },
                        onClick = { addDialog = true; menu = false },
                    )
                    DropdownMenuItem(
                        text = { Text(if (rating > 0) "Nota: ${starsText(rating)}" else "Dar nota") },
                        onClick = { rateDialog = true; menu = false },
                    )
                    DropdownMenuItem(
                        text = { Text("Editar informações") },
                        onClick = { onEdit(); menu = false },
                    )
                    DropdownMenuItem(
                        text = { Text("Compartilhar") },
                        onClick = { onShare(); menu = false },
                    )
                    DropdownMenuItem(
                        text = { Text("Abrir no YouTube") },
                        onClick = { openInYouTube(context, song); menu = false },
                    )
                    DropdownMenuItem(
                        text = { Text("Abrir no YouTube Music") },
                        onClick = { openInYouTubeMusic(context, song); menu = false },
                    )
                    DropdownMenuItem(
                        text = { Text("Selecionar várias") },
                        onClick = { onLongClick(); menu = false },
                    )
                    if (playlistId != null) {
                        DropdownMenuItem(
                            text = { Text("Remover da playlist") },
                            onClick = { vm.playlistStore.removeSong(playlistId, song.id); menu = false },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("Apagar", color = MaterialTheme.colorScheme.error) },
                        onClick = { onDelete(); menu = false },
                    )
                }
            }
    }
    if (addDialog) AddToPlaylistDialog(vm, listOf(song.id)) { addDialog = false }
    if (rateDialog) {
        RatingDialog(rating, onSelect = { vm.setRating(song.id, it); rateDialog = false }) { rateDialog = false }
    }
}

@Composable
fun AddToPlaylistDialog(vm: MainViewModel, songIds: List<Long>, onDismiss: () -> Unit) {
    val playlists by vm.playlistStore.playlists.collectAsStateWithLifecycle()
    var creating by remember { mutableStateOf(false) }
    val context = LocalContext.current

    if (creating) {
        NameDialog(
            title = "Nova playlist",
            initial = "",
            confirmLabel = "Criar",
            onConfirm = { name ->
                val p = vm.playlistStore.create(name)
                vm.playlistStore.addSongs(p.id, songIds)
                Toast.makeText(context, "Adicionada a $name", Toast.LENGTH_SHORT).show()
                onDismiss()
            },
            onDismiss = { creating = false },
        )
        return
    }

    val transparent = ListItemDefaults.colors(containerColor = Color.Transparent)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Adicionar à playlist") },
        text = {
            LazyColumn {
                item {
                    ListItem(
                        colors = transparent,
                        leadingContent = { Icon(Icons.Rounded.Add, null) },
                        headlineContent = { Text("Nova playlist") },
                        modifier = Modifier.clickable { creating = true },
                    )
                }
                items(playlists, key = { it.id }) { p ->
                    ListItem(
                        colors = transparent,
                        headlineContent = { Text(p.name) },
                        supportingContent = { Text("${p.songIds.size} músicas") },
                        modifier = Modifier.clickable {
                            vm.playlistStore.addSongs(p.id, songIds)
                            Toast.makeText(context, "Adicionada a ${p.name}", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        },
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                label = { Text("Nome") },
            )
        },
        confirmButton = {
            TextButton(enabled = text.isNotBlank(), onClick = { onConfirm(text.trim()) }) {
                Text(confirmLabel)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
fun GroupRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    trailing: (@Composable () -> Unit)? = null,
) {
    ListItem(
        modifier = Modifier.clickable(onClick = onClick),
        leadingContent = {
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(24.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        },
        headlineContent = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        supportingContent = { Text(subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        trailingContent = trailing,
    )
}


/** Três barrinhas que pulam, mostrando a música que está tocando. */
@Composable
fun PlayingIndicator(isPlaying: Boolean, color: Color) {
    val transition = androidx.compose.animation.core.rememberInfiniteTransition(label = "eq")
    Row(
        Modifier.size(width = 20.dp, height = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        listOf(420, 560, 360).forEachIndexed { i, duration ->
            val animated by transition.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                    androidx.compose.animation.core.tween(duration),
                    androidx.compose.animation.core.RepeatMode.Reverse,
                ),
                label = "bar$i",
            )
            val h = if (isPlaying) animated else 0.3f
            Box(
                Modifier.weight(1f).fillMaxHeight(h)
                    .clip(RoundedCornerShape(2.dp))
                    .background(color)
            )
        }
    }
}

/** Botão "Ordenar" com a lista de opções. */
@Composable
fun SortButton(current: SongSort, onSelect: (SongSort) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) {
            Icon(Icons.Rounded.SwapVert, "Ordenar: ${current.label}")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            Text(
                "Ordenar por",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            )
            SongSort.entries.forEach { option ->
                DropdownMenuItem(
                    text = {
                        Text(
                            option.label,
                            fontWeight = if (option == current) FontWeight.Bold else null,
                            color = if (option == current) MaterialTheme.colorScheme.primary else Color.Unspecified,
                        )
                    },
                    leadingIcon = {
                        if (option == current) Icon(Icons.Rounded.Check, null, tint = MaterialTheme.colorScheme.primary)
                        else Spacer(Modifier.size(24.dp))
                    },
                    onClick = { onSelect(option); open = false },
                )
            }
        }
    }
}

/** Primeira letra sem acento (Á → A). Números e símbolos viram "#". */
fun firstLetter(text: String): String {
    val c = java.text.Normalizer.normalize(text.trim().take(1), java.text.Normalizer.Form.NFD)
        .firstOrNull()?.uppercaseChar() ?: return "#"
    return if (c in 'A'..'Z') c.toString() else "#"
}

/** Barrinha de letras do lado da lista: toque ou arraste para pular. */
@Composable
private fun FastScrollRail(
    songs: List<Song>,
    letterOf: (Song) -> String,
    itemOffset: Int,
    listState: androidx.compose.foundation.lazy.LazyListState,
    modifier: Modifier = Modifier,
) {
    val firstIndex = remember(songs) {
        val map = LinkedHashMap<String, Int>()
        songs.forEachIndexed { i, s -> map.putIfAbsent(letterOf(s), i) }
        map
    }
    val letters = remember(firstIndex) { firstIndex.keys.toList() }
    if (letters.size < 2) return
    val scope = rememberCoroutineScope()
    var active by remember { mutableStateOf<String?>(null) }
    var railHeight by remember { mutableStateOf(1) }

    fun jump(y: Float) {
        val i = (y / railHeight * letters.size).toInt().coerceIn(0, letters.size - 1)
        val letter = letters[i]
        if (letter != active) {
            active = letter
            scope.launch { listState.scrollToItem(itemOffset + (firstIndex[letter] ?: 0)) }
        }
    }

    Row(modifier.padding(end = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        // Balão com a letra atual enquanto arrasta
        active?.let {
            Box(
                Modifier.size(52.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center,
            ) {
                Text(it, color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.headlineSmall)
            }
            Spacer(Modifier.width(8.dp))
        }
        Column(
            Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.6f))
                .onSizeChanged { railHeight = it.height.coerceAtLeast(1) }
                .pointerInput(letters) {
                    detectTapGestures(
                        onPress = { offset ->
                            jump(offset.y)
                            tryAwaitRelease()
                            active = null
                        },
                    )
                }
                .pointerInput(letters) {
                    detectVerticalDragGestures(
                        onDragStart = { jump(it.y) },
                        onDragEnd = { active = null },
                        onDragCancel = { active = null },
                    ) { change, _ ->
                        change.consume()
                        jump(change.position.y)
                    }
                }
                .padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            letters.forEach { letter ->
                Text(
                    letter,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = if (letter == active) FontWeight.Bold else null,
                    color = if (letter == active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
