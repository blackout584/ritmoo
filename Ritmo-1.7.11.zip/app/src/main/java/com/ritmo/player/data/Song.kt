package com.ritmo.player.data

import android.content.ContentUris
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val trackNumber: Int,
    val folderPath: String,
    val folderName: String,
    val uri: Uri,
    val dateAdded: Long = 0, // segundos desde 1970
    val path: String = "",
    /** Capa escolhida por você no editor (só dentro do Ritmo). */
    val customArt: Uri? = null,
) {
    /** Pasta relativa ao armazenamento interno (ex.: "Music/Rap/"), ou null se estiver no cartão SD. */
    val relativeDir: String?
        get() {
            val root = "/storage/emulated/0/"
            if (!path.startsWith(root)) return null
            val dir = path.removePrefix(root).substringBeforeLast('/', "")
            return if (dir.isEmpty()) "" else "$dir/"
        }

    val artUri: Uri
        get() = customArt ?: ContentUris.withAppendedId(ALBUM_ART_BASE, albumId)

    companion object {
        private val ALBUM_ART_BASE: Uri = Uri.parse("content://media/external/audio/albumart")
    }
}

fun Song.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        // A URI também vai no RequestMetadata para sobreviver à passagem controller -> serviço.
        .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(uri).build())
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(artUri)
                .setIsPlayable(true)
                .setIsBrowsable(false)
                .build()
        )
        .build()
