package com.ritmo.player.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class Playlist(val id: Long, val name: String, val songIds: List<Long>)

const val FAVORITES_ID = -1L

/** Guarda as playlists no próprio aparelho (JSON em SharedPreferences). */
class PlaylistStore(context: Context) {
    private val prefs = context.getSharedPreferences("playlists", Context.MODE_PRIVATE)
    private val _playlists = MutableStateFlow(load())
    val playlists: StateFlow<List<Playlist>> = _playlists.asStateFlow()

    fun create(name: String): Playlist {
        val p = Playlist(System.currentTimeMillis(), name, emptyList())
        save(_playlists.value + p)
        return p
    }

    fun rename(id: Long, name: String) =
        save(_playlists.value.map { if (it.id == id) it.copy(name = name) else it })

    fun delete(id: Long) {
        if (id == FAVORITES_ID) return
        save(_playlists.value.filterNot { it.id == id })
    }

    fun addSongs(id: Long, songIds: List<Long>) =
        save(_playlists.value.map { p ->
            if (p.id == id) p.copy(songIds = p.songIds + songIds.filterNot { it in p.songIds }) else p
        })

    /** Troca uma música por outra em todas as playlists (usado ao apagar cópias duplicadas). */
    fun replaceSong(oldId: Long, newId: Long) =
        save(_playlists.value.map { p ->
            if (oldId !in p.songIds) p
            else if (newId in p.songIds) p.copy(songIds = p.songIds - oldId)
            else p.copy(songIds = p.songIds.map { if (it == oldId) newId else it })
        })

    fun removeSong(id: Long, songId: Long) =
        save(_playlists.value.map { if (it.id == id) it.copy(songIds = it.songIds - songId) else it })

    fun isFavorite(songId: Long): Boolean =
        _playlists.value.firstOrNull { it.id == FAVORITES_ID }?.songIds?.contains(songId) == true

    fun toggleFavorite(songId: Long) {
        if (isFavorite(songId)) removeSong(FAVORITES_ID, songId) else addSongs(FAVORITES_ID, listOf(songId))
    }

    private fun save(list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("songs", JSONArray(p.songIds))
            })
        }
        prefs.edit().putString("data", arr.toString()).apply()
        _playlists.value = list
    }

    private fun load(): List<Playlist> {
        val list = runCatching {
            val arr = JSONArray(prefs.getString("data", "[]"))
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val songs = o.getJSONArray("songs")
                Playlist(
                    id = o.getLong("id"),
                    name = o.getString("name"),
                    songIds = (0 until songs.length()).map { songs.getLong(it) },
                )
            }
        }.getOrDefault(emptyList())
        return if (list.none { it.id == FAVORITES_ID }) {
            listOf(Playlist(FAVORITES_ID, "Favoritas", emptyList())) + list
        } else list
    }
}
