package com.ritmo.player.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode { SYSTEM, LIGHT, DARK, AUTO_TIME }

enum class AppThemeId(val label: String) {
    DEFAULT("Padrão"),
    BLACK("Preto"),
    MIDNIGHT("Meia-noite"),
    NEON("Neon"),
    SUNSET("Pôr do sol"),
    OCEAN("Oceano"),
    FOREST("Floresta"),
}

enum class FontStyleId(val label: String) {
    DEFAULT("Padrão"),
    MODERN("Moderna"),
    CLASSIC("Clássica"),
    HANDWRITTEN("Manuscrita"),
    FUTURISTIC("Futurista"),
    PIXEL("Pixel"),
    ELEGANT("Elegante"),
}

enum class PlayMode(val label: String) {
    ONE("Repetir esta música"),
    SHUFFLE("Aleatório"),
    ALL("Repetir tudo"),
    ORDER("Tocar em ordem"),
}

enum class PlayerStyle(val label: String) {
    PADRAO("Padrão"),
    VINIL_MODERNO("Vinil Moderno"),
    VINIL_CLASSICO("Vinil Clássico"),
    CD("CD"),
    CASSETE("Cassete"),
}

/** Tamanho geral da interface (capas, listas, botões e espaços). */
enum class UiSize(val label: String, val factor: Float) {
    COMPACT("Compacto", 0.9f),
    NORMAL("Normal", 1f),
    LARGE("Grande", 1.12f),
}

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accent: Int = 0,
    val dynamicColor: Boolean = true,
    val minDurationSec: Int = 10,
    val vinylArt: Boolean = true,
    val visualizer: Boolean = true,
    val songSort: SongSort = SongSort.TITLE_ASC,
    val themeId: AppThemeId = AppThemeId.DEFAULT,
    val wallpaperPath: String? = null,
    val wallpaperDim: Float = 0.55f,
    val wallpaperBlur: Float = 0f,
    val playMode: PlayMode = PlayMode.ORDER,
    /** Cor de destaque escolhida (índice), ou -1 para automática. */
    val highlight: Int = -1,
    /** Cor das letras (índice), ou -1 para a cor da foto/tema. */
    val textColor: Int = 0,
    val fontStyle: FontStyleId = FontStyleId.DEFAULT,
    /** Transição suave entre músicas, em segundos (0 = desligada). */
    val fadeSeconds: Int = 0,
    val resumePlayback: Boolean = true,
    val animatedPlayerBg: Boolean = true,
    /** Pastas escondidas da Biblioteca (caminho completo). */
    val hiddenFolders: Set<String> = emptySet(),
    /** Tamanho das letras do app (1 = normal). */
    val fontScale: Float = 1f,
    val autoUpdateCheck: Boolean = true,
    val lastUpdateCheck: Long = 0,
    val playerStyle: PlayerStyle = PlayerStyle.VINIL_CLASSICO,
    val uiSize: UiSize = UiSize.NORMAL,
    /** Mostrar o papel de parede atrás da tela do player. */
    val wallpaperInPlayer: Boolean = false,
)

/** Use sempre SettingsStore.get(context): uma só instância para o app e o serviço de música. */
class SettingsStore private constructor(context: Context) {

    companion object {
        @Volatile private var instance: SettingsStore? = null
        fun get(context: Context): SettingsStore =
            instance ?: synchronized(this) {
                instance ?: SettingsStore(context.applicationContext).also { instance = it }
            }
    }

    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    fun update(transform: (AppSettings) -> AppSettings) {
        val s = transform(_settings.value)
        prefs.edit()
            .putString("theme", s.themeMode.name)
            .putInt("accent", s.accent)
            .putBoolean("dynamic", s.dynamicColor)
            .putInt("minDuration", s.minDurationSec)
            .putBoolean("vinyl", s.vinylArt)
            .putBoolean("visualizer", s.visualizer)
            .putString("songSort", s.songSort.name)
            .putString("themeId", s.themeId.name)
            .putString("wallpaperPath", s.wallpaperPath)
            .putFloat("wallpaperDim", s.wallpaperDim)
            .putFloat("wallpaperBlur", s.wallpaperBlur)
            .putString("playMode", s.playMode.name)
            .putInt("highlight", s.highlight)
            .putInt("textColor", s.textColor)
            .putString("fontStyle", s.fontStyle.name)
            .putInt("fadeSeconds", s.fadeSeconds)
            .putBoolean("resumePlayback", s.resumePlayback)
            .putBoolean("animatedPlayerBg", s.animatedPlayerBg)
            .putStringSet("hiddenFolders", s.hiddenFolders)
            .putFloat("fontScale", s.fontScale)
            .putBoolean("autoUpdateCheck", s.autoUpdateCheck)
            .putLong("lastUpdateCheck", s.lastUpdateCheck)
            .putString("playerStyle", s.playerStyle.name)
            .putString("uiSize", s.uiSize.name)
            .putBoolean("wallpaperInPlayer", s.wallpaperInPlayer)
            .apply()
        _settings.value = s
    }

    private inline fun <reified E : Enum<E>> enumPref(key: String, default: E): E =
        runCatching { enumValueOf<E>(prefs.getString(key, null) ?: default.name) }.getOrDefault(default)

    private fun load() = AppSettings(
        themeMode = enumPref("theme", ThemeMode.SYSTEM),
        accent = prefs.getInt("accent", 0),
        dynamicColor = prefs.getBoolean("dynamic", true),
        minDurationSec = prefs.getInt("minDuration", 10),
        vinylArt = prefs.getBoolean("vinyl", true),
        visualizer = prefs.getBoolean("visualizer", true),
        songSort = enumPref("songSort", SongSort.TITLE_ASC),
        themeId = enumPref("themeId", AppThemeId.DEFAULT),
        wallpaperPath = prefs.getString("wallpaperPath", null),
        wallpaperDim = prefs.getFloat("wallpaperDim", 0.55f),
        wallpaperBlur = prefs.getFloat("wallpaperBlur", 0f),
        playMode = enumPref("playMode", PlayMode.ORDER),
        highlight = prefs.getInt("highlight", -1),
        textColor = prefs.getInt("textColor", 0),
        fontStyle = enumPref("fontStyle", FontStyleId.DEFAULT),
        fadeSeconds = prefs.getInt("fadeSeconds", 0),
        resumePlayback = prefs.getBoolean("resumePlayback", true),
        animatedPlayerBg = prefs.getBoolean("animatedPlayerBg", true),
        hiddenFolders = prefs.getStringSet("hiddenFolders", emptySet())?.toSet() ?: emptySet(),
        fontScale = prefs.getFloat("fontScale", 1f),
        autoUpdateCheck = prefs.getBoolean("autoUpdateCheck", true),
        lastUpdateCheck = prefs.getLong("lastUpdateCheck", 0),
        playerStyle = enumPref(
            "playerStyle",
            if (prefs.getBoolean("vinyl", true)) PlayerStyle.VINIL_CLASSICO else PlayerStyle.PADRAO,
        ),
        uiSize = enumPref("uiSize", UiSize.NORMAL),
        wallpaperInPlayer = prefs.getBoolean("wallpaperInPlayer", false),
    )
}
