package com.ritmo.player.playback

import android.media.audiofx.Visualizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow

/** Lê as frequências da música tocando para desenhar as barras que dançam. */
object AudioVisualizer {
    const val BARS = 28

    private var visualizer: Visualizer? = null
    private var attachedSession = 0

    private val _levels = MutableStateFlow(FloatArray(BARS))
    val levels: StateFlow<FloatArray> = _levels.asStateFlow()

    fun start(sessionId: Int) {
        if (sessionId == 0) return
        if (visualizer != null && attachedSession == sessionId) return
        stop()
        visualizer = runCatching {
            Visualizer(sessionId).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
                setDataCaptureListener(
                    object : Visualizer.OnDataCaptureListener {
                        override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
                        override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                            if (fft != null) _levels.value = toBars(fft)
                        }
                    },
                    Visualizer.getMaxCaptureRate(),
                    false,
                    true,
                )
                enabled = true
            }
        }.getOrNull()
        attachedSession = if (visualizer != null) sessionId else 0
    }

    fun stop() {
        runCatching { visualizer?.enabled = false }
        runCatching { visualizer?.release() }
        visualizer = null
        attachedSession = 0
        _levels.value = FloatArray(BARS)
    }

    private fun toBars(fft: ByteArray): FloatArray {
        val bins = fft.size / 2
        val out = FloatArray(BARS)
        for (i in 0 until BARS) {
            // Faixas em escala logarítmica: mais barras para graves e médios.
            val lo = max(1, bins.toDouble().pow(i.toDouble() / BARS).toInt())
            val hi = max(lo + 1, bins.toDouble().pow((i + 1).toDouble() / BARS).toInt()).coerceAtMost(bins)
            var peak = 0f
            for (k in lo until hi) {
                val m = hypot(fft[2 * k].toFloat(), fft[2 * k + 1].toFloat())
                if (m > peak) peak = m
            }
            out[i] = (ln(1f + peak) / ln(129f)).coerceIn(0f, 1f)
        }
        return out
    }
}
