# Regras extras do ProGuard/R8 (as bibliotecas já trazem as suas).
