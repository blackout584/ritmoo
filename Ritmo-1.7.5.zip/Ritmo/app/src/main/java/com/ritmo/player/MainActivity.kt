package com.ritmo.player

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.content.Intent
import android.os.Bundle
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.ui.AppRoot
import com.ritmo.player.ui.MainViewModel
import com.ritmo.player.ui.AppBackground
import com.ritmo.player.ui.rememberArtColors
import com.ritmo.player.ui.theme.RitmoTheme
import com.ritmo.player.ui.theme.isAppDark
import com.ritmo.player.ui.wallpaperUri

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    /** Atalhos do ícone com o app já aberto. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        vm.handleShortcut(intent.action)
        handleExternal(intent)
    }

    /** Áudio vindo do player rápido ("Abrir no Ritmo"). */
    private fun handleExternal(intent: Intent?) {
        val path = intent?.getStringExtra(QuickPlayerActivity.EXTRA_PATH) ?: return
        val title = intent.getStringExtra(QuickPlayerActivity.EXTRA_TITLE) ?: "Áudio"
        intent.removeExtra(QuickPlayerActivity.EXTRA_PATH)
        vm.playExternal(path, title)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Só na primeira abertura (girar a tela não repete o atalho)
        if (savedInstanceState == null) {
            vm.handleShortcut(intent?.action)
            handleExternal(intent)
        }
        setContent {
            val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
            val wallpaper = settings.wallpaperUri()
            // Cores tiradas do papel de parede, para os botões combinarem com a foto
            val wallColors = if (wallpaper != null) rememberArtColors(wallpaper, Color(0xFFB7B0FF)) else null

            // Ícones da barra de status claros em temas escuros
            val dark = isAppDark(settings)
            DisposableEffect(dark) {
                val style = if (dark) {
                    SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                } else {
                    SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
                }
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose {}
            }

            // Tamanho da interface e das letras escolhidos em Personalizar
            val baseDensity = LocalDensity.current
            CompositionLocalProvider(
                LocalDensity provides Density(
                    baseDensity.density * settings.uiSize.factor,
                    baseDensity.fontScale * settings.fontScale,
                )
            ) {
            RitmoTheme(settings, wallColors?.let { it.accent to it.background }) {
                AppBackground(settings, wallpaper) {
                    Surface(
                        Modifier.fillMaxSize(),
                        color = Color.Transparent,
                        contentColor = MaterialTheme.colorScheme.onBackground,
                    ) {
                        PermissionGate(onGranted = { vm.loadLibrary() }) {
                            AppRoot(vm)
                        }
                    }
                }
                // Abertura animada
                var showSplash by rememberSaveable { mutableStateOf(true) }
                LaunchedEffect(Unit) {
                    delay(950)
                    showSplash = false
                }
                AnimatedVisibility(visible = showSplash, enter = EnterTransition.None, exit = fadeOut(tween(450))) {
                    SplashContent()
                }
            }
            }
        }
    }
}

@Composable
private fun PermissionGate(onGranted: () -> Unit, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val audioPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        arrayOf(audioPermission, Manifest.permission.POST_NOTIFICATIONS)
    } else {
        arrayOf(audioPermission)
    }
    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result -> granted = result[audioPermission] == true }

    LaunchedEffect(Unit) { if (!granted) launcher.launch(permissions) }
    LaunchedEffect(granted) { if (granted) onGranted() }

    if (granted) {
        content()
    } else {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(
                Icons.Rounded.LibraryMusic, null,
                Modifier.size(72.dp),
                tint = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.height(16.dp))
            Text(
                "Para tocar suas músicas, o Ritmo precisa de permissão para acessar os arquivos de áudio do aparelho.",
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = { launcher.launch(permissions) }) { Text("Permitir acesso") }
        }
    }
}

@Composable
private fun SplashContent() {
    val scale = remember { Animatable(0.55f) }
    val textAlpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { scale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)) }
        delay(250)
        textAlpha.animateTo(1f, tween(400))
    }
    Box(
        Modifier.fillMaxSize().background(Color.Black),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .size(104.dp)
                    .graphicsLayer {
                        scaleX = scale.value
                        scaleY = scale.value
                        rotationZ = (1f - scale.value) * -40f
                    }
                    .clip(RoundedCornerShape(30.dp))
                    .background(Color(0xFF4F7DF3)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.MusicNote, null, Modifier.size(60.dp), tint = Color.White)
            }
            Spacer(Modifier.height(18.dp))
            Text(
                "Ritmo",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.graphicsLayer { alpha = textAlpha.value },
            )
        }
    }
}
