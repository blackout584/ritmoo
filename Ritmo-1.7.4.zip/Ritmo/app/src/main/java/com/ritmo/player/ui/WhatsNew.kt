package com.ritmo.player.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.NewReleases
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.pm.PackageInfoCompat

/** Uma novidade da versão: ícone, título e uma frase curta. */
private data class NewsItem(val icon: ImageVector, val title: String, val text: String)

/** Novidades desta versão (mostradas uma vez depois de atualizar). */
private val currentNews = listOf(
    NewsItem(Icons.Rounded.Palette, "Player com as cores do tema", "Combina com o resto do app (dá para voltar às cores da capa em Personalizar)"),
    NewsItem(Icons.Rounded.Chat, "Abrir áudios do WhatsApp", "Pelo \"Abrir com\" ou Compartilhar, num player rápido"),
    NewsItem(Icons.Rounded.Info, "Detalhes da música", "Pasta, formato e tamanho no menu ⋮ do player"),
    NewsItem(Icons.Rounded.SwapHoriz, "Organize as abas", "Segure uma aba e arraste; esconda abas em Personalizar"),
    NewsItem(Icons.AutoMirrored.Rounded.QueueMusic, "Fila mais fácil", "Arraste até a borda e a lista rola sozinha; deslize para tocar a seguir"),
    NewsItem(Icons.Rounded.Search, "Menu na busca", "Segure uma música para compartilhar, mover, apagar e mais"),
    NewsItem(Icons.Rounded.Person, "Desenvolvido por Blanck", "Agora no Sobre o Ritmo"),
)

private const val SHOW_FIRST = 4

fun appVersionName(context: Context): String =
    runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: ""

fun appVersionCode(context: Context): Int =
    runCatching {
        PackageInfoCompat.getLongVersionCode(context.packageManager.getPackageInfo(context.packageName, 0)).toInt()
    }.getOrDefault(0)

/** Verdadeiro se o app acabou de ser instalado (e não atualizado). */
fun isFreshInstall(context: Context): Boolean =
    runCatching {
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        info.firstInstallTime == info.lastUpdateTime
    }.getOrDefault(false)

@Composable
fun WhatsNewDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    var expanded by remember { mutableStateOf(false) }
    val items = if (expanded) currentNews else currentNews.take(SHOW_FIRST)
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Box(
                Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.AutoAwesome, null, tint = MaterialTheme.colorScheme.onPrimary)
            }
        },
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text("Novidades da ${appVersionName(context)}", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Text(
                    "O Ritmo foi atualizado",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        text = {
            Column(
                Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items.forEach { n ->
                    Row(verticalAlignment = Alignment.Top) {
                        Box(
                            Modifier.size(34.dp).clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(n.icon, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                        }
                        Column(Modifier.padding(start = 12.dp)) {
                            Text(n.title, fontWeight = FontWeight.SemiBold)
                            Text(n.text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                if (!expanded && currentNews.size > SHOW_FIRST) {
                    Text(
                        "+ ${currentNews.size - SHOW_FIRST} novidades",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { expanded = true }.padding(6.dp),
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Entendi") }
        },
    )
}

/** Janela "Sobre o Ritmo". */
@Composable
fun AboutDialog(onDismiss: () -> Unit, onShowNews: () -> Unit) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Rounded.NewReleases, null) },
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text("Ritmo", fontWeight = FontWeight.Bold)
                Text("Versão ${appVersionName(context)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        text = {
            Column {
                Text("Player de música gratuito, sem anúncios.")
                Spacer(Modifier.height(12.dp))
                Text(
                    "Desenvolvido por Blanck",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    "Fontes com licença livre (SIL OFL): Outfit, Lora, Nothing You Could Do, Tektur, Pixelify Sans e Poiret One.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } },
        dismissButton = { TextButton(onClick = { onDismiss(); onShowNews() }) { Text("Ver novidades") } },
    )
}
