package com.ritmo.player.data

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

data class UpdateInfo(val name: String, val apkUrl: String, val publishedAt: Long)

/** Procura versão nova no GitHub, baixa e abre a instalação. */
object Updater {
    private const val REPO = "blackout584/ritmoo"
    private const val FILE_NAME = "Ritmo-update.apk"

    suspend fun fetchLatest(): UpdateInfo? = withContext(Dispatchers.IO) {
        runCatching {
            val conn = URL("https://api.github.com/repos/$REPO/releases/latest").openConnection() as HttpURLConnection
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            if (conn.responseCode != 200) return@runCatching null
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val assets = json.getJSONArray("assets")
            var url: String? = null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.getString("name").endsWith(".apk")) url = a.getString("browser_download_url")
            }
            val format = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            val published = format.parse(json.getString("published_at"))?.time ?: 0L
            url?.let { UpdateInfo(json.optString("name", json.getString("tag_name")), it, published) }
        }.getOrNull()
    }

    /** A versão do GitHub saiu depois que você instalou a atual? */
    fun isNewer(context: Context, info: UpdateInfo): Boolean {
        // Se o nome da versão no GitHub for igual à instalada, não é novidade
        val installedName = runCatching {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName
        }.getOrNull()
        val releaseName = info.name.removePrefix("Ritmo").trim()
        if (!installedName.isNullOrBlank() && releaseName == installedName) return false
        val installed = runCatching {
            context.packageManager.getPackageInfo(context.packageName, 0).lastUpdateTime
        }.getOrDefault(Long.MAX_VALUE)
        return info.publishedAt > installed + 60_000
    }

    private fun file(context: Context) =
        File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), FILE_NAME)

    fun startDownload(context: Context, info: UpdateInfo): Long {
        file(context).delete()
        val request = DownloadManager.Request(Uri.parse(info.apkUrl))
            .setTitle("Ritmo")
            .setDescription("Baixando atualização")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, FILE_NAME)
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        return dm.enqueue(request)
    }

    /** Retorna (terminou?, deu erro?, progresso 0..1). */
    fun progress(context: Context, id: Long): Triple<Boolean, Boolean, Float> {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        dm.query(DownloadManager.Query().setFilterById(id))?.use { c ->
            if (!c.moveToFirst()) return Triple(true, true, 0f)
            val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            val fraction = if (total > 0) done.toFloat() / total else 0f
            return when (status) {
                DownloadManager.STATUS_SUCCESSFUL -> Triple(true, false, 1f)
                DownloadManager.STATUS_FAILED -> Triple(true, true, fraction)
                else -> Triple(false, false, fraction)
            }
        }
        return Triple(true, true, 0f)
    }

    /** Abre a tela de instalação. Retorna false se precisar liberar "instalar apps" primeiro. */
    fun install(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !context.packageManager.canRequestPackageInstalls()) {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return false
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file(context))
        context.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return true
    }
}
