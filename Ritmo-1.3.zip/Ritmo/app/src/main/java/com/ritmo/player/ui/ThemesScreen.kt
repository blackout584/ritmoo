package com.ritmo.player.ui

import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.ritmo.player.data.AppSettings
import com.ritmo.player.data.AppThemeId
import com.ritmo.player.data.WallpaperStore
import com.ritmo.player.ui.theme.presetFor
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.roundToInt

/** Desenha o fundo do app: papel de parede, degradê do tema ou a cor normal. */
@Composable
fun AppBackground(settings: AppSettings, wallpaper: Uri?, content: @Composable () -> Unit) {
    val preset = presetFor(settings.themeId)
    Box(Modifier.fillMaxSize()) {
        when {
            wallpaper != null -> {
                AsyncImage(
                    model = wallpaper,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().blur((settings.wallpaperBlur * 25).dp),
                )
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = settings.wallpaperDim)))
            }
            preset != null -> Box(
                Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(preset.top, preset.bottom)))
            )
            else -> Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background))
        }
        content()
    }
}

fun AppSettings.wallpaperUri(): Uri? =
    wallpaperPath?.let { File(it) }?.takeIf { it.exists() }?.let { Uri.fromFile(it) }

@Composable
fun ThemesScreen(vm: MainViewModel, onBack: () -> Unit) {
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var saving by remember { mutableStateOf(false) }
    var dim by remember(settings.wallpaperDim) { mutableFloatStateOf(settings.wallpaperDim) }
    var blur by remember(settings.wallpaperBlur) { mutableFloatStateOf(settings.wallpaperBlur) }
    val wallpaper = settings.wallpaperUri()

    BackHandler(onBack = onBack)

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            saving = true
            scope.launch {
                val path = WallpaperStore.save(context, uri)
                if (path != null) vm.settingsStore.update { it.copy(wallpaperPath = path) }
                saving = false
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        SimpleTopBar("Temas", onBack = onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {

            // Grade de temas, 2 por linha
            AppThemeId.entries.chunked(2).forEach { row ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    row.forEach { id ->
                        ThemeCard(
                            id = id,
                            selected = wallpaper == null && settings.themeId == id,
                            modifier = Modifier.weight(1f),
                            onClick = {
                                // Escolher um tema tira o papel de parede
                                WallpaperStore.clear(context)
                                vm.settingsStore.update { it.copy(themeId = id, wallpaperPath = null) }
                            },
                        )
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "Papel de parede",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.height(8.dp))

            if (wallpaper != null) {
                Box(
                    Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(16.dp))
                        .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp))
                ) {
                    AsyncImage(
                        model = wallpaper,
                        contentDescription = "Papel de parede atual",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().blur((blur * 25).dp),
                    )
                    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim)))
                    Text(
                        "Prévia",
                        color = Color.White,
                        modifier = Modifier.align(Alignment.Center),
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        modifier = Modifier.weight(1f),
                    ) { Text("Trocar imagem") }
                    TextButton(onClick = {
                        WallpaperStore.clear(context)
                        vm.settingsStore.update { it.copy(wallpaperPath = null) }
                    }) {
                        Icon(Icons.Rounded.Delete, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Remover")
                    }
                }

                Spacer(Modifier.height(12.dp))
                Text("Escurecer: ${(dim * 100).roundToInt()}%")
                Slider(
                    value = dim,
                    onValueChange = { dim = it },
                    onValueChangeFinished = { vm.settingsStore.update { it.copy(wallpaperDim = dim) } },
                    valueRange = 0.15f..0.85f,
                )
                Text("Desfoque: ${(blur * 100).roundToInt()}%")
                Slider(
                    value = blur,
                    onValueChange = { blur = it },
                    onValueChangeFinished = { vm.settingsStore.update { it.copy(wallpaperBlur = blur) } },
                )
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                    Text(
                        "O desfoque só funciona no Android 12 ou mais novo.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                        .clickable(enabled = !saving) {
                            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (saving) {
                        CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
                    } else {
                        Icon(Icons.Rounded.AddPhotoAlternate, null, Modifier.size(28.dp), tint = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Usar imagem do celular", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Escolha uma foto da galeria para o fundo do app",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ThemeCard(id: AppThemeId, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val preset = presetFor(id)
    val top = preset?.top ?: MaterialTheme.colorScheme.surfaceContainerHigh
    val bottom = preset?.bottom ?: MaterialTheme.colorScheme.surfaceContainerLow
    val primary = preset?.primary ?: MaterialTheme.colorScheme.primary
    val secondary = preset?.secondary ?: MaterialTheme.colorScheme.onSurfaceVariant
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .clip(shape)
            .border(
                if (selected) 2.dp else 1.dp,
                if (selected) primary else MaterialTheme.colorScheme.outlineVariant,
                shape,
            )
            .clickable(onClick = onClick)
    ) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1.4f)
                .background(Brush.verticalGradient(listOf(top, bottom)))
                .padding(10.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.width(44.dp).height(7.dp).clip(CircleShape).background(primary))
                Box(Modifier.width(80.dp).height(5.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.35f)))
                Box(Modifier.width(60.dp).height(5.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f)))
                Box(Modifier.width(30.dp).height(5.dp).clip(CircleShape).background(secondary))
            }
            if (selected) {
                Icon(
                    Icons.Rounded.Check, "Selecionado",
                    tint = if (preset == null) MaterialTheme.colorScheme.onPrimary else Color.Black,
                    modifier = Modifier.align(Alignment.TopEnd).size(22.dp).clip(CircleShape).background(primary).padding(3.dp),
                )
            }
        }
        Text(id.label, modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp))
    }
}
