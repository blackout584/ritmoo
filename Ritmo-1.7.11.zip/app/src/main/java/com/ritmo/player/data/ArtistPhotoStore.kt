package com.ritmo.player.data

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.io.File

/** Fotos escolhidas para os artistas (ficam só no Ritmo; as capas das músicas não mudam). */
class ArtistPhotoStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("artist_photos", Context.MODE_PRIVATE)
    private val dir = File(context.filesDir, "artist_photos").apply { mkdirs() }
    private val _photos = MutableStateFlow(load())
    /** Nome do artista → caminho da foto. */
    val photos: StateFlow<Map<String, String>> = _photos.asStateFlow()

    fun uriFor(artist: String): Uri? =
        _photos.value[artist]?.let { File(it) }?.takeIf { it.exists() }?.let { Uri.fromFile(it) }

    /** Salva a foto (um nome novo a cada vez, para a tela atualizar na hora). */
    fun save(artist: String, bitmap: Bitmap) {
        remove(artist)
        val file = File(dir, "a_${artist.hashCode()}_${System.currentTimeMillis()}.jpg")
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        _photos.value = _photos.value + (artist to file.absolutePath)
        persist()
    }

    fun remove(artist: String) {
        _photos.value[artist]?.let { File(it).delete() }
        _photos.value = _photos.value - artist
        persist()
    }

    private fun persist() {
        val o = JSONObject()
        _photos.value.forEach { (k, v) -> o.put(k, v) }
        prefs.edit().putString("data", o.toString()).apply()
    }

    private fun load(): Map<String, String> = runCatching {
        val o = JSONObject(prefs.getString("data", "{}") ?: "{}")
        o.keys().asSequence().associateWith { o.getString(it) }
    }.getOrDefault(emptyMap())
}
