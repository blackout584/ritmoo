package com.ritmo.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.HourglassBottom
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.data.PlayStat
import com.ritmo.player.data.Song

// ---------------- Playlists automáticas ----------------

enum class SmartKind(val label: String, val subtitle: String, val icon: ImageVector, val color: Color) {
    TOP("Mais tocadas", "Suas 50 mais ouvidas", Icons.Rounded.LocalFireDepartment, Color(0xFF7F77DD)),
    NEVER("Nunca ouvidas", "Músicas que ainda não tocaram", Icons.Rounded.AutoAwesome, Color(0xFF1D9E75)),
    ADDED_MONTH("Adicionadas este mês", "Entraram nos últimos 30 dias", Icons.Rounded.CalendarMonth, Color(0xFFD85A30)),
    FORGOTTEN("Esquecidas", "Sem tocar há mais de 3 meses", Icons.Rounded.HourglassBottom, Color(0xFF888780)),
}

/** As playlists automáticas se montam sozinhas a partir do que você ouve. */
fun smartSongs(kind: SmartKind, songs: List<Song>, stats: Map<Long, PlayStat>): List<Song> {
    val now = System.currentTimeMillis()
    return when (kind) {
        SmartKind.TOP -> songs.filter { stats.containsKey(it.id) }
            .sortedByDescending { stats[it.id]?.count ?: 0 }
            .take(50)
        SmartKind.NEVER -> songs.filter { !stats.containsKey(it.id) }
        SmartKind.ADDED_MONTH -> songs.filter { it.dateAdded * 1000 >= now - 30L * 24 * 3600 * 1000 }
            .sortedByDescending { it.dateAdded }
        SmartKind.FORGOTTEN -> songs.filter {
            val last = stats[it.id]?.lastPlayed ?: return@filter false
            last < now - 90L * 24 * 3600 * 1000
        }
    }
}

@Composable
fun SmartPlaylistGrid(vm: MainViewModel, onOpen: (Detail) -> Unit) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    val stats by vm.statsStore.stats.collectAsStateWithLifecycle()
    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Automáticas", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
        SmartKind.entries.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { kind ->
                    val count = remember(songs, stats) { smartSongs(kind, songs, stats).size }
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(kind.color.copy(alpha = 0.22f))
                            .clickable { onOpen(Detail.Smart(kind)) }
                            .padding(12.dp)
                    ) {
                        Icon(kind.icon, null, tint = kind.color)
                        Spacer(Modifier.height(6.dp))
                        Text(kind.label, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "$count músicas",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
        Text("Suas playlists", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
    }
}

// ---------------- Busca geral ----------------

private fun matches(text: String, query: String): Boolean =
    java.text.Normalizer.normalize(text, java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .contains(
            java.text.Normalizer.normalize(query, java.text.Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), ""),
            ignoreCase = true,
        )

/** Resultados da busca: artistas, álbuns, músicas e playlists ao mesmo tempo (ignora acentos). */
@Composable
fun SearchResults(vm: MainViewModel, query: String, onOpen: (Detail) -> Unit) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    val playlists by vm.playlistStore.playlists.collectAsStateWithLifecycle()
    val q = query.trim()
    val artists = remember(songs, q) {
        songs.groupBy { it.artist }.filterKeys { matches(it, q) }.map { it.key to it.value.size }.take(5)
    }
    val albums = remember(songs, q) {
        songs.groupBy { it.albumId }.values.map { it.first() }.filter { matches(it.album, q) }.take(5)
    }
    val found = remember(songs, q) { songs.filter { matches(it.title, q) }.take(30) }
    val lists = remember(playlists, q) { playlists.filter { matches(it.name, q) } }

    if (artists.isEmpty() && albums.isEmpty() && found.isEmpty() && lists.isEmpty()) {
        EmptyMessage("Nada encontrado para \"$q\"")
        return
    }
    LazyColumn(Modifier.fillMaxSize()) {
        if (artists.isNotEmpty()) {
            item { ResultHeader("Artistas") }
            items(artists, key = { "ar_${it.first}" }) { (name, count) ->
                GroupRow(Icons.Rounded.Person, name, "$count músicas", onClick = { onOpen(Detail.Artist(name)) })
            }
        }
        if (albums.isNotEmpty()) {
            item { ResultHeader("Álbuns") }
            items(albums, key = { "al_${it.albumId}" }) { s ->
                ListItem(
                    leadingContent = { ArtImage(s.artUri, Modifier.size(48.dp)) },
                    headlineContent = { Text(s.album, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = { Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    modifier = Modifier.clickable { onOpen(Detail.Album(s.albumId, s.album)) },
                )
            }
        }
        if (lists.isNotEmpty()) {
            item { ResultHeader("Playlists") }
            items(lists, key = { "pl_${it.id}" }) { p ->
                GroupRow(Icons.AutoMirrored.Rounded.QueueMusic, p.name, "${p.songIds.size} músicas", onClick = {
                    onOpen(Detail.PlaylistDetail(p.id))
                })
            }
        }
        if (found.isNotEmpty()) {
            item { ResultHeader("Músicas") }
            items(found.size) { i ->
                val s = found[i]
                ListItem(
                    leadingContent = { ArtImage(s.artUri, Modifier.size(48.dp)) },
                    headlineContent = { Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = { Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    modifier = Modifier.clickable { vm.playSongs(found, i) },
                )
            }
        }
    }
}

@Composable
private fun ResultHeader(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp),
    )
}

// ---------------- Estrelas ----------------

fun starsText(stars: Int): String = "★".repeat(stars)

@Composable
fun RatingDialog(current: Int, onSelect: (Int) -> Unit, onDismiss: () -> Unit) {
    var value by remember { mutableStateOf(current) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dar nota") },
        text = {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                (1..5).forEach { n ->
                    IconButton(onClick = { value = n }) {
                        Icon(
                            if (n <= value) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                            "$n estrelas",
                            tint = if (n <= value) Color(0xFFFFB300) else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(36.dp),
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSelect(value) }) { Text("Salvar") } },
        dismissButton = {
            Row {
                if (current > 0) TextButton(onClick = { onSelect(0) }) { Text("Tirar nota") }
                TextButton(onClick = onDismiss) { Text("Cancelar") }
            }
        },
    )
}

// ---------------- Escolher pastas ----------------

@Composable
fun FoldersScreen(vm: MainViewModel, onBack: () -> Unit) {
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    androidx.activity.compose.BackHandler(onBack = onBack)
    val folders = remember(settings.hiddenFolders) { vm.allFolders() }
    Column(Modifier.fillMaxSize()) {
        SimpleTopBar("Escolher pastas", onBack = onBack)
        Text(
            "Desmarque as pastas que não quer ver na Biblioteca (ex.: áudios do WhatsApp).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        LazyColumn(Modifier.fillMaxSize()) {
            items(folders, key = { it.first }) { (path, name, count) ->
                val visible = path !in settings.hiddenFolders
                ListItem(
                    leadingContent = {
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center,
                        ) { Icon(Icons.Rounded.Folder, null) }
                    },
                    headlineContent = { Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = { Text("$count músicas • $path", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    trailingContent = {
                        Checkbox(checked = visible, onCheckedChange = { vm.setFolderHidden(path, !it) })
                    },
                    modifier = Modifier.clickable { vm.setFolderHidden(path, visible) },
                )
            }
        }
    }
}
