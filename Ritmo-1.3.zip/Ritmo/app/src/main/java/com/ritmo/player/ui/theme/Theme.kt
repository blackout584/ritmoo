package com.ritmo.player.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import com.ritmo.player.data.AppSettings
import com.ritmo.player.data.AppThemeId
import com.ritmo.player.data.ThemeMode

val accentColors = listOf(
    Color(0xFF4F7DF3), // azul
    Color(0xFFE8505B), // vermelho
    Color(0xFF2BB673), // verde
    Color(0xFFF2A93B), // laranja
    Color(0xFF9B5DE5), // roxo
    Color(0xFF14B8C4), // ciano
)
val accentNames = listOf("Azul", "Vermelho", "Verde", "Laranja", "Roxo", "Ciano")

/** Cores de cada tema pronto: degradê do fundo, cor principal, secundária e cor das caixas. */
data class ThemePreset(
    val top: Color,
    val bottom: Color,
    val primary: Color,
    val secondary: Color,
    val container: Color,
)

fun presetFor(id: AppThemeId): ThemePreset? = when (id) {
    AppThemeId.DEFAULT -> null
    AppThemeId.MIDNIGHT -> ThemePreset(
        top = Color(0xFF2A2468), bottom = Color(0xFF0B0A1F),
        primary = Color(0xFFB7B0FF), secondary = Color(0xFF7F9CFF), container = Color(0xFF1B1840),
    )
    AppThemeId.NEON -> ThemePreset(
        top = Color(0xFF1A0820), bottom = Color(0xFF020203),
        primary = Color(0xFFFF4FA3), secondary = Color(0xFF2EE6D6), container = Color(0xFF151018),
    )
    AppThemeId.SUNSET -> ThemePreset(
        top = Color(0xFF7A2A14), bottom = Color(0xFF1C0A07),
        primary = Color(0xFFFFB04A), secondary = Color(0xFFFF6B5A), container = Color(0xFF2E140D),
    )
    AppThemeId.OCEAN -> ThemePreset(
        top = Color(0xFF0E4A73), bottom = Color(0xFF04121F),
        primary = Color(0xFF4FD8CB), secondary = Color(0xFF6CB8FF), container = Color(0xFF0B2438),
    )
    AppThemeId.FOREST -> ThemePreset(
        top = Color(0xFF2B5216), bottom = Color(0xFF07120A),
        primary = Color(0xFFA6DB6E), secondary = Color(0xFFE3D27A), container = Color(0xFF13250D),
    )
}

/** Fundo transparente: o degradê do tema ou o papel de parede aparece por trás de tudo. */
fun themedScheme(primary: Color, secondary: Color, container: Color): ColorScheme = darkColorScheme(
    primary = primary,
    onPrimary = if (primary.luminance() > 0.5f) Color.Black else Color.White,
    primaryContainer = primary.copy(alpha = 0.28f),
    onPrimaryContainer = Color.White,
    secondary = secondary,
    onSecondary = Color.Black,
    secondaryContainer = primary.copy(alpha = 0.22f),
    onSecondaryContainer = primary,
    tertiary = secondary,
    background = Color.Transparent,
    onBackground = Color.White,
    surface = Color.Transparent,
    onSurface = Color.White,
    surfaceVariant = Color.White.copy(alpha = 0.10f),
    onSurfaceVariant = Color.White.copy(alpha = 0.72f),
    surfaceTint = primary,
    surfaceContainerLowest = container,
    surfaceContainerLow = container,
    surfaceContainer = container.copy(alpha = 0.94f),
    surfaceContainerHigh = lerp(container, Color.White, 0.06f),
    surfaceContainerHighest = lerp(container, Color.White, 0.10f),
    outline = Color.White.copy(alpha = 0.35f),
    outlineVariant = Color.White.copy(alpha = 0.15f),
)

/** O app está usando um tema pronto ou papel de parede (sempre escuro). */
fun AppSettings.isThemed(): Boolean = wallpaperPath != null || themeId != AppThemeId.DEFAULT

@Composable
fun isAppDark(settings: AppSettings): Boolean =
    settings.isThemed() || when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

/**
 * @param wallpaperAccent cor de destaque e cor escura tiradas do papel de parede (quando houver).
 */
@Composable
fun RitmoTheme(
    settings: AppSettings,
    wallpaperAccent: Pair<Color, Color>? = null,
    content: @Composable () -> Unit,
) {
    val dark = isAppDark(settings)
    val context = LocalContext.current
    val preset = presetFor(settings.themeId)
    val scheme = when {
        settings.wallpaperPath != null -> {
            val (accent, base) = wallpaperAccent ?: (Color(0xFFB7B0FF) to Color(0xFF15151A))
            themedScheme(accent, accent, lerp(base, Color.Black, 0.45f))
        }
        preset != null -> themedScheme(preset.primary, preset.secondary, preset.container)
        settings.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        else -> {
            val accent = accentColors[settings.accent.coerceIn(accentColors.indices)]
            if (dark) {
                darkColorScheme(
                    primary = accent,
                    secondary = accent,
                    tertiary = accent,
                    background = Color(0xFF0F1013),
                    surface = Color(0xFF0F1013),
                    onPrimary = Color.White,
                )
            } else {
                lightColorScheme(primary = accent, secondary = accent, tertiary = accent, onPrimary = Color.White)
            }
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
