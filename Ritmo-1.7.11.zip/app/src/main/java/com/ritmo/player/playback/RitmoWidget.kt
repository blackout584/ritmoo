package com.ritmo.player.playback

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.net.Uri
import android.view.KeyEvent
import android.widget.RemoteViews
import androidx.annotation.OptIn
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaButtonReceiver
import com.ritmo.player.MainActivity
import com.ritmo.player.R
import java.util.concurrent.Executors

/** Widget da tela inicial: capa, nome e botões de tocar/pausar, anterior e próxima. */
class RitmoWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        WidgetUpdater.push(context)
    }
}

object WidgetUpdater {
    @Volatile private var title: String? = null
    @Volatile private var artist: String? = null
    @Volatile private var playing = false
    @Volatile private var art: Bitmap? = null
    private var artKey: String? = null
    private val executor = Executors.newSingleThreadExecutor()

    /** Usado pelo botão do painel rápido. */
    val isPlaying: Boolean get() = playing
    val currentTitle: String? get() = title

    /** Mesmo que apertar play/pause num fone (funciona até com o app fechado). */
    fun sendPlayPause(context: Context) {
        runCatching { mediaButton(context, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, 11).send() }
    }

    /** Chamado pelo serviço de música sempre que algo muda. */
    fun update(context: Context, player: Player) {
        val app = context.applicationContext
        val md = player.mediaMetadata
        title = md.title?.toString()
        artist = md.artist?.toString()
        playing = player.isPlaying
        val uri = md.artworkUri
        val key = uri?.toString()
        // Atualiza também o botão do painel rápido
        runCatching {
            android.service.quicksettings.TileService.requestListeningState(
                app, ComponentName(app, RitmoTileService::class.java)
            )
        }
        if (key != artKey) {
            artKey = key
            art = null
            push(app)
            if (uri != null) executor.execute {
                val bmp = loadArt(app, uri)
                if (artKey == key) {
                    art = bmp
                    push(app)
                }
            }
        } else {
            push(app)
        }
    }

    fun push(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, RitmoWidget::class.java))
        if (ids.isEmpty()) return
        val views = RemoteViews(context.packageName, R.layout.widget_player)
        views.setTextViewText(R.id.widget_title, title ?: context.getString(R.string.app_name))
        views.setTextViewText(R.id.widget_artist, artist ?: context.getString(R.string.widget_hint))
        views.setImageViewResource(R.id.widget_play, if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        val bmp = art
        if (bmp != null) views.setImageViewBitmap(R.id.widget_art, bmp)
        else views.setImageViewResource(R.id.widget_art, R.drawable.widget_art_placeholder)

        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        views.setOnClickPendingIntent(R.id.widget_root, open)
        views.setOnClickPendingIntent(R.id.widget_play, mediaButton(context, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, 11))
        views.setOnClickPendingIntent(R.id.widget_next, mediaButton(context, KeyEvent.KEYCODE_MEDIA_NEXT, 12))
        views.setOnClickPendingIntent(R.id.widget_prev, mediaButton(context, KeyEvent.KEYCODE_MEDIA_PREVIOUS, 13))
        runCatching { manager.updateAppWidget(ids, views) }
    }

    /** Os botões funcionam como os botões de mídia de um fone: o Android entrega ao Ritmo. */
    @OptIn(UnstableApi::class)
    private fun mediaButton(context: Context, keyCode: Int, requestCode: Int): PendingIntent {
        val intent = Intent(Intent.ACTION_MEDIA_BUTTON)
            .setClass(context, MediaButtonReceiver::class.java)
            .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        return PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
    }

    private fun loadArt(context: Context, uri: Uri): Bitmap? = runCatching {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 200 && bounds.outHeight / (sample * 2) >= 200) sample *= 2
        val src = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return@runCatching null
        rounded(Bitmap.createScaledBitmap(src, 200, 200, true))
    }.getOrNull()

    /** Cantos arredondados na capa (o widget não sabe arredondar sozinho). */
    private fun rounded(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val rect = RectF(0f, 0f, src.width.toFloat(), src.height.toFloat())
        canvas.drawRoundRect(rect, 28f, 28f, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(src, 0f, 0f, paint)
        return out
    }
}
