package com.ritmo.player.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.ritmo.player.data.PlayerStyle
import android.net.Uri
import kotlin.math.roundToInt

/**
 * Transição mini player <-> player completo (estilo YouTube Music).
 * progress 0 = mini player, 1 = player aberto. Pode ser arrastado com o dedo.
 */
@Stable
class PlayerTransitionState {
    val progress = Animatable(0f)
    var miniBox by mutableStateOf(Rect.Zero)
    var miniArt by mutableStateOf(Rect.Zero)
    var fullArt by mutableStateOf(Rect.Zero)
    var miniColor by mutableStateOf(Color(0xFF5A2A1E))
    var origin by mutableStateOf(Offset.Zero)
    var screenHeight by mutableStateOf(1f)
    var dragging by mutableStateOf(false)

    val p: Float get() = progress.value
    val moving: Boolean get() = progress.value > 0.002f && progress.value < 0.998f
    val isMoving = androidx.compose.runtime.derivedStateOf { moving }
    val isVisible = androidx.compose.runtime.derivedStateOf { progress.value > 0.001f }

    suspend fun animateTo(target: Float) {
        progress.animateTo(target, tween(420, easing = TransitionEasing))
    }
}

val TransitionEasing = CubicBezierEasing(0.2f, 0.8f, 0.2f, 1f)

val LocalPlayerTransition = staticCompositionLocalOf<PlayerTransitionState?> { null }

fun LayoutCoordinates.rectInRoot(): Rect {
    val pos = positionInRoot()
    return Rect(pos, Size(size.width.toFloat(), size.height.toFloat()))
}

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t

fun lerpRect(a: Rect, b: Rect, t: Float) = Rect(
    lerpF(a.left, b.left, t), lerpF(a.top, b.top, t),
    lerpF(a.right, b.right, t), lerpF(a.bottom, b.bottom, t),
)

/** Recorte do painel: começa no formato do mini player e cresce até a tela toda. */
class PanelShape(private val p: Float, private val mini: Rect, private val cornerPx: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val full = Rect(0f, 0f, size.width, size.height)
        val from = if (mini.isEmpty) Rect(0f, size.height - cornerPx * 2.3f, size.width, size.height) else mini
        val r = lerpRect(from, full, p)
        return Outline.Rounded(RoundRect(r, CornerRadius(cornerPx * (1f - p).coerceIn(0f, 1f))))
    }
}

/** Capa voando do mini player até o lugar dela no player (e de volta). */
@Composable
fun FlyingArt(
    tr: PlayerTransitionState,
    style: PlayerStyle,
    uri: Uri?,
    isPlaying: Boolean,
    accent: Color,
) {
    if (!tr.moving || tr.miniArt.isEmpty) return
    val density = LocalDensity.current
    val mini = tr.miniArt.translate(-tr.origin)
    val full = if (tr.fullArt.isEmpty) null else tr.fullArt.translate(-tr.origin)
    Box(Modifier.fillMaxSize()) {
        if (full == null) {
            // Letra aberta: sem capa no player, a capinha só some
            return@Box
        }
        val p = tr.p
        val r = lerpRect(mini, full, p)
        val fullAlpha = ((p - 0.08f) / 0.35f).coerceIn(0f, 1f)
        // Capa grande (desenhada no tamanho final e encolhida)
        Box(
            Modifier
                .offset { IntOffset(r.left.roundToInt(), r.top.roundToInt()) }
                .graphicsLayer {
                    transformOrigin = TransformOrigin(0f, 0f)
                    scaleX = r.width / full.width
                    scaleY = r.height / full.height
                    alpha = fullAlpha
                }
                .requiredSize(with(density) { full.width.toDp() }, with(density) { full.height.toDp() }),
            contentAlignment = Alignment.Center,
        ) {
            PlayerStyleArt(style = style, uri = uri, isPlaying = isPlaying, accent = accent, modifier = Modifier.fillMaxSize())
        }
        // Ícone do mini player (crescendo enquanto some)
        Box(
            Modifier
                .offset { IntOffset(r.left.roundToInt(), r.top.roundToInt()) }
                .graphicsLayer {
                    transformOrigin = TransformOrigin(0f, 0f)
                    scaleX = r.width / mini.width
                    scaleY = r.height / mini.height
                    alpha = 1f - fullAlpha
                }
                .requiredSize(with(density) { mini.width.toDp() }, with(density) { mini.height.toDp() }),
            contentAlignment = Alignment.Center,
        ) {
            MiniStyleIcon(style, uri, isPlaying)
        }
    }
}

/** Camada da cor do mini player que vai sumindo no começo da abertura. */
@Composable
fun MiniColorVeil(tr: PlayerTransitionState) {
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = (1f - tr.p * 2.5f).coerceIn(0f, 1f) }
            .background(tr.miniColor)
    )
}
