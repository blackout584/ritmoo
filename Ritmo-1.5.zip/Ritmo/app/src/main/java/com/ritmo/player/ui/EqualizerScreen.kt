package com.ritmo.player.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.playback.AudioEffects
import kotlin.math.roundToInt

@Composable
fun EqualizerScreen() {
    val st by AudioEffects.state.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize()) {
        SimpleTopBar("Equalizador", actions = {
            Switch(
                checked = st.enabled,
                onCheckedChange = { AudioEffects.setEnabled(it) },
                enabled = st.available,
            )
            Spacer(Modifier.width(12.dp))
        })

        if (!st.available) {
            EmptyMessage("Toque uma música para ativar o equalizador.")
            return@Column
        }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 16.dp),
        ) {
            if (!st.enabled) {
                Text(
                    "Ligue a chave acima para aplicar os ajustes.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
            }

            // Predefinições
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                item {
                    FilterChip(
                        selected = st.currentPreset == -1 && st.bandLevels.all { it == 0 },
                        onClick = { AudioEffects.resetFlat() },
                        label = { Text("Plano") },
                    )
                }
                itemsIndexed(st.presets) { i, name ->
                    FilterChip(
                        selected = st.currentPreset == i,
                        onClick = { AudioEffects.usePreset(i) },
                        label = { Text(name) },
                    )
                }
            }

            // Bandas
            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Row(
                    Modifier.fillMaxWidth().height(280.dp).padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    st.bandLevels.forEachIndexed { i, level ->
                        Column(
                            Modifier.weight(1f).fillMaxHeight(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            val db = level / 100f
                            Text(
                                (if (db > 0) "+" else "") + "%.0f".format(db),
                                style = MaterialTheme.typography.labelSmall,
                            )
                            Slider(
                                value = level.toFloat(),
                                onValueChange = { AudioEffects.setBandLevel(i, it.roundToInt()) },
                                valueRange = st.minLevel.toFloat()..st.maxLevel.toFloat(),
                                enabled = st.enabled,
                                modifier = Modifier.weight(1f).verticalSlider(),
                            )
                            Text(
                                formatFreq(st.bandFreqsHz.getOrElse(i) { 0 }),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                    }
                }
            }

            if (st.bassSupported) {
                EffectSlider("Reforço de graves", st.bassStrength, st.enabled) { AudioEffects.setBass(it) }
            }
            if (st.virtualizerSupported) {
                EffectSlider("Som 3D (virtualizador)", st.virtualizerStrength, st.enabled) { AudioEffects.setVirtualizer(it) }
            }

            if (st.normalizeSupported) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Volume igual entre músicas")
                        Text(
                            "Segura as músicas muito altas e levanta as baixas",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = st.normalize, onCheckedChange = { AudioEffects.setNormalize(it) })
                }
            }

            Text(
                "Os ajustes são salvos automaticamente. O efeito pode variar de acordo com o aparelho e o fone.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(16.dp),
            )
        }
    }
}

@Composable
private fun EffectSlider(label: String, value: Int, enabled: Boolean, onChange: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
        Row {
            Text(label, modifier = Modifier.weight(1f))
            Text("${value / 10}%", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.roundToInt()) },
            valueRange = 0f..1000f,
            enabled = enabled,
        )
    }
}

private fun formatFreq(hz: Int): String =
    if (hz >= 1000) {
        val k = hz / 1000f
        (if (k % 1f == 0f) k.toInt().toString() else "%.1f".format(k)) + "k"
    } else hz.toString()

/** Gira o slider para ficar na vertical, como um equalizador de verdade. */
private fun Modifier.verticalSlider(): Modifier = this
    .graphicsLayer { rotationZ = 270f }
    .layout { measurable, constraints ->
        val placeable = measurable.measure(
            Constraints(
                minWidth = constraints.minHeight,
                maxWidth = constraints.maxHeight,
                minHeight = constraints.minWidth,
                maxHeight = constraints.maxWidth,
            )
        )
        layout(placeable.height, placeable.width) {
            placeable.place(
                (placeable.height - placeable.width) / 2,
                (placeable.width - placeable.height) / 2,
            )
        }
    }
