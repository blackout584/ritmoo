package com.ritmo.player.data

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

data class AppIconOption(val alias: String, val label: String)

/** Troca o ícone do app ativando um "atalho" diferente no Android. */
object AppIcons {
    val options = listOf(
        AppIconOption("IconBlue", "Azul"),
        AppIconOption("IconBlack", "Preto"),
        AppIconOption("IconNeon", "Neon"),
        AppIconOption("IconSunset", "Pôr do sol"),
    )

    private fun component(context: Context, alias: String) =
        ComponentName(context.packageName, "${context.packageName}.$alias")

    fun current(context: Context): Int {
        val pm = context.packageManager
        options.forEachIndexed { i, o ->
            if (i > 0 && pm.getComponentEnabledSetting(component(context, o.alias)) ==
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            ) return i
        }
        return 0
    }

    fun set(context: Context, index: Int) {
        val pm = context.packageManager
        // Primeiro liga o novo, depois desliga os outros (assim o app nunca fica sem ícone)
        pm.setComponentEnabledSetting(
            component(context, options[index].alias),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP,
        )
        options.forEachIndexed { i, o ->
            if (i != index) pm.setComponentEnabledSetting(
                component(context, o.alias),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP,
            )
        }
    }
}
