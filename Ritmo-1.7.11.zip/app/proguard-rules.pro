# Regras extras do R8 (o otimizador que deixa o APK menor).
# Anotações usadas só na compilação de algumas bibliotecas; não fazem falta no app.
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
-dontwarn org.checkerframework.**
-dontwarn afu.org.checkerframework.**
-dontwarn com.google.j2objc.annotations.**
-dontwarn org.codehaus.mojo.animal_sniffer.**
-dontwarn kotlin.annotations.jvm.**
-ignorewarnings

# Mantém o widget e os ícones alternativos (são chamados pelo Android pelo nome)
-keep class com.ritmo.player.playback.RitmoWidget { *; }
-keep class com.ritmo.player.RitmoApp { *; }
