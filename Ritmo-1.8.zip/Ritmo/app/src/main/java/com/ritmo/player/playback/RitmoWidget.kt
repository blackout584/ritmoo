package com.ritmo.player.playback

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.net.Uri
import android.view.KeyEvent
import android.widget.RemoteViews
import androidx.annotation.OptIn
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaButtonReceiver
import com.ritmo.player.MainActivity
import com.ritmo.player.R
import java.util.concurrent.Executors

/** Widget da tela inicial: capa, nome e botões de tocar/pausar, anterior e próxima. */
class RitmoWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        WidgetUpdater.push(context)
    }
}

/** 1.8: widget redondo de disco. */
class RitmoDiscWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        WidgetUpdater.push(context)
    }
}

object WidgetUpdater {
    @Volatile private var rawArt: Bitmap? = null
    @Volatile private var discAngle = 0f
    @Volatile private var title: String? = null
    @Volatile private var artist: String? = null
    @Volatile private var playing = false
    @Volatile private var art: Bitmap? = null
    private var artKey: String? = null
    private val executor = Executors.newSingleThreadExecutor()

    /** Usado pelo botão do painel rápido. */
    val isPlaying: Boolean get() = playing
    val currentTitle: String? get() = title

    /** Mesmo que apertar play/pause num fone (funciona até com o app fechado). */
    fun sendPlayPause(context: Context) {
        runCatching { mediaButton(context, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, 11).send() }
    }

    /** Chamado pelo serviço de música sempre que algo muda. */
    fun update(context: Context, player: Player) {
        val app = context.applicationContext
        val md = player.mediaMetadata
        title = md.title?.toString()
        artist = md.artist?.toString()
        playing = player.isPlaying
        val uri = md.artworkUri
        val key = uri?.toString()
        // Atualiza também o botão do painel rápido
        runCatching {
            android.service.quicksettings.TileService.requestListeningState(
                app, ComponentName(app, RitmoTileService::class.java)
            )
        }
        if (key != artKey) {
            artKey = key
            art = null
            push(app)
            rawArt = null
            // o disco dá um giro a cada música nova
            discAngle = (discAngle + 137f) % 360f
            if (uri != null) executor.execute {
                val src = loadSquare(app, uri)
                if (artKey == key) {
                    rawArt = src
                    art = src?.let { rounded(it) }
                    push(app)
                }
            }
        } else {
            push(app)
        }
    }

    fun push(context: Context) {
        pushDisc(context)
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, RitmoWidget::class.java))
        if (ids.isEmpty()) return
        val views = RemoteViews(context.packageName, R.layout.widget_player)
        views.setTextViewText(R.id.widget_title, title ?: context.getString(R.string.app_name))
        views.setTextViewText(R.id.widget_artist, artist ?: context.getString(R.string.widget_hint))
        views.setImageViewResource(R.id.widget_play, if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        val bmp = art
        if (bmp != null) views.setImageViewBitmap(R.id.widget_art, bmp)
        else views.setImageViewResource(R.id.widget_art, R.drawable.widget_art_placeholder)

        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        views.setOnClickPendingIntent(R.id.widget_root, open)
        views.setOnClickPendingIntent(R.id.widget_play, mediaButton(context, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, 11))
        views.setOnClickPendingIntent(R.id.widget_next, mediaButton(context, KeyEvent.KEYCODE_MEDIA_NEXT, 12))
        views.setOnClickPendingIntent(R.id.widget_prev, mediaButton(context, KeyEvent.KEYCODE_MEDIA_PREVIOUS, 13))
        runCatching { manager.updateAppWidget(ids, views) }
    }

    /** Os botões funcionam como os botões de mídia de um fone: o Android entrega ao Ritmo. */
    @OptIn(UnstableApi::class)
    private fun mediaButton(context: Context, keyCode: Int, requestCode: Int): PendingIntent {
        val intent = Intent(Intent.ACTION_MEDIA_BUTTON)
            .setClass(context, MediaButtonReceiver::class.java)
            .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        return PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
    }

    /** 1.8: atualiza os widgets de disco. */
    private fun pushDisc(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, RitmoDiscWidget::class.java))
        if (ids.isEmpty()) return
        val views = RemoteViews(context.packageName, R.layout.widget_disc)
        views.setTextViewText(R.id.disc_title, title ?: context.getString(R.string.app_name))
        views.setTextViewText(R.id.disc_artist, artist ?: context.getString(R.string.widget_hint))
        views.setImageViewResource(R.id.disc_play, if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        views.setImageViewBitmap(R.id.disc_art, discBitmap(rawArt, discAngle))
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        views.setOnClickPendingIntent(R.id.disc_root, open)
        views.setOnClickPendingIntent(R.id.disc_play, mediaButton(context, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, 11))
        views.setOnClickPendingIntent(R.id.disc_next, mediaButton(context, KeyEvent.KEYCODE_MEDIA_NEXT, 12))
        views.setOnClickPendingIntent(R.id.disc_prev, mediaButton(context, KeyEvent.KEYCODE_MEDIA_PREVIOUS, 13))
        runCatching { manager.updateAppWidget(ids, views) }
    }

    /** Desenha o disco de vinil com a capa no meio, girado em [angle] graus. */
    private fun discBitmap(cover: Bitmap?, angle: Float): Bitmap {
        val size = 320
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val cx = size / 2f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = 0xFF111114.toInt()
        c.drawCircle(cx, cx, cx, paint)
        // sulcos
        val groove = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.4f }
        var r = cx * 0.96f
        var i = 0
        while (r > cx * 0.42f) {
            groove.color = if (i % 3 == 0) 0x22FFFFFF else 0x10FFFFFF
            c.drawCircle(cx, cx, r, groove)
            r -= cx * 0.035f
            i++
        }
        // capa redonda no meio, girada
        val artR = cx * 0.4f
        c.save()
        c.rotate(angle, cx, cx)
        val circle = android.graphics.Path().apply { addCircle(cx, cx, artR, android.graphics.Path.Direction.CW) }
        c.clipPath(circle)
        if (cover != null) {
            c.drawBitmap(cover, null, RectF(cx - artR, cx - artR, cx + artR, cx + artR), Paint(Paint.FILTER_BITMAP_FLAG))
        } else {
            paint.color = 0xFF534AB7.toInt()
            c.drawCircle(cx, cx, artR, paint)
        }
        c.restore()
        // furo
        paint.color = 0xFF111114.toInt()
        c.drawCircle(cx, cx, cx * 0.05f, paint)
        // brilho na borda
        groove.color = 0x33FFFFFF
        groove.strokeWidth = 2f
        c.drawCircle(cx, cx, cx - 1f, groove)
        return out
    }

    private fun loadSquare(context: Context, uri: Uri): Bitmap? = runCatching {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 200 && bounds.outHeight / (sample * 2) >= 200) sample *= 2
        val src = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return@runCatching null
        Bitmap.createScaledBitmap(src, 200, 200, true)
    }.getOrNull()

    private fun loadArt(context: Context, uri: Uri): Bitmap? = runCatching {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 200 && bounds.outHeight / (sample * 2) >= 200) sample *= 2
        val src = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return@runCatching null
        rounded(Bitmap.createScaledBitmap(src, 200, 200, true))
    }.getOrNull()

    /** Cantos arredondados na capa (o widget não sabe arredondar sozinho). */
    private fun rounded(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val rect = RectF(0f, 0f, src.width.toFloat(), src.height.toFloat())
        canvas.drawRoundRect(rect, 28f, 28f, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(src, 0f, 0f, paint)
        return out
    }
}
