package com.ritmo.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.data.Song
import java.util.Calendar

/** Tela inicial "Para você": recentes, mais ouvidas e adicionadas recentemente. */
@Composable
fun HomeScreen(vm: MainViewModel, onOpen: (Detail) -> Unit, onBack: () -> Unit) {
    androidx.activity.compose.BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize()) {
        SimpleTopBar("Para você", onBack = onBack)
        ForYouContent(vm, onOpen)
    }
}

/** Conteúdo da aba Início ("Para você"). */
@Composable
fun ForYouContent(vm: MainViewModel, onOpen: (Detail) -> Unit = {}) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    val stats by vm.statsStore.stats.collectAsStateWithLifecycle()
    val byId = remember(songs) { songs.associateBy { it.id } }

    val recent = remember(byId, stats) {
        stats.entries.sortedByDescending { it.value.lastPlayed }.mapNotNull { byId[it.key] }.take(15)
    }
    val top = remember(byId, stats) {
        stats.entries.sortedByDescending { it.value.count }
            .mapNotNull { e -> byId[e.key]?.let { it to e.value.count } }
            .take(5)
    }
    val added = remember(songs) { songs.sortedByDescending { it.dateAdded }.take(15) }
    val topArtists = remember(songs, stats) {
        songs.groupBy { it.artist }
            .map { (name, list) -> Triple(name, list.sumOf { stats[it.id]?.count ?: 0 }, list.first().artUri) }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(10)
    }
    val greeting = remember {
        when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
            in 5..11 -> "Bom dia"
            in 12..17 -> "Boa tarde"
            else -> "Boa noite"
        }
    }

    if (songs.isEmpty()) {
        EmptyMessage("Nenhuma música encontrada ainda.\nAbra a Biblioteca para carregar suas músicas.")
        return
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        // Retrospectiva do mês que passou (só nos 7 primeiros dias)
        item { HomeRecapCard(vm) { month -> onOpen(Detail.Recap(month)) } }
        item {
            Column(Modifier.padding(start = 14.dp, end = 14.dp, top = 6.dp)) {
                GreetingLine(vm)
                Text("Para você", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        }
        item {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { vm.shuffleAll(songs) },
            ) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(36.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.Shuffle, null, tint = MaterialTheme.colorScheme.onPrimary)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Toque algo aleatório", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Mistura de ${songs.size} músicas",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }

        // Procurar músicas novas
        item { ScanCard(vm, onOpen) }

        // Playlists automáticas em blocos pequenos
        item {
            Column(Modifier.padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SmartKind.entries.chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { kind ->
                            Row(
                                Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(kind.color.copy(alpha = 0.22f))
                                    .clickable { onOpen(Detail.Smart(kind)) }
                                    .padding(horizontal = 10.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(kind.icon, null, Modifier.size(18.dp), tint = kind.color)
                                Text(
                                    kind.label,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(start = 6.dp),
                                )
                            }
                        }
                    }
                }
            }
        }

        if (recent.isNotEmpty()) {
            item { SectionHeader("Tocadas recentemente") }
            item { SongCarousel(recent) { i -> vm.playSongs(recent, i) } }
        }

        if (top.isNotEmpty()) {
            item { SectionHeader("Mais ouvidas") }
            itemsIndexed(top, key = { _, p -> "top_${p.first.id}" }) { i, (song, count) ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { vm.playSongs(top.map { it.first }, i) }
                        .padding(horizontal = 14.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "${i + 1}",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.width(24.dp),
                    )
                    ArtImage(song.artUri, Modifier.size(40.dp))
                    Column(Modifier.weight(1f).padding(start = 10.dp)) {
                        Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            if (count == 1) "1 vez" else "$count vezes",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        if (topArtists.isNotEmpty()) {
            item { SectionHeader("Artistas que você mais ouve") }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    itemsIndexed(topArtists, key = { _, a -> "art_${a.first}" }) { _, (name, _, art) ->
                        Column(
                            Modifier.width(60.dp).clip(RoundedCornerShape(10.dp)).clickable { onOpen(Detail.Artist(name)) },
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            ArtImage(art, Modifier.size(52.dp).clip(CircleShape), corner = 26.dp)
                            Text(
                                name,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(top = 3.dp),
                            )
                        }
                    }
                }
            }
        }

        item { SectionHeader("Adicionadas recentemente") }
        item { SongCarousel(added) { i -> vm.playSongs(added, i) } }
    }
}

/** Cartão "Recentes": as músicas que você tocou por último. */
@Composable
fun RecentScreen(vm: MainViewModel, onBack: () -> Unit) {
    androidx.activity.compose.BackHandler(onBack = onBack)
    val songs by vm.songs.collectAsStateWithLifecycle()
    val stats by vm.statsStore.stats.collectAsStateWithLifecycle()
    val recent = remember(songs, stats) {
        val byId = songs.associateBy { it.id }
        stats.entries.sortedByDescending { it.value.lastPlayed }.mapNotNull { byId[it.key] }.take(100)
    }
    Column(Modifier.fillMaxSize()) {
        SimpleTopBar("Tocadas recentemente", onBack = onBack)
        if (recent.isEmpty()) EmptyMessage("Você ainda não tocou nenhuma música.") else SongList(recent, vm)
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodyLarge,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 6.dp),
    )
}

@Composable
private fun SongCarousel(songs: List<Song>, onPlay: (Int) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        itemsIndexed(songs, key = { _, s -> s.id }) { i, song ->
            Column(
                Modifier
                    .width(88.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onPlay(i) }
            ) {
                ArtImage(song.artUri, Modifier.size(88.dp), corner = 10.dp)
                Spacer(Modifier.height(4.dp))
                Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                Text(
                    song.artist,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
