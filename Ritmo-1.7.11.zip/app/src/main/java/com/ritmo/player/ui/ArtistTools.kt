@file:OptIn(ExperimentalMaterial3Api::class)

package com.ritmo.player.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.data.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Normalizer

// ---------------- Menu ao segurar o artista ----------------

@Composable
fun ArtistOptionsSheet(vm: MainViewModel, name: String, songs: List<Song>, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val photos by vm.artistPhotos.photos.collectAsStateWithLifecycle()
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var addingSongs by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) pickedUri = uri
    }
    val totalMin = songs.sumOf { it.durationMs } / 60_000
    val time = if (totalMin >= 60) "${totalMin / 60}h ${totalMin % 60}min" else "$totalMin min"

    val crop = pickedUri
    if (crop != null) {
        PhotoCropDialog(
            title = "Foto de $name",
            uri = crop,
            onPickAnother = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            onSave = { bmp ->
                vm.artistPhotos.save(name, bmp)
                Toast.makeText(context, "Foto de $name salva", Toast.LENGTH_SHORT).show()
                pickedUri = null
                onDismiss()
            },
            onDismiss = { pickedUri = null },
        )
        return
    }
    if (addingSongs) {
        AddSongsToArtistDialog(vm, name, onDismiss = { addingSongs = false; onDismiss() })
        return
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(bottom = 24.dp)) {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                ArtImage(
                    vm.artistArt(name, songs.firstOrNull()?.artUri),
                    Modifier.size(52.dp).clip(CircleShape),
                    corner = 26.dp,
                )
                Column(Modifier.padding(start = 14.dp)) {
                    Text(name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "${songs.size} músicas · $time",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            SheetItem(Icons.Rounded.PlayArrow, "Tocar") { vm.playSongs(songs, 0); onDismiss() }
            SheetItem(Icons.Rounded.Shuffle, "Tocar aleatório") { vm.shuffleAll(songs); onDismiss() }
            SheetItem(Icons.AutoMirrored.Rounded.PlaylistAdd, "Adicionar à fila") { songs.forEach { vm.addToQueue(it) }; onDismiss() }
            SheetItem(Icons.Rounded.Add, "Adicionar músicas a $name") { addingSongs = true }
            SheetItem(Icons.Rounded.PhotoLibrary, "Trocar foto do artista", highlight = true) {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }
            if (photos.containsKey(name)) {
                SheetItem(Icons.Rounded.RestartAlt, "Voltar à capa original") {
                    vm.artistPhotos.remove(name)
                    onDismiss()
                }
            }
        }
    }
}

@Composable
private fun SheetItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, highlight: Boolean = false, onClick: () -> Unit) {
    val color = if (highlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = color)
        Text(label, color = color, fontWeight = if (highlight) FontWeight.SemiBold else null, modifier = Modifier.padding(start = 16.dp))
    }
}

// ---------------- Ajustar a foto no círculo ----------------

private fun loadBitmap(context: Context, uri: Uri, maxSide: Int = 1600): Bitmap? = runCatching {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (bounds.outWidth / sample > maxSide || bounds.outHeight / sample > maxSide) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
}.getOrNull()

@Composable
fun PhotoCropDialog(
    title: String,
    uri: Uri,
    onPickAnother: () -> Unit,
    onSave: (Bitmap) -> Unit,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val bitmap by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) { loadBitmap(context, uri) }
    }
    var zoom by remember(uri) { mutableFloatStateOf(1f) }
    var offset by remember(uri) { mutableStateOf(Offset.Zero) }
    var rotation by remember(uri) { mutableFloatStateOf(0f) }
    var circlePx by remember { mutableFloatStateOf(1f) }
    val pink = MaterialTheme.colorScheme.primary

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(color = Color(0xFF08080A), contentColor = Color.White, modifier = Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, "Fechar") }
                    Text(title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    IconButton(onClick = { rotation = (rotation + 90f) % 360f }) { Icon(Icons.Rounded.RotateRight, "Girar") }
                }
                BoxWithConstraints(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    val density = LocalDensity.current
                    val areaPx = with(density) { minOf(maxWidth, maxHeight).toPx() }
                    circlePx = areaPx * 0.82f
                    val bmp = bitmap
                    if (bmp == null) {
                        Text("Carregando…", color = Color.White.copy(alpha = 0.7f))
                    } else {
                        val image = remember(bmp) { bmp.asImageBitmap() }
                        val base = circlePx / minOf(bmp.width, bmp.height)
                        Canvas(
                            Modifier
                                .fillMaxSize()
                                .pointerInput(bmp) {
                                    detectTransformGestures { _, pan, gestureZoom, _ ->
                                        zoom = (zoom * gestureZoom).coerceIn(1f, 5f)
                                        offset += pan
                                    }
                                }
                        ) {
                            translate(center.x + offset.x, center.y + offset.y) {
                                rotate(rotation, pivot = Offset.Zero) {
                                    scale(base * zoom, pivot = Offset.Zero) {
                                        drawImage(
                                            image,
                                            dstOffset = IntOffset(-bmp.width / 2, -bmp.height / 2),
                                            dstSize = IntSize(bmp.width, bmp.height),
                                        )
                                    }
                                }
                            }
                            // Escurece tudo fora do círculo
                            val r = circlePx / 2
                            val hole = Path().apply {
                                fillType = PathFillType.EvenOdd
                                addRect(androidx.compose.ui.geometry.Rect(Offset.Zero, size))
                                addOval(androidx.compose.ui.geometry.Rect(center, r))
                            }
                            drawPath(hole, Color.Black.copy(alpha = 0.65f))
                            drawCircle(pink, radius = r, center = center, style = Stroke(width = 3.dp.toPx()))
                        }
                    }
                }
                Text(
                    "Arraste para posicionar · dois dedos para zoom",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 8.dp),
                )
                Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.ZoomOut, null, tint = Color.White.copy(alpha = 0.7f))
                    Slider(
                        value = zoom,
                        onValueChange = { zoom = it },
                        valueRange = 1f..5f,
                        colors = SliderDefaults.colors(thumbColor = pink, activeTrackColor = pink),
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                    )
                    Icon(Icons.Rounded.ZoomIn, null, tint = Color.White.copy(alpha = 0.7f))
                }
                Button(
                    onClick = {
                        val bmp = bitmap ?: return@Button
                        scope.launch {
                            val out = withContext(Dispatchers.Default) {
                                cropCircleArea(bmp, circlePx, zoom, offset, rotation)
                            }
                            onSave(out)
                        }
                    },
                    enabled = bitmap != null,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                ) { Text("Salvar foto") }
                TextButton(onClick = onPickAnother, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Text("Escolher outra da galeria", color = Color.White.copy(alpha = 0.7f))
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

/** Recorta o quadrado que aparece dentro do círculo, com o mesmo zoom, posição e giro da tela. */
private fun cropCircleArea(bmp: Bitmap, circlePx: Float, zoom: Float, offset: Offset, rotation: Float): Bitmap {
    val outSize = 640
    val out = Bitmap.createBitmap(outSize, outSize, Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(out)
    c.drawColor(android.graphics.Color.BLACK)
    val k = outSize / circlePx
    val base = circlePx / minOf(bmp.width, bmp.height)
    c.translate(outSize / 2f, outSize / 2f)
    c.scale(k, k)
    c.translate(offset.x, offset.y)
    c.rotate(rotation)
    c.scale(base * zoom, base * zoom)
    c.drawBitmap(bmp, -bmp.width / 2f, -bmp.height / 2f, android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
    return out
}

// ---------------- Adicionar músicas ao artista ----------------

private fun norm(s: String): String =
    Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

private fun isUnknownArtist(a: String): Boolean {
    val n = norm(a).trim()
    return n.isBlank() || "desconhecido" in n || n == "<unknown>" || n == "unknown"
}

@Composable
fun AddSongsToArtistDialog(vm: MainViewModel, artist: String, onDismiss: () -> Unit) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(0) }
    val selected = remember { mutableStateMapOf<Long, Boolean>() }
    val key = norm(artist).replace(Regex("[^a-z0-9]"), "")
    val others = remember(songs, artist) { songs.filter { it.artist != artist } }
    val unknownCount = remember(others) { others.count { isUnknownArtist(it.artist) } }
    val list = remember(others, filter, query) {
        val base = when (filter) {
            0 -> others.filter { isUnknownArtist(it.artist) }
            2 -> others.filter { s ->
                key.length >= 3 && (norm(s.title).replace(Regex("[^a-z0-9]"), "").contains(key) ||
                    norm(s.path).replace(Regex("[^a-z0-9]"), "").contains(key))
            }
            else -> others
        }
        val q = norm(query.trim())
        if (q.isBlank()) base else base.filter { norm(it.title).contains(q) || norm(it.artist).contains(q) }
    }
    val count = selected.count { it.value }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, "Fechar") }
                    Text("Adicionar a $artist", fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Row(
                    Modifier
                        .padding(horizontal = 16.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(28.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.Search, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Box(Modifier.weight(1f).padding(start = 8.dp)) {
                        if (query.isEmpty()) Text("Buscar música", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        BasicTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface),
                            cursorBrush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary),
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    listOf("Sem artista ($unknownCount)", "Todas", "Parecidas").forEachIndexed { i, label ->
                        val sel = filter == i
                        Text(
                            label,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                .clickable { filter = i }
                                .padding(horizontal = 14.dp, vertical = 7.dp),
                        )
                    }
                }
                if (list.isEmpty()) {
                    Text(
                        "Nenhuma música aqui.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(24.dp),
                    )
                }
                LazyColumn(Modifier.weight(1f)) {
                    items(list, key = { it.id }) { s ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { selected[s.id] = selected[s.id] != true }
                                .padding(horizontal = 8.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Checkbox(checked = selected[s.id] == true, onCheckedChange = { selected[s.id] = it })
                            ArtImage(s.artUri, Modifier.size(40.dp).clip(RoundedCornerShape(6.dp)), corner = 6.dp)
                            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                                Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    s.artist,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }
                Button(
                    onClick = {
                        val ids = selected.filter { it.value }.keys
                        vm.setArtistFor(ids, artist)
                        Toast.makeText(context, "${ids.size} música(s) adicionada(s) a $artist", Toast.LENGTH_SHORT).show()
                        onDismiss()
                    },
                    enabled = count > 0,
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                ) {
                    Text(if (count == 1) "Adicionar 1 música" else "Adicionar $count músicas")
                }
            }
        }
    }
}
