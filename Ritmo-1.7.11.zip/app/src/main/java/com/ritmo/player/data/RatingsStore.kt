package com.ritmo.player.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

/** Notas de 1 a 5 estrelas que você dá para as músicas. */
class RatingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("ratings", Context.MODE_PRIVATE)
    private val _ratings = MutableStateFlow(load())
    val ratings: StateFlow<Map<Long, Int>> = _ratings.asStateFlow()

    fun set(id: Long, stars: Int) {
        val updated = if (stars <= 0) _ratings.value - id else _ratings.value + (id to stars.coerceIn(1, 5))
        _ratings.value = updated
        val o = JSONObject()
        updated.forEach { (k, v) -> o.put(k.toString(), v) }
        prefs.edit().putString("data", o.toString()).apply()
    }

    private fun load(): Map<Long, Int> = runCatching {
        val o = JSONObject(prefs.getString("data", "{}") ?: "{}")
        o.keys().asSequence().associate { it.toLong() to o.getInt(it) }
    }.getOrDefault(emptyMap())
}
