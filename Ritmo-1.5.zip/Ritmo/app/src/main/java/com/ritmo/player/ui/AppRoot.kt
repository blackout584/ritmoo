package com.ritmo.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle

enum class MainTab(val label: String, val icon: ImageVector) {
    HOME("Início", Icons.Rounded.Home),
    LIBRARY("Biblioteca", Icons.Rounded.LibraryMusic),
    PLAYLISTS("Playlists", Icons.AutoMirrored.Rounded.QueueMusic),
    EQUALIZER("Equalizador", Icons.Rounded.Equalizer),
    SETTINGS("Ajustes", Icons.Rounded.Settings),
}

@Composable
fun AppRoot(vm: MainViewModel) {
    var tab by rememberSaveable { mutableStateOf(MainTab.HOME) }
    var detail by remember { mutableStateOf<Detail?>(null) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    val player by vm.player.collectAsStateWithLifecycle()
    val screenState = rememberSaveableStateHolder()

    BackHandler(enabled = showPlayer) { showPlayer = false }
    BackHandler(enabled = !showPlayer && detail != null) { detail = null }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            bottomBar = {
                Column {
                    AnimatedVisibility(
                        visible = player.hasMedia,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut(),
                    ) {
                        MiniPlayer(player, vm, onClick = { showPlayer = true })
                    }
                    NavigationBar {
                        MainTab.entries.forEach { t ->
                            NavigationBarItem(
                                selected = tab == t,
                                onClick = { tab = t; detail = null },
                                icon = { Icon(t.icon, null) },
                                label = { Text(t.label, maxLines = 1) },
                            )
                        }
                    }
                }
            },
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                // Cada troca de tela aparece com um leve efeito de entrada
                AnimatedContent(
                    targetState = detail ?: tab,
                    transitionSpec = {
                        val opening = targetState is Detail
                        val closing = initialState is Detail && targetState !is Detail
                        when {
                            opening -> (slideInHorizontally(tween(320)) { it / 3 } + fadeIn(tween(320))) togetherWith
                                fadeOut(tween(150))
                            closing -> fadeIn(tween(250)) togetherWith
                                (slideOutHorizontally(tween(280)) { it / 3 } + fadeOut(tween(200)))
                            else -> (fadeIn(tween(250)) + scaleIn(tween(250), initialScale = 0.97f)) togetherWith
                                fadeOut(tween(120))
                        }
                    },
                    label = "screens",
                    modifier = Modifier.fillMaxSize(),
                ) { screen ->
                    // Guarda a memória de cada tela (aba aberta, posição da rolagem),
                    // para voltar exatamente onde você estava.
                    screenState.SaveableStateProvider(key = screen.toString()) {
                        when (screen) {
                            is Detail -> DetailScreen(screen, vm, onBack = { detail = null })
                            MainTab.HOME -> HomeScreen(vm)
                            MainTab.LIBRARY -> LibraryScreen(vm, onOpen = { detail = it })
                            MainTab.PLAYLISTS -> PlaylistsScreen(vm, onOpen = { detail = it })
                            MainTab.EQUALIZER -> EqualizerScreen()
                            MainTab.SETTINGS -> SettingsScreen(vm)
                            else -> {}
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = showPlayer && player.hasMedia,
            enter = slideInVertically { it },
            exit = slideOutVertically { it },
        ) {
            NowPlayingScreen(vm, onClose = { showPlayer = false })
        }
    }
}
