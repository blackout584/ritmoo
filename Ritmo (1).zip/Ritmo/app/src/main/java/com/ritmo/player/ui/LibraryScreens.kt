@file:OptIn(ExperimentalMaterial3Api::class)

package com.ritmo.player.ui

import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.data.FAVORITES_ID
import com.ritmo.player.data.Song

sealed interface Detail {
    data class Album(val albumId: Long, val name: String) : Detail
    data class Artist(val name: String) : Detail
    data class Folder(val path: String, val name: String) : Detail
    data class PlaylistDetail(val id: Long) : Detail
}

private data class AlbumInfo(val id: Long, val name: String, val artist: String, val artUri: Uri, val count: Int)

// ---------------- Biblioteca ----------------

@Composable
fun LibraryScreen(vm: MainViewModel, onOpen: (Detail) -> Unit) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    var page by rememberSaveable { mutableIntStateOf(0) }
    val titles = listOf("Músicas", "Álbuns", "Artistas", "Pastas")

    Column(Modifier.fillMaxSize()) {
        SimpleTopBar("Biblioteca", actions = {
            IconButton(onClick = { vm.loadLibrary(force = true) }) {
                Icon(Icons.Rounded.Refresh, "Atualizar biblioteca")
            }
        })
        ScrollableTabRow(selectedTabIndex = page, edgePadding = 8.dp) {
            titles.forEachIndexed { i, t ->
                Tab(selected = page == i, onClick = { page = i }, text = { Text(t) })
            }
        }
        when {
            loading && songs.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            songs.isEmpty() -> EmptyMessage("Nenhuma música encontrada no aparelho.\nCopie arquivos de áudio para o celular e toque em atualizar.")
            else -> when (page) {
                0 -> SongsTab(songs, vm)
                1 -> AlbumsTab(songs, onOpen)
                2 -> ArtistsTab(songs, onOpen)
                else -> FoldersTab(songs, onOpen)
            }
        }
    }
}

@Composable
private fun SongsTab(songs: List<Song>, vm: MainViewModel) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = remember(songs, query) {
        if (query.isBlank()) songs else songs.filter {
            it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
        }
    }
    SongList(filtered, vm, header = {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Buscar música, artista ou álbum") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, "Limpar") }
            },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        )
    })
}

@Composable
private fun AlbumsTab(songs: List<Song>, onOpen: (Detail) -> Unit) {
    val albums = remember(songs) {
        songs.groupBy { it.albumId }.map { (id, list) ->
            val first = list.first()
            AlbumInfo(id, first.album, first.artist, first.artUri, list.size)
        }.sortedBy { it.name.lowercase() }
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(150.dp),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        items(albums, key = { it.id }) { a ->
            Column(
                Modifier.clip(RoundedCornerShape(12.dp))
                    .clickable { onOpen(Detail.Album(a.id, a.name)) }
            ) {
                ArtImage(a.artUri, Modifier.fillMaxWidth().aspectRatio(1f), corner = 12.dp)
                Text(
                    a.name,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 6.dp, start = 2.dp),
                )
                Text(
                    a.artist,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(start = 2.dp, bottom = 4.dp),
                )
            }
        }
    }
}

@Composable
private fun ArtistsTab(songs: List<Song>, onOpen: (Detail) -> Unit) {
    val artists = remember(songs) {
        songs.groupBy { it.artist }.map { (name, list) -> name to list.size }.sortedBy { it.first.lowercase() }
    }
    LazyColumn(Modifier.fillMaxSize()) {
        items(artists, key = { it.first }) { (name, count) ->
            GroupRow(Icons.Rounded.Person, name, "$count músicas", onClick = { onOpen(Detail.Artist(name)) })
        }
    }
}

@Composable
private fun FoldersTab(songs: List<Song>, onOpen: (Detail) -> Unit) {
    val folders = remember(songs) {
        songs.groupBy { it.folderPath }.map { (path, list) -> Triple(path, list.first().folderName, list.size) }
            .sortedBy { it.second.lowercase() }
    }
    LazyColumn(Modifier.fillMaxSize()) {
        items(folders, key = { it.first }) { (path, name, count) ->
            GroupRow(Icons.Rounded.Folder, name, "$count músicas • $path", onClick = { onOpen(Detail.Folder(path, name)) })
        }
    }
}

// ---------------- Playlists ----------------

@Composable
fun PlaylistsScreen(vm: MainViewModel, onOpen: (Detail) -> Unit) {
    val playlists by vm.playlistStore.playlists.collectAsStateWithLifecycle()
    var creating by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        SimpleTopBar("Playlists", actions = {
            IconButton(onClick = { creating = true }) { Icon(Icons.Rounded.Add, "Nova playlist") }
        })
        LazyColumn(Modifier.fillMaxSize()) {
            items(playlists, key = { it.id }) { p ->
                GroupRow(
                    icon = if (p.id == FAVORITES_ID) Icons.Rounded.Favorite else Icons.AutoMirrored.Rounded.QueueMusic,
                    title = p.name,
                    subtitle = "${p.songIds.size} músicas",
                    onClick = { onOpen(Detail.PlaylistDetail(p.id)) },
                )
            }
        }
    }
    if (creating) {
        NameDialog("Nova playlist", "", "Criar", onConfirm = {
            vm.playlistStore.create(it)
            creating = false
        }, onDismiss = { creating = false })
    }
}

// ---------------- Detalhes (álbum, artista, pasta, playlist) ----------------

@Composable
fun DetailScreen(detail: Detail, vm: MainViewModel, onBack: () -> Unit) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    val playlists by vm.playlistStore.playlists.collectAsStateWithLifecycle()
    val byId = remember(songs) { songs.associateBy { it.id } }
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }

    val playlist = (detail as? Detail.PlaylistDetail)?.let { d -> playlists.firstOrNull { it.id == d.id } }
    if (detail is Detail.PlaylistDetail && playlist == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    val (title, list) = remember(detail, songs, playlist) {
        when (detail) {
            is Detail.Album -> detail.name to songs.filter { it.albumId == detail.albumId }.sortedBy { it.trackNumber }
            is Detail.Artist -> detail.name to songs.filter { it.artist == detail.name }
                .sortedWith(compareBy({ it.album.lowercase() }, { it.trackNumber }))
            is Detail.Folder -> detail.name to songs.filter { it.folderPath == detail.path }
            is Detail.PlaylistDetail -> playlist!!.name to playlist.songIds.mapNotNull { byId[it] }
        }
    }

    Column(Modifier.fillMaxSize()) {
        SimpleTopBar(title, onBack = onBack, actions = {
            if (playlist != null && playlist.id != FAVORITES_ID) {
                IconButton(onClick = { renaming = true }) { Icon(Icons.Rounded.Edit, "Renomear") }
                IconButton(onClick = { deleting = true }) { Icon(Icons.Rounded.Delete, "Excluir") }
            }
        })
        if (list.isEmpty()) {
            EmptyMessage(if (playlist != null) "Esta playlist está vazia.\nUse o menu ⋮ de uma música para adicioná-la." else "Nenhuma música aqui.")
        } else {
            SongList(list, vm, playlistId = playlist?.id)
        }
    }

    if (renaming && playlist != null) {
        NameDialog("Renomear playlist", playlist.name, "Salvar", onConfirm = {
            vm.playlistStore.rename(playlist.id, it)
            renaming = false
        }, onDismiss = { renaming = false })
    }
    if (deleting && playlist != null) {
        AlertDialog(
            onDismissRequest = { deleting = false },
            title = { Text("Excluir playlist?") },
            text = { Text("A playlist \"${playlist.name}\" será excluída. As músicas continuam no aparelho.") },
            confirmButton = {
                TextButton(onClick = { deleting = false; vm.playlistStore.delete(playlist.id) }) { Text("Excluir") }
            },
            dismissButton = { TextButton(onClick = { deleting = false }) { Text("Cancelar") } },
        )
    }
}
