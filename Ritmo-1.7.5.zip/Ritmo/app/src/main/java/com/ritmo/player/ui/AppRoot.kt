package com.ritmo.player.ui

import androidx.compose.runtime.LaunchedEffect
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SystemUpdate
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.playback.RitmoWidget
import kotlinx.coroutines.launch

@Composable
fun AppRoot(vm: MainViewModel) {
    var detail by remember { mutableStateOf<Detail?>(null) }
    var page by rememberSaveable { mutableStateOf<Page?>(null) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var showNews by remember { mutableStateOf(false) }
    val player by vm.player.collectAsStateWithLifecycle()
    val onYouTube by vm.onYouTube.collectAsStateWithLifecycle()
    val openUpdateRequest by vm.openUpdateRequest.collectAsStateWithLifecycle()
    LaunchedEffect(openUpdateRequest) {
        if (openUpdateRequest) {
            showPlayer = false
            detail = null
            page = Page.UPDATE
            vm.consumeOpenUpdateRequest()
        }
    }
    val openPlayerRequest by vm.openPlayerRequest.collectAsStateWithLifecycle()
    LaunchedEffect(openPlayerRequest) {
        if (openPlayerRequest) {
            showPlayer = true
            vm.consumeOpenPlayerRequest()
        }
    }
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val screenState = rememberSaveableStateHolder()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    // Novidades: aparece uma vez só, na primeira abertura depois de atualizar
    LaunchedEffect(Unit) {
        val code = appVersionCode(context)
        if (code > 0 && vm.settingsStore.settings.value.lastSeenVersion < code) {
            if (!isFreshInstall(context)) showNews = true
            vm.settingsStore.update { it.copy(lastSeenVersion = code) }
        }
    }

    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }
    BackHandler(enabled = showPlayer) { showPlayer = false }
    BackHandler(enabled = !showPlayer && detail != null) { detail = null }
    // Na aba YouTube o mini player some para o site ficar maior
    val showMini = player.hasMedia && !(onYouTube && detail == null && page == null)

    fun openPage(p: Page) {
        detail = null
        page = p
        scope.launch { drawerState.close() }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = drawerState.isOpen,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = MaterialTheme.colorScheme.surfaceContainerLow) {
                Column(Modifier.verticalScroll(rememberScrollState()).padding(vertical = 12.dp)) {
                    Text(
                        "Ritmo",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 28.dp, vertical = 16.dp),
                    )
                    DrawerItem(Icons.Rounded.Settings, "Configurações") { openPage(Page.SETTINGS) }
                    DrawerItem(Icons.Rounded.Palette, "Personalizar") { openPage(Page.THEMES) }
                    DrawerItem(Icons.Rounded.Equalizer, "Equalizador") { openPage(Page.EQUALIZER) }
                    HorizontalDivider(Modifier.padding(horizontal = 28.dp, vertical = 8.dp))
                    DrawerItem(Icons.Rounded.SystemUpdate, "Atualizar o app") { openPage(Page.UPDATE) }
                    DrawerItem(Icons.Rounded.Backup, "Backup") { openPage(Page.BACKUP) }
                    DrawerItem(Icons.Rounded.Widgets, "Widget da tela inicial") {
                        scope.launch { drawerState.close() }
                        addWidget(context)
                    }
                    DrawerItem(Icons.Rounded.Info, "Sobre o Ritmo") {
                        scope.launch { drawerState.close() }
                        showAbout = true
                    }
                }
            }
        },
    ) {
        Box(Modifier.fillMaxSize()) {
            // Configurações com o fundo liso do tema, sem o papel de parede
            AnimatedVisibility(
                visible = page == Page.SETTINGS && detail == null,
                enter = fadeIn(tween(250)),
                exit = fadeOut(tween(250)),
            ) {
                Box(Modifier.fillMaxSize().background(solidThemeBackground(settings)))
            }
            // Conteúdo (deixa espaço embaixo para o mini player flutuante)
            Box(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(bottom = if (showMini) 68.dp else 0.dp)
                    .navigationBarsPadding()
            ) {
                AnimatedContent(
                    targetState = detail ?: page ?: "main",
                    transitionSpec = {
                        val opening = targetState != "main" && initialState == "main" || targetState is Detail
                        if (opening) {
                            (slideInHorizontally(tween(320)) { it / 3 } + fadeIn(tween(320))) togetherWith fadeOut(tween(150))
                        } else {
                            (fadeIn(tween(250)) + scaleIn(tween(250), initialScale = 0.97f)) togetherWith
                                (slideOutHorizontally(tween(280)) { it / 3 } + fadeOut(tween(200)))
                        }
                    },
                    label = "screens",
                    modifier = Modifier.fillMaxSize(),
                ) { screen ->
                    screenState.SaveableStateProvider(key = screen.toString()) {
                        val back = { page = null }
                        when (screen) {
                            is Detail -> DetailScreen(screen, vm, onBack = { detail = null })
                            Page.SETTINGS -> SettingsScreen(vm, onBack = back, onOpenThemes = { openPage(Page.THEMES) })
                            Page.THEMES -> ThemesScreen(vm, onBack = back)
                            Page.EQUALIZER -> EqualizerScreen(onBack = back)
                            Page.PLAYLISTS -> PlaylistsScreen(vm, onOpen = { detail = it }, onBack = back)
                            Page.FOR_YOU -> HomeScreen(vm, onOpen = { detail = it }, onBack = back)
                            Page.RECENT -> RecentScreen(vm, onBack = back)
                            Page.UPDATE -> SimplePage("Atualizar o app", back) { UpdateSettings(vm) }
                            Page.BACKUP -> SimplePage("Backup", back) { BackupSection() }
                            else -> MainScreen(
                                vm,
                                onOpen = { detail = it },
                                onOpenPage = { openPage(it) },
                                onMenu = { scope.launch { drawerState.open() } },
                            )
                        }
                    }
                }
            }

            // Mini player flutuante
            AnimatedVisibility(
                visible = showMini,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut(),
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding(),
            ) {
                MiniPlayer(player, vm, onClick = { showPlayer = true })
            }

            AnimatedVisibility(
                visible = showPlayer && player.hasMedia,
                enter = slideInVertically { it },
                exit = slideOutVertically { it },
            ) {
                NowPlayingScreen(vm, onClose = { showPlayer = false }, onOpenDetail = { page = null; detail = it })
            }
        }
    }

    if (showAbout) {
        AboutDialog(onDismiss = { showAbout = false }, onShowNews = { showNews = true })
    }
    if (showNews) {
        WhatsNewDialog(onDismiss = { showNews = false })
    }
}

@Composable
private fun DrawerItem(icon: ImageVector, label: String, onClick: () -> Unit) {
    NavigationDrawerItem(
        icon = { Icon(icon, null) },
        label = { Text(label) },
        selected = false,
        onClick = onClick,
        colors = NavigationDrawerItemDefaults.colors(unselectedContainerColor = androidx.compose.ui.graphics.Color.Transparent),
        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
    )
}

/** Página simples com título, botão voltar e conteúdo rolável. */
@Composable
private fun SimplePage(title: String, onBack: () -> Unit, content: @Composable () -> Unit) {
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize()) {
        SimpleTopBar(title, onBack = onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            content()
            Spacer(Modifier.height(24.dp))
        }
    }
}

/** Pede ao Android para colocar o widget do Ritmo na tela inicial. */
private fun addWidget(context: android.content.Context) {
    val manager = AppWidgetManager.getInstance(context)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager.isRequestPinAppWidgetSupported) {
        manager.requestPinAppWidget(ComponentName(context, RitmoWidget::class.java), null, null)
    } else {
        Toast.makeText(
            context,
            "Segure um espaço vazio na tela inicial, toque em Widgets e escolha Ritmo",
            Toast.LENGTH_LONG,
        ).show()
    }
}
