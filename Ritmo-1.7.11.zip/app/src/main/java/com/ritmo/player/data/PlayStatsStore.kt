package com.ritmo.player.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class PlayStat(val count: Int, val lastPlayed: Long)

/** Quantas vezes cada música tocou e quando foi a última vez (para a tela "Para você"). */
class PlayStatsStore(context: Context) {
    private val prefs = context.getSharedPreferences("play_stats", Context.MODE_PRIVATE)
    private val _stats = MutableStateFlow(load())
    val stats: StateFlow<Map<Long, PlayStat>> = _stats.asStateFlow()

    fun record(id: Long) {
        val old = _stats.value[id]
        val updated = _stats.value + (id to PlayStat((old?.count ?: 0) + 1, System.currentTimeMillis()))
        _stats.value = updated
        val o = JSONObject()
        updated.forEach { (k, v) -> o.put(k.toString(), JSONArray().put(v.count).put(v.lastPlayed)) }
        prefs.edit().putString("data", o.toString()).apply()
    }

    private fun load(): Map<Long, PlayStat> = runCatching {
        val o = JSONObject(prefs.getString("data", "{}") ?: "{}")
        o.keys().asSequence().associate { k ->
            val a = o.getJSONArray(k)
            k.toLong() to PlayStat(a.getInt(0), a.getLong(1))
        }
    }.getOrDefault(emptyMap())
}
