package com.ritmo.player.data

import java.text.Collator
import java.util.Locale

enum class SongSort(val label: String) {
    TITLE_ASC("A → Z"),
    TITLE_DESC("Z → A"),
    RECENT("Adicionadas recentemente"),
    OLDEST("Adicionadas primeiro"),
    ARTIST("Por artista"),
    DURATION("Por duração"),
    RATING("Por nota (estrelas)"),
}

/** Compara textos em português, ignorando acentos e maiúsculas (á = a = A). */
private val collator: Collator = Collator.getInstance(Locale("pt", "BR")).apply {
    strength = Collator.PRIMARY
}

fun List<Song>.sortedFor(sort: SongSort, ratings: Map<Long, Int> = emptyMap()): List<Song> = when (sort) {
    SongSort.TITLE_ASC -> sortedWith(compareBy(collator) { it.title })
    SongSort.TITLE_DESC -> sortedWith(compareBy<Song, String>(collator) { it.title }.reversed())
    SongSort.RECENT -> sortedByDescending { it.dateAdded }
    SongSort.OLDEST -> sortedBy { it.dateAdded }
    SongSort.ARTIST -> sortedWith(compareBy<Song, String>(collator) { it.artist }.thenBy(collator) { it.title })
    SongSort.DURATION -> sortedByDescending { it.durationMs }
    SongSort.RATING -> sortedWith(compareByDescending<Song> { ratings[it.id] ?: 0 }.thenBy(collator) { it.title })
}
