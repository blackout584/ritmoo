package com.ritmo.player.ui

import androidx.compose.foundation.border
import android.net.Uri
import androidx.core.graphics.drawable.toBitmap
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage

// ---------------- Fundo animado do player ----------------

/** A capa da música, desfocada e se mexendo devagar, atrás de tudo. */
@Composable
fun AnimatedArtBackground(artUri: Uri?, tint: Color, bottom: Color) {
    // 1.8: três manchas com as cores da capa, passeando devagar
    val palette = rememberArtPalette(artUri, tint)
    val c1 by androidx.compose.animation.animateColorAsState(palette[0], tween(1200), label = "blob1")
    val c2 by androidx.compose.animation.animateColorAsState(palette[1], tween(1200), label = "blob2")
    val c3 by androidx.compose.animation.animateColorAsState(palette[2], tween(1200), label = "blob3")
    val transition = rememberInfiniteTransition(label = "bg")
    val a by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(16_000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val b by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(21_000, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    val c by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(12_000, easing = LinearEasing), RepeatMode.Reverse), label = "c")
    Box(Modifier.fillMaxSize().background(bottom)) {
        androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            fun blob(color: Color, x: Float, y: Float, r: Float) {
                drawCircle(
                    Brush.radialGradient(
                        listOf(color.copy(alpha = 0.75f), color.copy(alpha = 0.25f), Color.Transparent),
                        center = androidx.compose.ui.geometry.Offset(x, y),
                        radius = r,
                    ),
                    radius = r,
                    center = androidx.compose.ui.geometry.Offset(x, y),
                )
            }
            blob(c1, w * (0.1f + 0.5f * a), h * (0.12f + 0.25f * b), w * 0.95f)
            blob(c2, w * (0.95f - 0.55f * b), h * (0.55f + 0.3f * c), w * 1.05f)
            blob(c3, w * (0.3f + 0.4f * c), h * (0.4f + 0.2f * a), w * 0.75f)
        }
        // Escurece um pouco para o texto ficar legível
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.15f), bottom.copy(alpha = 0.9f)))
            )
        )
    }
}

/** Três cores da capa (vibrante, escura e média) para o fundo animado. */
@Composable
fun rememberArtPalette(uri: Uri?, fallback: Color): List<Color> {
    val context = LocalContext.current
    val extracted by androidx.compose.runtime.produceState<List<Color>?>(initialValue = null, uri) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
            runCatching {
                if (uri == null) return@runCatching null
                val request = coil.request.ImageRequest.Builder(context).data(uri).allowHardware(false).size(120).build()
                val result = coil.Coil.imageLoader(context).execute(request) as? coil.request.SuccessResult
                    ?: return@runCatching null
                val bmp = result.drawable.toBitmap()
                val p = androidx.palette.graphics.Palette.from(bmp).generate()
                val dom = p.dominantSwatch?.rgb
                listOfNotNull(
                    p.vibrantSwatch?.rgb ?: p.lightVibrantSwatch?.rgb ?: dom,
                    p.darkVibrantSwatch?.rgb ?: p.darkMutedSwatch?.rgb ?: dom,
                    p.mutedSwatch?.rgb ?: p.lightMutedSwatch?.rgb ?: dom,
                ).map { Color(it) }.takeIf { it.size == 3 }
            }.getOrNull()
        }
    }
    return extracted ?: listOf(fallback, androidx.compose.ui.graphics.lerp(fallback, Color.Black, 0.5f), androidx.compose.ui.graphics.lerp(fallback, Color.White, 0.2f))
}

// ---------------- Letras ----------------

@Composable
fun LyricsPanel(vm: MainViewModel, mediaId: String?, accent: Color, modifier: Modifier = Modifier) {
    val lyrics by vm.lyrics.collectAsStateWithLifecycle()
    val loading by vm.lyricsLoading.collectAsStateWithLifecycle()
    val position by rememberPlaybackPosition(vm)
    val context = LocalContext.current
    var pasting by remember { mutableStateOf(false) }
    var options by remember { mutableStateOf(false) }
    var styling by remember { mutableStateOf(false) }
    val appSettings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val lyricStyle = lyricsStyleOf(appSettings)

    LaunchedEffect(mediaId) { vm.ensureLyrics(mediaId) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            }.getOrNull()
            if (text.isNullOrBlank()) {
                Toast.makeText(context, "Não deu para ler esse arquivo", Toast.LENGTH_SHORT).show()
            } else {
                vm.saveLyrics(text)
            }
        }
    }

    Box(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color.Black.copy(alpha = 0.25f)),
        contentAlignment = Alignment.Center,
    ) {
        val current = lyrics
        when {
            loading -> CircularProgressIndicator(color = accent)
            current == null -> Column(
                Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Sem letra para esta música", fontWeight = FontWeight.SemiBold, color = Color.White)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Adicione um arquivo .lrc (letra com tempo) ou cole a letra.",
                    color = Color.White.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodySmall,
                )
                Spacer(Modifier.height(14.dp))
                OutlinedButton(onClick = { filePicker.launch(arrayOf("*/*")) }) { Text("Escolher arquivo .lrc") }
                TextButton(onClick = { pasting = true }) { Text("Colar letra") }
            }
            current.synced -> SyncedLyrics(current.lines, position, accent, lyricStyle) { vm.seekTo(it) }
            else -> Text(
                current.lines.joinToString("\n") { it.text },
                color = Color.White,
                fontSize = lyricStyle.size.sp,
                lineHeight = (lyricStyle.size * 1.6f).sp,
                fontFamily = lyricStyle.family,
                fontWeight = if (lyricStyle.strong) FontWeight.Black else null,
                textAlign = if (lyricStyle.center) TextAlign.Center else TextAlign.Start,
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            )
        }
        if (current != null) {
            androidx.compose.foundation.layout.Row(Modifier.align(Alignment.BottomEnd)) {
                // Aa: fonte, tamanho, alinhamento e cor da letra
                TextButton(onClick = { styling = true }) {
                    Text(
                        "Aa",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp),
                    )
                }
                TextButton(onClick = { options = true }) { Text("Editar letra", color = Color.White.copy(alpha = 0.7f)) }
            }
        }
    }

    if (styling) LyricsStyleSheet(vm) { styling = false }
    if (options) {
        AlertDialog(
            onDismissRequest = { options = false },
            title = { Text("Letra") },
            text = {
                Column {
                    TextButton(onClick = { options = false; filePicker.launch(arrayOf("*/*")) }) { Text("Trocar por arquivo .lrc") }
                    TextButton(onClick = { options = false; pasting = true }) { Text("Colar outra letra") }
                    if (vm.hasUserLyrics()) {
                        TextButton(onClick = { options = false; vm.removeUserLyrics() }) {
                            Text("Remover a letra que adicionei", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { options = false }) { Text("Fechar") } },
        )
    }

    if (pasting) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pasting = false },
            title = { Text("Colar letra") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("Cole aqui a letra (pode ter tempos [00:12.34])") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp, max = 320.dp),
                )
            },
            confirmButton = {
                TextButton(enabled = text.isNotBlank(), onClick = { vm.saveLyrics(text); pasting = false }) { Text("Salvar") }
            },
            dismissButton = { TextButton(onClick = { pasting = false }) { Text("Cancelar") } },
        )
    }
}

/** Letra com tempo: a linha atual acende e a lista acompanha a música. Toque numa linha para pular. */
@Composable
private fun SyncedLyrics(
    lines: List<com.ritmo.player.data.LyricLine>,
    positionMs: Long,
    accent: Color,
    style: LyricsStyle,
    onSeek: (Long) -> Unit,
) {
    val current = remember(lines, positionMs) {
        lines.indexOfLast { (it.timeMs ?: 0) <= positionMs + 250 }.coerceAtLeast(0)
    }
    val listState = rememberLazyListState()
    LaunchedEffect(current) {
        listState.animateScrollToItem((current - 2).coerceAtLeast(0))
    }
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 24.dp, horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        itemsIndexed(lines) { i, line ->
            val active = i == current
            val color by animateColorAsState(
                when {
                    active -> style.highlight
                    i < current -> Color.White.copy(alpha = 0.35f)
                    else -> Color.White.copy(alpha = 0.55f)
                },
                label = "lyricColor",
            )
            // 1.8: karaokê — na linha atual, as palavras acendem uma a uma
            val karaokeText = if (active && style.karaoke && line.text.isNotBlank()) {
                val start = line.timeMs ?: 0L
                val end = lines.getOrNull(i + 1)?.timeMs?.takeIf { it > start } ?: (start + 4000L)
                // termina de acender um pouco antes da próxima linha
                val span = ((end - start) * 0.9f).coerceAtLeast(400f)
                val frac = ((positionMs + 250 - start) / span).coerceIn(0f, 1f)
                karaokeString(line.text, frac, style.highlight)
            } else null
            Text(
                karaokeText ?: androidx.compose.ui.text.AnnotatedString(line.text.ifBlank { "♪" }),
                color = color,
                fontSize = if (active) (style.size + 4f).sp else style.size.sp,
                fontWeight = if (style.strong) FontWeight.Black else if (active) FontWeight.Bold else FontWeight.Normal,
                fontFamily = style.family,
                textAlign = if (style.center) TextAlign.Center else TextAlign.Start,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { line.timeMs?.let(onSeek) }
                    .padding(vertical = 2.dp),
            )
        }
    }
}


/** Monta a linha com as palavras já cantadas acesas e o resto apagado. */
private fun karaokeString(text: String, frac: Float, lit: Color): androidx.compose.ui.text.AnnotatedString {
    val words = text.split(" ").filter { it.isNotEmpty() }
    val total = words.sumOf { it.length }.coerceAtLeast(1)
    val litChars = frac * total
    return androidx.compose.ui.text.buildAnnotatedString {
        var acc = 0
        words.forEachIndexed { i, w ->
            if (i > 0) append(" ")
            val on = acc + w.length * 0.5f <= litChars
            val c = if (on) lit else Color.White.copy(alpha = 0.4f)
            pushStyle(androidx.compose.ui.text.SpanStyle(color = c))
            append(w)
            pop()
            acc += w.length
        }
    }
}
