package com.ritmo.player.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.os.BatteryManager
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 1.8: celular deitado e carregando, com música tocando → relógio grande com a capa.
 * Tocar na tela fecha (volta a aparecer na próxima vez que deitar o celular).
 */
@Composable
fun ChargerClockHost(vm: MainViewModel) {
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val player by vm.player.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    var charging by remember { mutableStateOf(false) }
    var battery by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (i == null) return
                val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
                val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
                if (level >= 0) battery = level * 100 / scale
            }
        }
        // ACTION_BATTERY_CHANGED é "sticky": já devolve o estado atual
        val sticky = context.registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        receiver.onReceive(context, sticky)
        onDispose { runCatching { context.unregisterReceiver(receiver) } }
    }
    var dismissed by remember(landscape) { mutableStateOf(false) }
    val show = settings.chargerClock && charging && landscape && player.hasMedia && !dismissed

    // Mantém a tela acesa enquanto o relógio aparece
    DisposableEffect(show) {
        val window = (context as? ComponentActivity)?.window
        if (show) window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    AnimatedVisibility(show, enter = fadeIn(), exit = fadeOut()) {
        ChargerClockScreen(vm, player, battery) { dismissed = true }
    }
}

@Composable
private fun ChargerClockScreen(vm: MainViewModel, s: PlayerUiState, battery: Int, onDismiss: () -> Unit) {
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(5_000)
        }
    }
    val time = remember(now) { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(now)) }
    val date = remember(now) {
        SimpleDateFormat("EEEE, d 'de' MMMM", Locale("pt", "BR")).format(Date(now))
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss)
            .padding(horizontal = 40.dp, vertical = 24.dp),
        contentAlignment = Alignment.Center,
    ) {
        androidx.compose.runtime.CompositionLocalProvider(androidx.compose.material3.LocalContentColor provides Color.White) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ArtImage(
                s.artUri,
                Modifier.fillMaxHeight(0.8f).aspectRatio(1f).clip(RoundedCornerShape(20.dp)),
                corner = 20.dp,
            )
            Spacer(Modifier.width(36.dp))
            Column {
                Text(time, color = Color.White, fontSize = 96.sp, fontWeight = FontWeight.Light, lineHeight = 96.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(date, color = Color.White.copy(alpha = 0.6f), fontSize = 16.sp)
                    Spacer(Modifier.width(10.dp))
                    Icon(Icons.Rounded.BatteryChargingFull, null, Modifier.size(18.dp), tint = Color(0xFF97C459))
                    Text("$battery%", color = Color.White.copy(alpha = 0.6f), fontSize = 16.sp)
                }
                Spacer(Modifier.height(20.dp))
                Text(s.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(s.artist, color = Color.White.copy(alpha = 0.6f), fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    BouncyIconButton(onClick = { vm.previous() }) { Icon(Icons.Rounded.SkipPrevious, "Anterior", tint = Color.White) }
                    BouncyIconButton(onClick = { vm.togglePlay() }) { AnimatedPlayIcon(s.isPlaying, Modifier.size(30.dp)) }
                    BouncyIconButton(onClick = { vm.next() }) { Icon(Icons.Rounded.SkipNext, "Próxima", tint = Color.White) }
                }
            }
        }
        }
    }
}
