package com.ritmo.player.data

import android.content.Context
import org.json.JSONArray

data class ResumeState(val ids: List<Long>, val index: Int, val positionMs: Long)

/** Lembra a fila, a música e o ponto onde você parou. */
object ResumeStore {
    private fun prefs(context: Context) = context.getSharedPreferences("resume", Context.MODE_PRIVATE)

    fun save(context: Context, ids: List<Long>, index: Int, positionMs: Long) {
        if (ids.isEmpty()) return
        prefs(context).edit()
            .putString("ids", JSONArray(ids).toString())
            .putInt("index", index)
            .putLong("pos", positionMs)
            .apply()
    }

    fun load(context: Context): ResumeState? = runCatching {
        val p = prefs(context)
        val arr = JSONArray(p.getString("ids", null) ?: return@runCatching null)
        val ids = (0 until arr.length()).map { arr.getLong(it) }
        if (ids.isEmpty()) null else ResumeState(ids, p.getInt("index", 0), p.getLong("pos", 0))
    }.getOrNull()
}
