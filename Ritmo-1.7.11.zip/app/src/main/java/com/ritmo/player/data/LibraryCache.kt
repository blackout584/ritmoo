package com.ritmo.player.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Guarda a lista de músicas para o app abrir na hora, sem reler o celular. */
object LibraryCache {
    private fun file(context: Context) = File(context.filesDir, "library.json")

    suspend fun save(context: Context, songs: List<Song>) = withContext(Dispatchers.IO) {
        runCatching {
            val arr = JSONArray()
            songs.forEach { s ->
                arr.put(JSONObject().apply {
                    put("id", s.id); put("t", s.title); put("ar", s.artist); put("al", s.album)
                    put("ai", s.albumId); put("d", s.durationMs); put("tr", s.trackNumber)
                    put("fp", s.folderPath); put("fn", s.folderName); put("u", s.uri.toString())
                    put("da", s.dateAdded); put("p", s.path)
                })
            }
            file(context).writeText(arr.toString())
        }
    }

    fun loadBlocking(context: Context): List<Song> = runCatching {
        val f = file(context)
        if (!f.exists()) return@runCatching emptyList()
        val arr = JSONArray(f.readText())
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Song(
                id = o.getLong("id"), title = o.getString("t"), artist = o.getString("ar"),
                album = o.getString("al"), albumId = o.getLong("ai"), durationMs = o.getLong("d"),
                trackNumber = o.getInt("tr"), folderPath = o.getString("fp"), folderName = o.getString("fn"),
                uri = Uri.parse(o.getString("u")), dateAdded = o.optLong("da"), path = o.optString("p"),
            )
        }
    }.getOrDefault(emptyList())

    suspend fun load(context: Context): List<Song> = withContext(Dispatchers.IO) { loadBlocking(context) }
}
