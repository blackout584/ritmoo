package com.ritmo.player.data

/**
 * 1.8: separa artistas que vêm juntos no mesmo nome
 * ("2ZDinizz, F.B.O & Hyperanhas feat. Fulano" → 4 artistas).
 * Só muda como o Ritmo mostra; o arquivo da música fica igual.
 */
private val separators = Regex(
    """\s*(?:,|;|\s&\s|\s+(?:feat|ft|featuring|part|participação\s+de|with|com)\.?\s+)\s*""",
    RegexOption.IGNORE_CASE,
)

private val cache = java.util.concurrent.ConcurrentHashMap<String, List<String>>()

fun artistNames(raw: String): List<String> {
    if (raw.isBlank()) return listOf(raw)
    return cache.getOrPut(raw) {
        val cleaned = raw.replace("(", " ").replace(")", " ").replace("[", " ").replace("]", " ")
        cleaned.split(separators)
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinctBy { it.lowercase() }
            .ifEmpty { listOf(raw) }
    }
}

/** Artistas da música, separados ou não (de acordo com a configuração). */
fun Song.artistsFor(split: Boolean): List<String> = if (split) artistNames(artist) else listOf(artist)

/** A música é desse artista? */
fun Song.hasArtist(name: String, split: Boolean): Boolean =
    if (split) artistNames(artist).any { it.equals(name, ignoreCase = true) } else artist == name

/** Agrupa as músicas por artista; com [split], uma música entra em cada artista dela. */
fun List<Song>.groupByArtist(split: Boolean): Map<String, List<Song>> {
    if (!split) return groupBy { it.artist }
    val out = LinkedHashMap<String, MutableList<Song>>()
    val canonical = HashMap<String, String>() // mesmo nome com maiúsculas diferentes vira um só
    for (s in this) {
        for (n in artistNames(s.artist)) {
            val key = canonical.getOrPut(n.lowercase()) { n }
            out.getOrPut(key) { mutableListOf() }.add(s)
        }
    }
    return out
}
