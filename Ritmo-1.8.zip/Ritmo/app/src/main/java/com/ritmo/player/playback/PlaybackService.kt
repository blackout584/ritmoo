package com.ritmo.player.playback

import android.app.PendingIntent
import android.content.Intent
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import com.ritmo.player.MainActivity
import com.ritmo.player.data.LibraryCache
import com.ritmo.player.data.ResumeStore
import com.ritmo.player.data.SettingsStore
import com.ritmo.player.data.SongEditsStore
import com.ritmo.player.data.toMediaItem
import kotlin.math.min

/**
 * Serviço que toca a música em segundo plano.
 * Gera a notificação, os controles da tela de bloqueio e atualiza o widget.
 */
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private val handler = Handler(Looper.getMainLooper())
    private val settings by lazy { SettingsStore.get(this) }

    /** Transição suave: abaixa o volume no fim da música e sobe no começo da próxima. */
    private val fadeTick = object : Runnable {
        override fun run() {
            val p = mediaSession?.player ?: return
            val fadeMs = settings.settings.value.fadeSeconds * 1000L
            if (fadeMs <= 0) {
                if (p.volume != 1f) p.volume = 1f
            } else {
                val pos = p.currentPosition
                val dur = p.duration
                var v = if (pos < fadeMs) pos.toFloat() / fadeMs else 1f
                if (dur > 0 && dur - pos < fadeMs && p.repeatMode != Player.REPEAT_MODE_ONE) {
                    v = min(v, (dur - pos).toFloat() / fadeMs)
                }
                p.volume = v.coerceIn(0f, 1f)
            }
            if (p.isPlaying) handler.postDelayed(this, 100)
        }
    }

    @OptIn(UnstableApi::class)
    override fun onCreate() {
        super.onCreate()

        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true,
            )
            .setHandleAudioBecomingNoisy(true) // pausa ao tirar o fone
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()

        // Sessão de áudio própria para ligar o equalizador.
        val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        val sessionId = audioManager.generateAudioSessionId()
        player.setAudioSessionId(sessionId)
        AudioEffects.attach(this, sessionId)
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                AudioEffects.attach(this@PlaybackService, audioSessionId)
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                handler.removeCallbacks(fadeTick)
                if (isPlaying) handler.post(fadeTick) else if (player.volume != 1f) player.volume = 1f
            }

            override fun onEvents(player: Player, events: Player.Events) {
                if (events.containsAny(
                        Player.EVENT_MEDIA_METADATA_CHANGED,
                        Player.EVENT_IS_PLAYING_CHANGED,
                        Player.EVENT_MEDIA_ITEM_TRANSITION,
                    )
                ) WidgetUpdater.update(this@PlaybackService, player)
            }
        })

        // 1.8: equalizador por fone — percebe quando conecta/desconecta
        audioManager.registerAudioDeviceCallback(deviceCallback, handler)
        checkOutput()

        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(openApp)
            .setCallback(object : MediaSession.Callback {
                override fun onAddMediaItems(
                    mediaSession: MediaSession,
                    controller: MediaSession.ControllerInfo,
                    mediaItems: MutableList<MediaItem>,
                ): ListenableFuture<MutableList<MediaItem>> {
                    val resolved = mediaItems.map { item ->
                        val uri = item.requestMetadata.mediaUri ?: item.localConfiguration?.uri
                        if (uri != null) item.buildUpon().setUri(uri).build() else item
                    }.toMutableList()
                    return Futures.immediateFuture(resolved)
                }

                /** Ao tocar "play" no widget ou no fone com o app fechado: volta a última fila. */
                override fun onPlaybackResumption(
                    mediaSession: MediaSession,
                    controller: MediaSession.ControllerInfo,
                ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
                    val future = SettableFuture.create<MediaSession.MediaItemsWithStartPosition>()
                    Thread {
                        val ctx = this@PlaybackService
                        val state = ResumeStore.load(ctx)
                        val songs = SongEditsStore(ctx).apply(LibraryCache.loadBlocking(ctx)).associateBy { it.id }
                        val items = state?.ids?.mapNotNull { songs[it]?.toMediaItem() }.orEmpty()
                        if (state == null || items.isEmpty()) {
                            future.setException(IllegalStateException("Nada para continuar"))
                        } else {
                            future.set(
                                MediaSession.MediaItemsWithStartPosition(
                                    items, state.index.coerceIn(0, items.size - 1), state.positionMs,
                                )
                            )
                        }
                    }.start()
                    return future
                }
            })
            .build()
    }

    private val deviceCallback = object : android.media.AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out android.media.AudioDeviceInfo>?) = checkOutput()
        override fun onAudioDevicesRemoved(removedDevices: Array<out android.media.AudioDeviceInfo>?) = checkOutput()
    }

    /** Descobre por onde o som está saindo e troca o ajuste do equalizador se precisar. */
    private fun checkOutput() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val devices = runCatching { am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList() }.getOrDefault(emptyList())
        val bt = devices.firstOrNull {
            it.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                (android.os.Build.VERSION.SDK_INT >= 31 && it.type == android.media.AudioDeviceInfo.TYPE_BLE_HEADSET)
        }
        val wired = devices.firstOrNull {
            it.type == android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                it.type == android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                it.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET
        }
        val (key, label) = when {
            bt != null -> {
                val name = bt.productName?.toString()?.takeIf { it.isNotBlank() } ?: "Fone Bluetooth"
                "bt:$name" to name
            }
            wired != null -> "wired" to "Fone com fio"
            else -> "speaker" to "Alto-falante"
        }
        val changed = AudioEffects.onOutputChanged(this, key, label, settings.settings.value.eqPerDevice)
        if (changed && AudioEffects.state.value.enabled) {
            android.widget.Toast.makeText(this, "$label: usando o ajuste dele", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(fadeTick)
        runCatching { (getSystemService(AUDIO_SERVICE) as AudioManager).unregisterAudioDeviceCallback(deviceCallback) }
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        AudioEffects.release()
        super.onDestroy()
    }
}
