package com.ritmo.player.ui

import androidx.compose.foundation.border
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage

// ---------------- Fundo animado do player ----------------

/** A capa da música, desfocada e se mexendo devagar, atrás de tudo. */
@Composable
fun AnimatedArtBackground(artUri: Uri?, tint: Color, bottom: Color) {
    val transition = rememberInfiniteTransition(label = "bg")
    val scale by transition.animateFloat(
        1.25f, 1.5f,
        infiniteRepeatable(tween(14_000, easing = LinearEasing), RepeatMode.Reverse),
        label = "bgScale",
    )
    val rotation by transition.animateFloat(
        -8f, 8f,
        infiniteRepeatable(tween(19_000, easing = LinearEasing), RepeatMode.Reverse),
        label = "bgRotation",
    )
    val canBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    Box(Modifier.fillMaxSize().background(bottom)) {
        Crossfade(targetState = artUri, animationSpec = tween(900), label = "bgArt") { uri ->
            if (uri != null) {
                AsyncImage(
                    model = uri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            rotationZ = rotation
                        }
                        .blur(80.dp),
                )
            }
        }
        // Escurece para o texto ficar legível (mais forte onde não dá para desfocar)
        val top = if (canBlur) 0.45f else 0.78f
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(tint.copy(alpha = top), bottom.copy(alpha = 0.94f)))
            )
        )
    }
}

// ---------------- Letras ----------------

@Composable
fun LyricsPanel(vm: MainViewModel, mediaId: String?, accent: Color, modifier: Modifier = Modifier) {
    val lyrics by vm.lyrics.collectAsStateWithLifecycle()
    val loading by vm.lyricsLoading.collectAsStateWithLifecycle()
    val position by rememberPlaybackPosition(vm)
    val context = LocalContext.current
    var pasting by remember { mutableStateOf(false) }
    var options by remember { mutableStateOf(false) }
    var styling by remember { mutableStateOf(false) }
    val appSettings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val lyricStyle = lyricsStyleOf(appSettings)

    LaunchedEffect(mediaId) { vm.ensureLyrics(mediaId) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            }.getOrNull()
            if (text.isNullOrBlank()) {
                Toast.makeText(context, "Não deu para ler esse arquivo", Toast.LENGTH_SHORT).show()
            } else {
                vm.saveLyrics(text)
            }
        }
    }

    Box(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color.Black.copy(alpha = 0.25f)),
        contentAlignment = Alignment.Center,
    ) {
        val current = lyrics
        when {
            loading -> CircularProgressIndicator(color = accent)
            current == null -> Column(
                Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Sem letra para esta música", fontWeight = FontWeight.SemiBold, color = Color.White)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Adicione um arquivo .lrc (letra com tempo) ou cole a letra.",
                    color = Color.White.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodySmall,
                )
                Spacer(Modifier.height(14.dp))
                OutlinedButton(onClick = { filePicker.launch(arrayOf("*/*")) }) { Text("Escolher arquivo .lrc") }
                TextButton(onClick = { pasting = true }) { Text("Colar letra") }
            }
            current.synced -> SyncedLyrics(current.lines, position, accent, lyricStyle) { vm.seekTo(it) }
            else -> Text(
                current.lines.joinToString("\n") { it.text },
                color = Color.White,
                fontSize = lyricStyle.size.sp,
                lineHeight = (lyricStyle.size * 1.6f).sp,
                fontFamily = lyricStyle.family,
                fontWeight = if (lyricStyle.strong) FontWeight.Black else null,
                textAlign = if (lyricStyle.center) TextAlign.Center else TextAlign.Start,
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            )
        }
        if (current != null) {
            androidx.compose.foundation.layout.Row(Modifier.align(Alignment.BottomEnd)) {
                // Aa: fonte, tamanho, alinhamento e cor da letra
                TextButton(onClick = { styling = true }) {
                    Text(
                        "Aa",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp),
                    )
                }
                TextButton(onClick = { options = true }) { Text("Editar letra", color = Color.White.copy(alpha = 0.7f)) }
            }
        }
    }

    if (styling) LyricsStyleSheet(vm) { styling = false }
    if (options) {
        AlertDialog(
            onDismissRequest = { options = false },
            title = { Text("Letra") },
            text = {
                Column {
                    TextButton(onClick = { options = false; filePicker.launch(arrayOf("*/*")) }) { Text("Trocar por arquivo .lrc") }
                    TextButton(onClick = { options = false; pasting = true }) { Text("Colar outra letra") }
                    if (vm.hasUserLyrics()) {
                        TextButton(onClick = { options = false; vm.removeUserLyrics() }) {
                            Text("Remover a letra que adicionei", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { options = false }) { Text("Fechar") } },
        )
    }

    if (pasting) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pasting = false },
            title = { Text("Colar letra") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("Cole aqui a letra (pode ter tempos [00:12.34])") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp, max = 320.dp),
                )
            },
            confirmButton = {
                TextButton(enabled = text.isNotBlank(), onClick = { vm.saveLyrics(text); pasting = false }) { Text("Salvar") }
            },
            dismissButton = { TextButton(onClick = { pasting = false }) { Text("Cancelar") } },
        )
    }
}

/** Letra com tempo: a linha atual acende e a lista acompanha a música. Toque numa linha para pular. */
@Composable
private fun SyncedLyrics(
    lines: List<com.ritmo.player.data.LyricLine>,
    positionMs: Long,
    accent: Color,
    style: LyricsStyle,
    onSeek: (Long) -> Unit,
) {
    val current = remember(lines, positionMs) {
        lines.indexOfLast { (it.timeMs ?: 0) <= positionMs + 250 }.coerceAtLeast(0)
    }
    val listState = rememberLazyListState()
    LaunchedEffect(current) {
        listState.animateScrollToItem((current - 2).coerceAtLeast(0))
    }
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 24.dp, horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        itemsIndexed(lines) { i, line ->
            val active = i == current
            val color by animateColorAsState(
                when {
                    active -> style.highlight
                    i < current -> Color.White.copy(alpha = 0.35f)
                    else -> Color.White.copy(alpha = 0.55f)
                },
                label = "lyricColor",
            )
            Text(
                line.text.ifBlank { "♪" },
                color = color,
                fontSize = if (active) (style.size + 4f).sp else style.size.sp,
                fontWeight = if (style.strong) FontWeight.Black else if (active) FontWeight.Bold else FontWeight.Normal,
                fontFamily = style.family,
                textAlign = if (style.center) TextAlign.Center else TextAlign.Start,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { line.timeMs?.let(onSeek) }
                    .padding(vertical = 2.dp),
            )
        }
    }
}
