@file:OptIn(ExperimentalMaterial3Api::class)

package com.ritmo.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.data.AppSettings
import com.ritmo.player.data.FontStyleId
import com.ritmo.player.ui.theme.fontFamilyFor

/** Cores da linha que está tocando. */
val lyricsColors = listOf(
    Color.White,
    Color(0xFFED93B1),
    Color(0xFF85B7EB),
    Color(0xFFFAC775),
    Color(0xFF5DCAA5),
)

/** Fonte e peso da letra conforme a escolha (null = fonte do app). */
data class LyricsStyle(
    val family: FontFamily?,
    val strong: Boolean,
    val size: Float,
    val center: Boolean,
    val highlight: Color,
    val karaoke: Boolean = false,
)

fun lyricsStyleOf(s: AppSettings): LyricsStyle {
    val family = when (s.lyricsFont) {
        "APP" -> null
        "STRONG" -> FontFamily.SansSerif
        else -> runCatching { FontStyleId.valueOf(s.lyricsFont) }.getOrNull()?.let { fontFamilyFor(it) ?: FontFamily.Default }
    }
    return LyricsStyle(
        family = family,
        strong = s.lyricsFont == "STRONG",
        size = s.lyricsSize.coerceIn(13f, 28f),
        center = s.lyricsCenter,
        highlight = lyricsColors.getOrElse(s.lyricsColor) { Color.White },
        karaoke = s.karaoke,
    )
}

private val fontChoices: List<Pair<String, String>> =
    listOf("APP" to "Do app") +
        FontStyleId.entries.filter { it != FontStyleId.DEFAULT }.map { it.name to it.label } +
        listOf("STRONG" to "Forte")

/** Janela "Estilo da letra": fonte, tamanho, alinhamento e cor da linha atual. */
@Composable
fun LyricsStyleSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    var size by remember(settings.lyricsSize) { mutableFloatStateOf(settings.lyricsSize) }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(start = 20.dp, end = 20.dp, bottom = 28.dp)) {
            Text("Estilo da letra", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            Label("Fonte")
            fontChoices.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    row.forEach { (id, label) ->
                        val sel = settings.lyricsFont == id
                        val family = when (id) {
                            "APP" -> null
                            "STRONG" -> FontFamily.SansSerif
                            else -> fontFamilyFor(FontStyleId.valueOf(id))
                        }
                        Column(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
                                .border(if (sel) 2.dp else 0.dp, if (sel) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(10.dp))
                                .clickable { vm.settingsStore.update { it.copy(lyricsFont = id) } }
                                .padding(vertical = 8.dp, horizontal = 2.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text(
                                "Aa",
                                fontFamily = family,
                                fontWeight = if (id == "STRONG") FontWeight.Black else null,
                                fontSize = 20.sp,
                                maxLines = 1,
                            )
                            Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    repeat(4 - row.size) { Box(Modifier.weight(1f)) }
                }
            }

            Label("Tamanho")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("A", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = size,
                    onValueChange = { size = it },
                    onValueChangeFinished = { vm.settingsStore.update { it.copy(lyricsSize = size) } },
                    valueRange = 13f..28f,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                )
                Text("A", style = MaterialTheme.typography.titleLarge)
            }

            Label("Alinhamento")
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(50))
                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    .padding(3.dp)
            ) {
                listOf(false to "Esquerda", true to "Centro").forEach { (center, label) ->
                    val sel = settings.lyricsCenter == center
                    Text(
                        label,
                        textAlign = TextAlign.Center,
                        color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (sel) FontWeight.Bold else null,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(50))
                            .background(if (sel) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clickable { vm.settingsStore.update { it.copy(lyricsCenter = center) } }
                            .padding(vertical = 8.dp),
                    )
                }
            }

            Label("Cor da linha atual")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                lyricsColors.forEachIndexed { i, c ->
                    val sel = settings.lyricsColor == i
                    Box(
                        Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(c)
                            .border(if (sel) 3.dp else 0.dp, if (sel) MaterialTheme.colorScheme.primary else Color.Transparent, CircleShape)
                            .clickable { vm.settingsStore.update { it.copy(lyricsColor = i) } },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (sel) Icon(Icons.Rounded.Check, null, Modifier.size(18.dp), tint = Color.Black)
                    }
                }
            }

            // 1.8: palavra por palavra
            Row(
                Modifier.fillMaxWidth().padding(top = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                    Text("Karaokê", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "Cada palavra acende na hora em que é cantada",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                androidx.compose.material3.Switch(
                    checked = settings.karaoke,
                    onCheckedChange = { on -> vm.settingsStore.update { it.copy(karaoke = on) } },
                )
            }
        }
    }
}

@Composable
private fun Label(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 14.dp, bottom = 6.dp),
    )
}
