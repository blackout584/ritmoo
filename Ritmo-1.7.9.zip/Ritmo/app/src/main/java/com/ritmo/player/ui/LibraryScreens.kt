@file:OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.ritmo.player.ui

import androidx.compose.foundation.border
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.foundation.combinedClickable
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.zIndex
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.unit.lerp
import com.ritmo.player.data.sortedFor
import kotlinx.coroutines.launch
import kotlin.math.abs
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.data.FAVORITES_ID
import com.ritmo.player.data.Song
import com.ritmo.player.data.SongSort

sealed interface Detail {
    data class Album(val albumId: Long, val name: String) : Detail
    data class Artist(val name: String) : Detail
    data class Folder(val path: String, val name: String) : Detail
    data class PlaylistDetail(val id: Long) : Detail
    data class Smart(val kind: SmartKind) : Detail
    data class Recap(val month: String) : Detail
    data object Duplicates : Detail
}

private data class AlbumInfo(val id: Long, val name: String, val artist: String, val artUri: Uri, val count: Int)

// ---------------- Tela principal ----------------

/** Páginas que abrem pelo menu lateral ou pelos cartões. */
enum class Page { SETTINGS, THEMES, EQUALIZER, PLAYLISTS, FOR_YOU, RECENT, UPDATE, BACKUP, RECAPS }

@Composable
fun MainScreen(
    vm: MainViewModel,
    onOpen: (Detail) -> Unit,
    onOpenPage: (Page) -> Unit,
    onMenu: () -> Unit,
) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    // Abas na ordem escolhida (segurar e arrastar), sem as escondidas
    val tabs = remember(settings.tabOrder, settings.hiddenTabs) {
        settings.tabOrder.filterNot { it in settings.hiddenTabs }.ifEmpty { listOf("songs") }
    }
    val youtubePage = tabs.indexOf("youtube")
    val pagerState = rememberPagerState(pageCount = { tabs.size })
    val pageState = rememberSaveableStateHolder()
    val scope = rememberCoroutineScope()

    // Cartões somem ao rolar para baixo e voltam quando você puxa no começo da lista
    var cardsVisible by rememberSaveable { mutableStateOf(true) }
    val collapseOnScroll = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < -6f) cardsVisible = false
                return Offset.Zero
            }

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                // Sobrou puxão para cima = a lista já está no começo
                if (available.y > 0f) cardsVisible = true
                return Offset.Zero
            }
        }
    }
    val showCards = cardsVisible && pagerState.currentPage != youtubePage
    // Avisa o app quando a aba YouTube está aberta, para esconder o mini player
    LaunchedEffect(pagerState.currentPage, query) {
        vm.setOnYouTube(pagerState.currentPage == youtubePage && query.isBlank())
    }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { vm.setOnYouTube(false) } }

    Column(Modifier.fillMaxSize()) {
        // Topo: menu + busca geral
        Row(
            Modifier.fillMaxWidth().padding(start = 4.dp, end = 14.dp, top = 4.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onMenu) { Icon(Icons.Rounded.Tune, "Menu") }
            Row(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(28.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 14.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Search, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                androidx.compose.foundation.text.BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary),
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp, vertical = 9.dp),
                    decorationBox = { inner ->
                        if (query.isEmpty()) {
                            Text(
                                "Buscar músicas, playlists e artistas",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        inner()
                    },
                )
                if (query.isNotEmpty()) {
                    Icon(
                        Icons.Rounded.Close, "Limpar",
                        modifier = Modifier.clip(CircleShape).clickable { query = "" }.padding(4.dp),
                    )
                }
            }
        }

        if (query.isNotBlank()) {
            SearchResults(vm, query, onOpen)
            return@Column
        }

        UpdateCard(vm, compact = true)
        AnimatedVisibility(
            visible = showCards,
            enter = expandVertically(expandFrom = Alignment.Top, animationSpec = tween(300)) + fadeIn(tween(300)),
            exit = shrinkVertically(shrinkTowards = Alignment.Top, animationSpec = tween(300)) + fadeOut(tween(200)),
        ) {
            ShortcutCards(vm, onOpen, onOpenPage)
        }

        // Abas em pílula (segure e arraste para mudar a ordem)
        TabPills(
            tabs = tabs,
            current = pagerState.currentPage.coerceIn(0, (tabs.size - 1).coerceAtLeast(0)),
            onSelect = { i -> scope.launch { pagerState.animateScrollToPage(i) } },
            onReorder = { newVisible ->
                val currentId = tabs.getOrNull(pagerState.currentPage)
                val hidden = settings.tabOrder.filter { it in settings.hiddenTabs }
                vm.settingsStore.update { it.copy(tabOrder = newVisible + hidden) }
                val newIndex = newVisible.indexOf(currentId)
                if (newIndex >= 0) scope.launch { pagerState.scrollToPage(newIndex) }
            },
            hidden = settings.tabOrder.filter { it in settings.hiddenTabs },
            onHide = { id -> vm.hideTabWithUndo(id) },
            onShow = { id -> vm.showTab(id) },
            onOrganize = {
                vm.requestPersonalizeTab(5)
                onOpenPage(Page.THEMES)
            },
        )

        when {
            loading && songs.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            else -> HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize().nestedScroll(collapseOnScroll),
                key = { tabs.getOrElse(it) { "x$it" } },
                // Na aba YouTube o arrastar é do site, então o deslizar entre abas fica desligado
                userScrollEnabled = pagerState.currentPage != youtubePage,
            ) { page ->
                val id = tabs.getOrElse(page) { "songs" }
                pageState.SaveableStateProvider(key = "page_$id") {
                    when (id) {
                        "home" -> ForYouContent(vm, onOpen)
                        "songs" -> if (songs.isEmpty()) {
                            EmptyMessage("Nenhuma música encontrada no aparelho.\nCopie arquivos de áudio para o celular.")
                        } else SongsTab(songs, vm)
                        "youtube" -> YouTubeScreen()
                        "artists" -> ArtistsTab(songs, vm, onOpen)
                        "albums" -> AlbumsTab(songs, vm, onOpen)
                        else -> FoldersTab(songs, vm, onOpen)
                    }
                }
            }
        }
    }
}

/** Os três cartões: Favoritas, Playlists e Recentes (fundo com a capa da última música). */
@Composable
private fun ShortcutCards(vm: MainViewModel, onOpen: (Detail) -> Unit, onOpenPage: (Page) -> Unit) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    val playlists by vm.playlistStore.playlists.collectAsStateWithLifecycle()
    val stats by vm.statsStore.stats.collectAsStateWithLifecycle()
    val byId = remember(songs) { songs.associateBy { it.id } }
    val favArt = remember(byId, playlists) {
        playlists.firstOrNull { it.id == FAVORITES_ID }?.songIds?.lastOrNull()?.let { byId[it]?.artUri }
    }
    val listArt = remember(byId, playlists) {
        playlists.firstOrNull { it.id != FAVORITES_ID && it.songIds.isNotEmpty() }?.songIds?.firstOrNull()?.let { byId[it]?.artUri }
    }
    val recentArt = remember(byId, stats) {
        stats.maxByOrNull { it.value.lastPlayed }?.key?.let { byId[it]?.artUri }
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        ShortcutCard("Favoritas", Icons.Rounded.Favorite, favArt, Color(0xFF3A3A3A), Modifier.weight(1f)) {
            onOpen(Detail.PlaylistDetail(FAVORITES_ID))
        }
        ShortcutCard("Playlists", Icons.Rounded.Album, listArt, Color(0xFF2F5D7C), Modifier.weight(1f)) {
            onOpenPage(Page.PLAYLISTS)
        }
        ShortcutCard("Recentes", Icons.Rounded.Schedule, recentArt, Color(0xFF6B5BC7), Modifier.weight(1f)) {
            onOpenPage(Page.RECENT)
        }
    }
}

@Composable
private fun ShortcutCard(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    art: Uri?,
    color: Color,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    Box(
        modifier
            .height(46.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(color)
            .clickable(onClick = onClick),
    ) {
        if (art != null) {
            coil.compose.AsyncImage(
                model = art,
                contentDescription = null,
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
        Box(
            Modifier.fillMaxSize().background(
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    listOf(Color.Black.copy(alpha = 0.45f), Color.Black.copy(alpha = 0.6f))
                )
            )
        )
        Row(
            Modifier.align(Alignment.Center).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(icon, null, Modifier.size(18.dp), tint = Color.White)
            Text(
                label,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                modifier = Modifier.padding(start = 5.dp),
            )
        }
    }
}

/** Linha "Reprodução aleatória" usada nas abas Artistas, Álbuns e Pastas. */
@Composable
private fun ShuffleHeader(vm: MainViewModel, songs: List<Song>, subtitle: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(24.dp))
            .clickable(enabled = songs.isNotEmpty()) { vm.shuffleAll(songs) }
            .padding(4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.onSurface),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.PlayArrow, null, tint = MaterialTheme.colorScheme.surfaceContainerLow)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("Reprodução aleatória", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Quadradinho da grade (Artistas e Álbuns): capa, nome e detalhe. */
@Composable
private fun GridTile(art: Uri?, round: Boolean, title: String, subtitle: String, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        ArtImage(
            art,
            Modifier.fillMaxWidth().aspectRatio(1f).clip(if (round) CircleShape else RoundedCornerShape(10.dp)),
            corner = if (round) 999.dp else 10.dp,
        )
        Text(
            title,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.SemiBold,
            textAlign = if (round) androidx.compose.ui.text.style.TextAlign.Center else null,
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
        )
        Text(
            subtitle,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = if (round) androidx.compose.ui.text.style.TextAlign.Center else null,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

/** Linha de lista com capa, título, subtítulo e seta ›. */
@Composable
private fun ChevronRow(art: Uri?, round: Boolean, title: String, subtitle: String, onClick: () -> Unit) {
    ListItem(
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        modifier = Modifier.clickable(onClick = onClick),
        leadingContent = {
            ArtImage(art, Modifier.size(44.dp).clip(if (round) CircleShape else RoundedCornerShape(8.dp)), corner = if (round) 22.dp else 8.dp)
        },
        headlineContent = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge) },
        supportingContent = { Text(subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall) },
        trailingContent = { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null) },
    )
}

@Composable
private fun SongsTab(songs: List<Song>, vm: MainViewModel) {
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val ratings by vm.ratingsStore.ratings.collectAsStateWithLifecycle()
    val shown = remember(songs, settings.songSort, ratings) { songs.sortedFor(settings.songSort, ratings) }
    SongList(
        shown, vm,
        sortControl = { SortButton(settings.songSort) { vm.setSongSort(it) } },
        letterOf = when (settings.songSort) {
            SongSort.TITLE_ASC, SongSort.TITLE_DESC -> { s: Song -> firstLetter(s.title) }
            SongSort.ARTIST -> { s: Song -> firstLetter(s.artist) }
            else -> null
        },
    )
}

@Composable
private fun AlbumsTab(songs: List<Song>, vm: MainViewModel, onOpen: (Detail) -> Unit) {
    val albums = remember(songs) {
        songs.groupBy { it.albumId }.map { (id, list) ->
            val first = list.first()
            AlbumInfo(id, first.album, first.artist, first.artUri, list.size)
        }.sortedBy { it.name.lowercase() }
    }
    androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
            ShuffleHeader(vm, songs, "${albums.size} álbuns")
        }
        items(albums.size, key = { albums[it].id }) { i ->
            val a = albums[i]
            GridTile(a.artUri, round = false, title = a.name, subtitle = a.artist) { onOpen(Detail.Album(a.id, a.name)) }
        }
    }
}

@Composable
private fun ArtistsTab(songs: List<Song>, vm: MainViewModel, onOpen: (Detail) -> Unit) {
    val artists = remember(songs) {
        songs.groupBy { it.artist }.map { (name, list) -> Triple(name, list.size, list.first().artUri) }
            .sortedBy { it.first.lowercase() }
    }
    androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
            ShuffleHeader(vm, songs, "${artists.size} artistas")
        }
        items(artists.size, key = { artists[it].first }) { i ->
            val (name, count, art) = artists[i]
            GridTile(art, round = true, title = name, subtitle = "$count músicas") { onOpen(Detail.Artist(name)) }
        }
    }
}

@Composable
private fun FoldersTab(songs: List<Song>, vm: MainViewModel, onOpen: (Detail) -> Unit) {
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val folders = remember(songs) {
        songs.groupBy { it.folderPath }.map { (path, list) -> Triple(path, list.first().folderName, list.size) }
            .sortedBy { it.second.lowercase() }
    }
    // Pastas escondidas (nome e quantidade vêm da biblioteca completa)
    val hiddenFolders = remember(settings.hiddenFolders, songs) {
        vm.allFolders().filter { it.first in settings.hiddenFolders }
    }
    var menuFolder by remember { mutableStateOf<Triple<String, String, Int>?>(null) }
    var showHidden by rememberSaveable { mutableStateOf(false) }
    val haptics = androidx.compose.ui.platform.LocalHapticFeedback.current

    LazyColumn(Modifier.fillMaxSize()) {
        item { ShuffleHeader(vm, songs, "${folders.size} pastas") }
        items(folders, key = { it.first }) { folder ->
            val (path, name, count) = folder
            ListItem(
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                modifier = Modifier.combinedClickable(
                    onClick = { onOpen(Detail.Folder(path, name)) },
                    onLongClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        menuFolder = folder
                    },
                ),
                leadingContent = {
                    Box(
                        Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Rounded.Folder, null) }
                },
                headlineContent = { Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge) },
                supportingContent = { Text("$count músicas • $path", maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall) },
                trailingContent = { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null) },
            )
        }
        if (hiddenFolders.isNotEmpty()) {
            item(key = "hidden_header") {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { showHidden = !showHidden }
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.VisibilityOff, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        "Pastas ocultas (${hiddenFolders.size})",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f).padding(start = 12.dp),
                    )
                    Icon(
                        if (showHidden) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                        null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            if (showHidden) {
                items(hiddenFolders, key = { "h_" + it.first }) { (path, name, count) ->
                    Row(
                        Modifier.fillMaxWidth().padding(start = 52.dp, end = 8.dp, top = 2.dp, bottom = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("$count músicas", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        TextButton(onClick = { vm.setFolderHidden(path, false) }) { Text("Mostrar") }
                    }
                }
            }
        }
    }

    menuFolder?.let { (path, name, count) ->
        val folderSongs = remember(path, songs) { songs.filter { it.folderPath == path } }
        ModalBottomSheet(onDismissRequest = { menuFolder = null }) {
            Column(Modifier.padding(bottom = 24.dp)) {
                Text(
                    "$name · ${if (count == 1) "1 música" else "$count músicas"}",
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                )
                FolderMenuItem(Icons.Rounded.PlayArrow, "Tocar") { vm.playSongs(folderSongs, 0); menuFolder = null }
                FolderMenuItem(Icons.Rounded.Shuffle, "Tocar aleatório") { vm.shuffleAll(folderSongs); menuFolder = null }
                FolderMenuItem(Icons.AutoMirrored.Rounded.QueueMusic, "Adicionar à fila") {
                    folderSongs.forEach { vm.addToQueue(it) }
                    menuFolder = null
                }
                FolderMenuItem(Icons.Rounded.VisibilityOff, "Ocultar pasta", highlight = true) {
                    vm.hideFolderWithUndo(path, name)
                    menuFolder = null
                }
            }
        }
    }
}

@Composable
private fun FolderMenuItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    highlight: Boolean = false,
    onClick: () -> Unit,
) {
    val color = if (highlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = color)
        Text(label, color = color, modifier = Modifier.padding(start = 16.dp))
    }
}

// ---------------- Playlists ----------------

@Composable
fun PlaylistsScreen(vm: MainViewModel, onOpen: (Detail) -> Unit, onBack: (() -> Unit)? = null) {
    if (onBack != null) androidx.activity.compose.BackHandler(onBack = onBack)
    val playlists by vm.playlistStore.playlists.collectAsStateWithLifecycle()
    var creating by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        SimpleTopBar("Playlists", onBack = onBack, actions = {
            IconButton(onClick = { creating = true }) { Icon(Icons.Rounded.Add, "Nova playlist") }
        })
        LazyColumn(Modifier.fillMaxSize()) {
            item(key = "smart") { SmartPlaylistGrid(vm, onOpen) }
            items(playlists, key = { it.id }) { p ->
                GroupRow(
                    icon = if (p.id == FAVORITES_ID) Icons.Rounded.Favorite else Icons.AutoMirrored.Rounded.QueueMusic,
                    title = p.name,
                    subtitle = "${p.songIds.size} músicas",
                    onClick = { onOpen(Detail.PlaylistDetail(p.id)) },
                )
            }
        }
    }
    if (creating) {
        NameDialog("Nova playlist", "", "Criar", onConfirm = {
            vm.playlistStore.create(it)
            creating = false
        }, onDismiss = { creating = false })
    }
}

// ---------------- Detalhes (álbum, artista, pasta, playlist) ----------------

@Composable
fun DetailScreen(detail: Detail, vm: MainViewModel, onBack: () -> Unit) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    val playlists by vm.playlistStore.playlists.collectAsStateWithLifecycle()
    val byId = remember(songs) { songs.associateBy { it.id } }
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }

    val playlist = (detail as? Detail.PlaylistDetail)?.let { d -> playlists.firstOrNull { it.id == d.id } }
    if (detail is Detail.PlaylistDetail && playlist == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val ratings by vm.ratingsStore.ratings.collectAsStateWithLifecycle()
    val stats by vm.statsStore.stats.collectAsStateWithLifecycle()
    val sortable = detail is Detail.Artist || detail is Detail.Folder
    val (title, list) = remember(detail, songs, playlist, settings.songSort, ratings, stats) {
        when (detail) {
            is Detail.Album -> detail.name to songs.filter { it.albumId == detail.albumId }.sortedBy { it.trackNumber }
            is Detail.Artist -> detail.name to songs.filter { it.artist == detail.name }.sortedFor(settings.songSort, ratings)
            is Detail.Folder -> detail.name to songs.filter { it.folderPath == detail.path }.sortedFor(settings.songSort, ratings)
            is Detail.Smart -> detail.kind.label to smartSongs(detail.kind, songs, stats)
            is Detail.PlaylistDetail -> playlist!!.name to playlist.songIds.mapNotNull { byId[it] }
            is Detail.Recap -> "" to emptyList()
            Detail.Duplicates -> "" to emptyList()
        }
    }

    Column(Modifier.fillMaxSize()) {
        SimpleTopBar(title, onBack = onBack, actions = {
            if (playlist != null && playlist.id != FAVORITES_ID) {
                IconButton(onClick = { renaming = true }) { Icon(Icons.Rounded.Edit, "Renomear") }
                IconButton(onClick = { deleting = true }) { Icon(Icons.Rounded.Delete, "Excluir") }
            }
        })
        if (list.isEmpty()) {
            EmptyMessage(if (playlist != null) "Esta playlist está vazia.\nUse o menu ⋮ de uma música para adicioná-la." else "Nenhuma música aqui.")
        } else {
            SongList(
                list, vm,
                playlistId = playlist?.id,
                sortControl = {
                    if (sortable) SortButton(settings.songSort) { vm.setSongSort(it) }
                },
            )
        }
    }

    if (renaming && playlist != null) {
        NameDialog("Renomear playlist", playlist.name, "Salvar", onConfirm = {
            vm.playlistStore.rename(playlist.id, it)
            renaming = false
        }, onDismiss = { renaming = false })
    }
    if (deleting && playlist != null) {
        AlertDialog(
            onDismissRequest = { deleting = false },
            title = { Text("Excluir playlist?") },
            text = { Text("A playlist \"${playlist.name}\" será excluída. As músicas continuam no aparelho.") },
            confirmButton = {
                TextButton(onClick = { deleting = false; vm.playlistStore.delete(playlist.id) }) { Text("Excluir") }
            },
            dismissButton = { TextButton(onClick = { deleting = false }) { Text("Cancelar") } },
        )
    }
}


/** Nome de cada aba da tela principal. */
fun tabTitle(id: String): String = when (id) {
    "home" -> "Início"
    "songs" -> "Músicas"
    "youtube" -> "YouTube"
    "artists" -> "Artistas"
    "albums" -> "Álbuns"
    "folders" -> "Pastas"
    else -> id
}

/** Fileira de abas em pílula. Segurar uma aba e arrastar muda a ordem. */
@Composable
private fun TabPills(
    tabs: List<String>,
    current: Int,
    onSelect: (Int) -> Unit,
    onReorder: (List<String>) -> Unit,
    hidden: List<String> = emptyList(),
    onHide: (String) -> Unit = {},
    onShow: (String) -> Unit = {},
    onOrganize: () -> Unit = {},
) {
    var order by remember(tabs) { mutableStateOf(tabs) }
    // Segurou e soltou sem arrastar: abre o menu da aba
    var menuFor by remember { mutableStateOf<String?>(null) }
    var showHiddenMenu by remember { mutableStateOf(false) }
    var moved by remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
    val latestTabs by androidx.compose.runtime.rememberUpdatedState(tabs)
    val latestReorder by androidx.compose.runtime.rememberUpdatedState(onReorder)
    var dragging by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
    val widths = remember { androidx.compose.runtime.mutableStateMapOf<String, Int>() }
    val haptics = androidx.compose.ui.platform.LocalHapticFeedback.current
    val scroll = androidx.compose.foundation.rememberScrollState()
    val density = androidx.compose.ui.platform.LocalDensity.current
    val gapPx = with(density) { 4.dp.toPx() }
    val currentId = tabs.getOrNull(current)

    // Mantém a aba escolhida visível
    LaunchedEffect(currentId, widths.size) {
        val idx = order.indexOf(currentId)
        if (idx > 0) {
            val x = order.take(idx - 1).sumOf { (widths[it] ?: 0) + gapPx.toInt() }
            scroll.animateScrollTo(x)
        } else if (idx == 0) scroll.animateScrollTo(0)
    }

    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(scroll, enabled = dragging == null)
            .padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        order.forEach { id ->
            androidx.compose.runtime.key(id) {
                val isDrag = dragging == id
                val selected = id == currentId
                val bg by animateColorAsState(
                    when {
                        isDrag -> MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
                        selected -> MaterialTheme.colorScheme.onSurface
                        else -> Color.Transparent
                    },
                    label = "pillBg",
                )
                val fg by animateColorAsState(
                    when {
                        isDrag -> MaterialTheme.colorScheme.onSurface
                        selected -> MaterialTheme.colorScheme.surfaceContainerLow
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    label = "pillFg",
                )
                Box(Modifier.zIndex(if (isDrag) 1f else 0f)) {
                Text(
                    tabTitle(id),
                    color = fg,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    modifier = Modifier
                        .onGloballyPositioned { widths[id] = it.size.width }
                        .zIndex(if (isDrag) 1f else 0f)
                        .graphicsLayer {
                            translationX = if (isDrag) dragOffset else 0f
                            val sc = if (isDrag) 1.08f else 1f
                            scaleX = sc
                            scaleY = sc
                        }
                        .clip(RoundedCornerShape(24.dp))
                        .background(bg)
                        .pointerInput(id) {
                            detectDragGesturesAfterLongPress(
                                onDragStart = {
                                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                    dragging = id
                                    dragOffset = 0f
                                    moved = 0f
                                },
                                onDragEnd = {
                                    dragging = null
                                    dragOffset = 0f
                                    if (order != latestTabs) latestReorder(order)
                                    else if (moved < 24f) menuFor = id
                                },
                                onDragCancel = {
                                    dragging = null
                                    dragOffset = 0f
                                    order = latestTabs
                                },
                                onDrag = { change, amount ->
                                    change.consume()
                                    dragOffset += amount.x
                                    moved += kotlin.math.abs(amount.x)
                                    val idx = order.indexOf(id)
                                    if (dragOffset > 0 && idx < order.size - 1) {
                                        val w = (widths[order[idx + 1]] ?: 0) + gapPx
                                        if (dragOffset > w / 2) {
                                            order = order.toMutableList().apply { removeAt(idx); add(idx + 1, id) }
                                            dragOffset -= w
                                        }
                                    } else if (dragOffset < 0 && idx > 0) {
                                        val w = (widths[order[idx - 1]] ?: 0) + gapPx
                                        if (-dragOffset > w / 2) {
                                            order = order.toMutableList().apply { removeAt(idx); add(idx - 1, id) }
                                            dragOffset += w
                                        }
                                    }
                                },
                            )
                        }
                        .clickable { tabs.indexOf(id).takeIf { it >= 0 }?.let(onSelect) }
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                )
                DropdownMenu(expanded = menuFor == id, onDismissRequest = { menuFor = null }) {
                    DropdownMenuItem(
                        leadingIcon = { Icon(Icons.Rounded.VisibilityOff, null) },
                        text = { Text("Ocultar aba") },
                        enabled = tabs.size > 1,
                        onClick = { menuFor = null; onHide(id) },
                    )
                    DropdownMenuItem(
                        leadingIcon = { Icon(Icons.Rounded.Tune, null) },
                        text = { Text("Organizar abas") },
                        onClick = { menuFor = null; onOrganize() },
                    )
                    Text(
                        "Segure e arraste para mudar a ordem",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    )
                }
                }
            }
        }
        // Abas ocultas: botão com o olho e a quantidade
        if (hidden.isNotEmpty()) {
            Box {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(24.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(24.dp))
                        .clickable { showHiddenMenu = true }
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.Visibility, "Abas ocultas", Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        "${hidden.size}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 4.dp),
                    )
                }
                DropdownMenu(expanded = showHiddenMenu, onDismissRequest = { showHiddenMenu = false }) {
                    Text(
                        "Abas ocultas",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    )
                    hidden.forEach { h ->
                        DropdownMenuItem(
                            leadingIcon = { Icon(Icons.Rounded.Visibility, null) },
                            text = { Text("Mostrar ${tabTitle(h)}") },
                            onClick = {
                                onShow(h)
                                if (hidden.size <= 1) showHiddenMenu = false
                            },
                        )
                    }
                }
            }
        }
    }
}
