package com.ritmo.player.ui

import android.app.Application
import android.content.ComponentName
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.ritmo.player.data.LibraryCache
import com.ritmo.player.data.Lyrics
import com.ritmo.player.data.LyricsRepository
import com.ritmo.player.data.MusicRepository
import com.ritmo.player.data.PlayStatsStore
import com.ritmo.player.data.ResumeStore
import com.ritmo.player.data.SongEdit
import com.ritmo.player.data.SongEditsStore
import com.ritmo.player.data.PlayMode
import com.ritmo.player.data.PlaylistStore
import com.ritmo.player.data.SettingsStore
import com.ritmo.player.data.Song
import com.ritmo.player.data.toMediaItem
import com.ritmo.player.playback.PlaybackService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

data class PlayerUiState(
    val hasMedia: Boolean = false,
    val mediaId: String? = null,
    val title: String = "",
    val artist: String = "",
    val album: String = "",
    val artUri: Uri? = null,
    val isPlaying: Boolean = false,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val durationMs: Long = 0,
    val speed: Float = 1f,
    val queue: List<MediaItem> = emptyList(),
    val queueIndex: Int = -1,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = MusicRepository(app)
    val playlistStore = PlaylistStore(app)
    val settingsStore = SettingsStore.get(app)
    val editsStore = SongEditsStore(app)
    val statsStore = PlayStatsStore(app)

    /** Músicas como estão no celular (sem as suas edições). */
    private var rawSongs: List<Song> = emptyList()
    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()
    private var loaded = false

    private val _player = MutableStateFlow(PlayerUiState())
    val player: StateFlow<PlayerUiState> = _player.asStateFlow()

    private val _sleepTimerEnd = MutableStateFlow<Long?>(null)
    val sleepTimerEnd: StateFlow<Long?> = _sleepTimerEnd.asStateFlow()
    private var sleepJob: Job? = null

    private var controller: MediaController? = null

    private var resumeJob: Job? = null
    private var restored = false
    private var refreshJob: Job? = null

    /** Atualiza sozinho quando entra ou sai música do celular. */
    private val mediaObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            if (!loaded) return
            refreshJob?.cancel()
            refreshJob = viewModelScope.launch {
                delay(2000) // espera terminar de copiar os arquivos
                loadLibrary(force = true)
            }
        }
    }

    init {
        connectToService()
        runCatching {
            app.contentResolver.registerContentObserver(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, mediaObserver
            )
        }
    }

    // ---------- Biblioteca ----------

    fun loadLibrary(force: Boolean = false) {
        if (loaded && !force) return
        val firstTime = !loaded
        loaded = true
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            // 1) Abre na hora com a lista guardada da última vez
            if (firstTime && rawSongs.isEmpty()) {
                val cached = LibraryCache.load(ctx)
                if (cached.isNotEmpty()) setRawSongs(cached)
            }
            // 2) Confere o celular em segundo plano
            if (_songs.value.isEmpty()) _loading.value = true
            val fresh = runCatching {
                repo.loadSongs(settingsStore.settings.value.minDurationSec)
            }.getOrNull()
            if (fresh != null) {
                setRawSongs(fresh)
                LibraryCache.save(ctx, fresh)
            }
            _loading.value = false
            tryRestoreQueue()
        }
    }

    private fun setRawSongs(list: List<Song>) {
        rawSongs = list
        _songs.value = editsStore.apply(list)
    }

    // ---------- Editar música (só dentro do Ritmo) ----------

    fun saveEdit(song: Song, edit: SongEdit) {
        editsStore.save(song.id, edit)
        setRawSongs(rawSongs)
        refreshQueueMetadata()
    }

    fun clearEdit(song: Song) {
        editsStore.clear(song.id)
        setRawSongs(rawSongs)
        refreshQueueMetadata()
    }

    /** Atualiza nome e capa nas músicas que já estão na fila. */
    private fun refreshQueueMetadata() {
        val c = controller ?: return
        val byId = _songs.value.associateBy { it.id }
        for (i in 0 until c.mediaItemCount) {
            val id = c.getMediaItemAt(i).mediaId.toLongOrNull() ?: continue
            val song = byId[id] ?: continue
            c.replaceMediaItem(i, song.toMediaItem())
        }
    }

    // ---------- Letras ----------

    private val _lyrics = MutableStateFlow<Lyrics?>(null)
    val lyrics: StateFlow<Lyrics?> = _lyrics.asStateFlow()
    private val _lyricsLoading = MutableStateFlow(false)
    val lyricsLoading: StateFlow<Boolean> = _lyricsLoading.asStateFlow()
    private var lyricsFor: String? = null

    /** Carrega a letra da música atual (só quando a tela de letra está aberta). */
    fun ensureLyrics(mediaId: String?, force: Boolean = false) {
        if (mediaId == null || (mediaId == lyricsFor && !force)) return
        lyricsFor = mediaId
        _lyrics.value = null
        val song = _songs.value.firstOrNull { it.id.toString() == mediaId } ?: return
        viewModelScope.launch {
            _lyricsLoading.value = true
            val result = LyricsRepository.load(getApplication(), song)
            if (lyricsFor == mediaId) _lyrics.value = result
            _lyricsLoading.value = false
        }
    }

    fun saveLyrics(text: String) {
        val id = lyricsFor?.toLongOrNull() ?: return
        LyricsRepository.saveUser(getApplication(), id, text)
        ensureLyrics(lyricsFor, force = true)
    }

    fun removeUserLyrics() {
        val id = lyricsFor?.toLongOrNull() ?: return
        LyricsRepository.deleteUser(getApplication(), id)
        ensureLyrics(lyricsFor, force = true)
    }

    fun hasUserLyrics(): Boolean =
        lyricsFor?.toLongOrNull()?.let { LyricsRepository.hasUserLyrics(getApplication(), it) } == true

    // ---------- Continuar de onde parou ----------

    private fun saveResume() {
        val c = controller ?: return
        if (c.mediaItemCount == 0) return
        val ids = (0 until c.mediaItemCount).mapNotNull { c.getMediaItemAt(it).mediaId.toLongOrNull() }
        ResumeStore.save(getApplication(), ids, c.currentMediaItemIndex, c.currentPosition)
    }

    /** Ao abrir o app, coloca de volta a última fila, pausada no mesmo ponto. */
    private fun tryRestoreQueue() {
        if (restored) return
        val c = controller ?: return
        if (_songs.value.isEmpty()) return
        restored = true
        if (!settingsStore.settings.value.resumePlayback || c.mediaItemCount > 0) return
        val state = ResumeStore.load(getApplication()) ?: return
        val byId = _songs.value.associateBy { it.id }
        val items = state.ids.mapNotNull { byId[it]?.toMediaItem() }
        if (items.isEmpty()) return
        val index = state.index.coerceIn(0, items.size - 1)
        c.setMediaItems(items, index, state.positionMs)
        c.prepare()
    }

    fun setSongSort(sort: com.ritmo.player.data.SongSort) {
        settingsStore.update { it.copy(songSort = sort) }
    }

    fun setMinDuration(seconds: Int) {
        settingsStore.update { it.copy(minDurationSec = seconds) }
        loadLibrary(force = true)
    }

    // ---------- Conexão com o serviço de reprodução ----------

    private fun connectToService() {
        val ctx = getApplication<Application>()
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            val c = runCatching { future.get() }.getOrNull() ?: return@addListener
            controller = c
            c.addListener(object : Player.Listener {
                override fun onEvents(player: Player, events: Player.Events) {
                    refresh(includeQueue = events.contains(Player.EVENT_TIMELINE_CHANGED))
                    // Conta uma reprodução só quando a música realmente vai tocar
                    if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION) && player.playWhenReady) {
                        player.currentMediaItem?.mediaId?.toLongOrNull()?.let { statsStore.record(it) }
                    }
                    if (events.containsAny(
                            Player.EVENT_MEDIA_ITEM_TRANSITION,
                            Player.EVENT_IS_PLAYING_CHANGED,
                            Player.EVENT_TIMELINE_CHANGED,
                        )
                    ) saveResume()
                }

                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    // Enquanto toca, salva a posição a cada 10 segundos
                    resumeJob?.cancel()
                    if (isPlaying) resumeJob = viewModelScope.launch {
                        while (true) {
                            delay(10_000)
                            saveResume()
                        }
                    }
                }
            })
            // Volta o modo de reprodução que você escolheu da última vez
            if (c.mediaItemCount == 0) setPlayMode(settingsStore.settings.value.playMode)
            refresh(includeQueue = true)
            tryRestoreQueue()
        }, ContextCompat.getMainExecutor(ctx))
    }

    private fun refresh(includeQueue: Boolean) {
        val c = controller ?: return
        val item = c.currentMediaItem
        val md = c.mediaMetadata
        val old = _player.value
        _player.value = PlayerUiState(
            hasMedia = item != null,
            mediaId = item?.mediaId,
            title = md.title?.toString() ?: "",
            artist = md.artist?.toString() ?: "",
            album = md.albumTitle?.toString() ?: "",
            artUri = md.artworkUri,
            isPlaying = c.isPlaying,
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
            durationMs = c.duration.coerceAtLeast(0),
            speed = c.playbackParameters.speed,
            queue = if (includeQueue) (0 until c.mediaItemCount).map { c.getMediaItemAt(it) } else old.queue,
            queueIndex = c.currentMediaItemIndex,
        )
    }

    fun positionMs(): Long = controller?.currentPosition ?: 0L

    // ---------- Controles ----------

    /** Toca a lista. O modo de reprodução escolhido (aleatório, repetir...) é mantido. */
    fun playSongs(list: List<Song>, startIndex: Int) {
        val c = controller ?: return
        if (list.isEmpty()) return
        c.setMediaItems(list.map { it.toMediaItem() }, startIndex, 0L)
        c.prepare()
        c.play()
    }

    fun shuffleAll(list: List<Song>) {
        if (list.isEmpty()) return
        setPlayMode(PlayMode.SHUFFLE)
        playSongs(list, Random.nextInt(list.size))
    }

    fun addAllToQueue(list: List<Song>) {
        val c = controller ?: return
        if (list.isEmpty()) return
        if (c.mediaItemCount == 0) playSongs(list, 0) else c.addMediaItems(list.map { it.toMediaItem() })
    }

    fun removeFromQueueByIds(ids: Set<Long>) {
        val c = controller ?: return
        for (i in c.mediaItemCount - 1 downTo 0) {
            if (c.getMediaItemAt(i).mediaId.toLongOrNull() in ids) c.removeMediaItem(i)
        }
    }

    // ---------- Modo de reprodução ----------

    fun setPlayMode(mode: PlayMode) {
        val c = controller
        if (c != null) {
            c.shuffleModeEnabled = mode == PlayMode.SHUFFLE
            c.repeatMode = when (mode) {
                PlayMode.ONE -> Player.REPEAT_MODE_ONE
                PlayMode.SHUFFLE, PlayMode.ALL -> Player.REPEAT_MODE_ALL
                PlayMode.ORDER -> Player.REPEAT_MODE_OFF
            }
        }
        settingsStore.update { it.copy(playMode = mode) }
    }

    private fun savePlayModeFromPlayer() {
        val c = controller ?: return
        val mode = when {
            c.repeatMode == Player.REPEAT_MODE_ONE -> PlayMode.ONE
            c.shuffleModeEnabled -> PlayMode.SHUFFLE
            c.repeatMode == Player.REPEAT_MODE_ALL -> PlayMode.ALL
            else -> PlayMode.ORDER
        }
        if (settingsStore.settings.value.playMode != mode) settingsStore.update { it.copy(playMode = mode) }
    }

    fun playNext(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            playSongs(listOf(song), 0)
        } else {
            c.addMediaItem(c.currentMediaItemIndex + 1, song.toMediaItem())
        }
    }

    fun addToQueue(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) playSongs(listOf(song), 0) else c.addMediaItem(song.toMediaItem())
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) {
            c.pause()
        } else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            if (c.playbackState == Player.STATE_ENDED) c.seekToDefaultPosition()
            c.play()
        }
    }

    fun next() { controller?.seekToNext() }
    fun previous() { controller?.seekToPrevious() }
    fun seekTo(ms: Long) { controller?.seekTo(ms) }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
        savePlayModeFromPlayer()
    }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        savePlayModeFromPlayer()
    }

    fun setSpeed(speed: Float) {
        controller?.playbackParameters = PlaybackParameters(speed)
    }

    fun playQueueIndex(index: Int) {
        controller?.let { it.seekTo(index, 0L); it.play() }
    }

    fun removeFromQueue(index: Int) {
        controller?.removeMediaItem(index)
    }

    fun toggleFavorite(songId: Long) = playlistStore.toggleFavorite(songId)

    // ---------- Timer para dormir ----------

    fun setSleepTimer(minutes: Int?) {
        sleepJob?.cancel()
        if (minutes == null) {
            _sleepTimerEnd.value = null
            return
        }
        val durationMs = minutes * 60_000L
        _sleepTimerEnd.value = System.currentTimeMillis() + durationMs
        sleepJob = viewModelScope.launch {
            delay(durationMs)
            controller?.pause()
            _sleepTimerEnd.value = null
        }
    }

    override fun onCleared() {
        saveResume()
        runCatching { getApplication<Application>().contentResolver.unregisterContentObserver(mediaObserver) }
        controller?.release()
        controller = null
        super.onCleared()
    }
}
