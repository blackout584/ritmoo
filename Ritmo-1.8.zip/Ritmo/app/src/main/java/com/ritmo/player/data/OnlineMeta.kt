package com.ritmo.player.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * 1.8: busca letra (LRCLIB) e capa (Apple / Deezer) na internet quando a música não tem.
 * O que acha fica guardado no celular; o arquivo da música não muda.
 */
object OnlineMeta {

    private const val UA = "Ritmo/1.8 (https://github.com/blackout584/ritmoo)"
    private const val MISS_RETRY_MS = 7L * 24 * 3600_000 // tenta de novo depois de 7 dias

    fun autoLyricsFile(ctx: Context, id: Long) = File(ctx.filesDir, "lyrics_auto/$id.lrc")
    fun autoCoverFile(ctx: Context, id: Long) = File(ctx.filesDir, "covers_auto/$id.jpg")
    private fun missFile(ctx: Context, kind: String, id: Long) = File(ctx.filesDir, "online_miss/$kind-$id")

    /** Tem internet (e Wi-Fi, se você pediu só no Wi-Fi)? */
    fun canUse(ctx: Context): Boolean = runCatching {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return false
        val wifiOnly = SettingsStore.get(ctx).settings.value.onlineWifiOnly
        !wifiOnly || caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }.getOrDefault(false)

    fun recentlyMissed(ctx: Context, kind: String, id: Long): Boolean {
        val f = missFile(ctx, kind, id)
        return f.exists() && System.currentTimeMillis() - f.lastModified() < MISS_RETRY_MS
    }

    private fun markMiss(ctx: Context, kind: String, id: Long) {
        runCatching { missFile(ctx, kind, id).apply { parentFile?.mkdirs() }.writeText("") }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** Nome sem "(feat. ...)", "[Clipe]" e afins, para achar mais fácil. */
    private fun cleanTitle(t: String): String =
        t.replace(Regex("""\s*[(\[][^)\]]*(feat|ft\.|part|prod|clipe|video|vídeo|official|oficial|lyric|letra|remaster)[^)\]]*[)\]]""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""\.(mp3|m4a|flac|ogg|wav|opus)$""", RegexOption.IGNORE_CASE), "")
            .trim()

    private fun mainArtist(a: String): String =
        if (a.isBlank() || a.startsWith("<")) "" else artistNames(a).firstOrNull().orEmpty()

    private fun httpGet(url: String): String? = runCatching {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 10000
        c.setRequestProperty("User-Agent", UA)
        try {
            if (c.responseCode != 200) null else c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }.getOrNull()

    private fun download(url: String, to: File): Boolean = runCatching {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", UA)
        try {
            if (c.responseCode != 200) return@runCatching false
            to.parentFile?.mkdirs()
            val tmp = File(to.path + ".tmp")
            c.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            tmp.length() > 1000 && tmp.renameTo(to)
        } finally {
            c.disconnect()
        }
    }.getOrDefault(false)

    // ---------------- Letra ----------------

    /** Busca a letra (sincronizada, se tiver). Devolve o texto e guarda no celular. */
    suspend fun fetchLyrics(ctx: Context, song: Song): String? = withContext(Dispatchers.IO) {
        val title = cleanTitle(song.title)
        val artist = mainArtist(song.artist)
        if (title.isBlank()) return@withContext null
        var text: String? = null
        if (artist.isNotBlank()) {
            httpGet(
                "https://lrclib.net/api/get?artist_name=${enc(artist)}&track_name=${enc(title)}" +
                    "&duration=${song.durationMs / 1000}"
            )?.let { body ->
                runCatching {
                    val o = JSONObject(body)
                    text = o.optString("syncedLyrics").takeIf { it.isNotBlank() && it != "null" }
                        ?: o.optString("plainLyrics").takeIf { it.isNotBlank() && it != "null" }
                }
            }
        }
        if (text == null) {
            val q = if (artist.isNotBlank()) "track_name=${enc(title)}&artist_name=${enc(artist)}" else "q=${enc(title)}"
            httpGet("https://lrclib.net/api/search?$q")?.let { body ->
                runCatching {
                    val arr = JSONArray(body)
                    var plain: String? = null
                    for (i in 0 until minOf(arr.length(), 8)) {
                        val o = arr.getJSONObject(i)
                        // duração parecida (até 5 s de diferença), quando dá para comparar
                        val d = o.optDouble("duration", -1.0)
                        if (d > 0 && song.durationMs > 0 && kotlin.math.abs(d - song.durationMs / 1000.0) > 5) continue
                        val synced = o.optString("syncedLyrics").takeIf { it.isNotBlank() && it != "null" }
                        if (synced != null) { text = synced; break }
                        if (plain == null) plain = o.optString("plainLyrics").takeIf { it.isNotBlank() && it != "null" }
                    }
                    if (text == null) text = plain
                }
            }
        }
        val found = text
        if (found == null) {
            markMiss(ctx, "l", song.id)
        } else {
            runCatching { autoLyricsFile(ctx, song.id).apply { parentFile?.mkdirs() }.writeText(found) }
        }
        found
    }

    // ---------------- Capa ----------------

    /** A música já tem capa (no arquivo, escolhida por você ou baixada)? */
    fun hasArt(ctx: Context, song: Song): Boolean {
        if (song.customArt != null) return true
        if (autoCoverFile(ctx, song.id).exists()) return true
        val fromStore = runCatching {
            ctx.contentResolver.openFileDescriptor(song.artUri, "r")?.use { true } ?: false
        }.getOrDefault(false)
        if (fromStore) return true
        // Confere também a capa gravada dentro do arquivo
        return runCatching {
            val r = android.media.MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, song.uri)
                r.embeddedPicture != null
            } finally {
                r.release()
            }
        }.getOrDefault(true) // na dúvida, não troca a capa

    }

    /** Busca a capa e guarda no celular. Devolve true se achou. */
    suspend fun fetchCover(ctx: Context, song: Song): Boolean = withContext(Dispatchers.IO) {
        val title = cleanTitle(song.title)
        val artist = mainArtist(song.artist)
        if (title.isBlank()) return@withContext false
        val term = listOf(artist, title).filter { it.isNotBlank() }.joinToString(" ")
        var url: String? = null
        // 1) Catálogo da Apple
        httpGet("https://itunes.apple.com/search?term=${enc(term)}&entity=song&limit=3&country=BR")?.let { body ->
            runCatching {
                val arr = JSONObject(body).getJSONArray("results")
                if (arr.length() > 0) {
                    url = arr.getJSONObject(0).optString("artworkUrl100")
                        .takeIf { it.isNotBlank() }
                        ?.replace("100x100bb", "600x600bb")
                }
            }
        }
        // 2) Deezer
        if (url == null) {
            httpGet("https://api.deezer.com/search?q=${enc(term)}&limit=3")?.let { body ->
                runCatching {
                    val arr = JSONObject(body).getJSONArray("data")
                    if (arr.length() > 0) {
                        url = arr.getJSONObject(0).getJSONObject("album").optString("cover_xl").takeIf { it.isNotBlank() }
                    }
                }
            }
        }
        val ok = url?.let { download(it, autoCoverFile(ctx, song.id)) } == true
        if (!ok) markMiss(ctx, "c", song.id)
        ok
    }

    /** Coloca as capas baixadas nas músicas que não têm capa própria. */
    fun applyCovers(ctx: Context, songs: List<Song>): List<Song> {
        val dir = File(ctx.filesDir, "covers_auto")
        val ids = dir.list()?.mapNotNull { it.removeSuffix(".jpg").toLongOrNull() }?.toHashSet() ?: return songs
        if (ids.isEmpty()) return songs
        return songs.map { s ->
            if (s.customArt == null && s.id in ids) s.copy(customArt = Uri.fromFile(autoCoverFile(ctx, s.id))) else s
        }
    }
}
