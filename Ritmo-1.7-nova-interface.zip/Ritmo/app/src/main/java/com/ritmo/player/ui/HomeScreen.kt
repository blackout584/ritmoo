package com.ritmo.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.data.Song
import java.util.Calendar

/** Tela inicial "Para você": recentes, mais ouvidas e adicionadas recentemente. */
@Composable
fun HomeScreen(vm: MainViewModel, onOpen: (Detail) -> Unit, onBack: () -> Unit) {
    androidx.activity.compose.BackHandler(onBack = onBack)
    val songs by vm.songs.collectAsStateWithLifecycle()
    val stats by vm.statsStore.stats.collectAsStateWithLifecycle()
    val byId = remember(songs) { songs.associateBy { it.id } }

    val recent = remember(byId, stats) {
        stats.entries.sortedByDescending { it.value.lastPlayed }.mapNotNull { byId[it.key] }.take(15)
    }
    val top = remember(byId, stats) {
        stats.entries.sortedByDescending { it.value.count }
            .mapNotNull { e -> byId[e.key]?.let { it to e.value.count } }
            .take(5)
    }
    val added = remember(songs) { songs.sortedByDescending { it.dateAdded }.take(15) }
    val greeting = remember {
        when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
            in 5..11 -> "Bom dia"
            in 12..17 -> "Boa tarde"
            else -> "Boa noite"
        }
    }

    if (songs.isEmpty()) {
        EmptyMessage("Nenhuma música encontrada ainda.\nAbra a Biblioteca para carregar suas músicas.")
        return
    }

    Column(Modifier.fillMaxSize()) {
    SimpleTopBar("Recentes e para você", onBack = onBack)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp)) {
                Text(greeting, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Para você", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }
        }
        item {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { vm.shuffleAll(songs) },
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(48.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.Shuffle, null, tint = MaterialTheme.colorScheme.onPrimary)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("Toque algo aleatório", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Mistura de ${songs.size} músicas",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }

        if (recent.isNotEmpty()) {
            item { SectionHeader("Tocadas recentemente") }
            item { SongCarousel(recent) { i -> vm.playSongs(recent, i) } }
        }

        if (top.isNotEmpty()) {
            item { SectionHeader("Mais ouvidas") }
            itemsIndexed(top, key = { _, p -> "top_${p.first.id}" }) { i, (song, count) ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { vm.playSongs(top.map { it.first }, i) }
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "${i + 1}",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.width(24.dp),
                    )
                    ArtImage(song.artUri, Modifier.size(48.dp))
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            if (count == 1) "1 vez" else "$count vezes",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        item { SectionHeader("Adicionadas recentemente") }
        item { SongCarousel(added) { i -> vm.playSongs(added, i) } }
    }
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp),
    )
}

@Composable
private fun SongCarousel(songs: List<Song>, onPlay: (Int) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        itemsIndexed(songs, key = { _, s -> s.id }) { i, song ->
            Column(
                Modifier
                    .width(124.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onPlay(i) }
            ) {
                ArtImage(song.artUri, Modifier.size(124.dp), corner = 12.dp)
                Spacer(Modifier.height(6.dp))
                Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                Text(
                    song.artist,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
