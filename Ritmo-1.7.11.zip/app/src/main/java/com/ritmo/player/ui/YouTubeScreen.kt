package com.ritmo.player.ui

import android.annotation.SuppressLint
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.ritmo.player.data.Song

private const val YT_HOME = "https://m.youtube.com/"

/** Pausa qualquer vídeo da página (o YouTube não toca com o app minimizado). */
private const val PAUSE_JS = "document.querySelectorAll('video,audio').forEach(function(m){m.pause();});"

/**
 * Aba YouTube: o site do YouTube dentro do Ritmo.
 * Os vídeos param ao sair da aba ou minimizar o app, como manda a regra do YouTube.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var lastUrl by rememberSaveable { mutableStateOf(YT_HOME) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var canGoBack by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var fullscreenView by remember { mutableStateOf<View?>(null) }
    var fullscreenCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    // Minimizou o app → pausa tudo. Voltou → libera de novo (sem dar play sozinho).
    DisposableEffect(lifecycleOwner, webView) {
        val observer = LifecycleEventObserver { _, event ->
            val wv = webView ?: return@LifecycleEventObserver
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    wv.evaluateJavascript(PAUSE_JS, null)
                    wv.onPause()
                }
                Lifecycle.Event.ON_RESUME -> wv.onResume()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Saiu da aba → para o vídeo e libera a memória
    DisposableEffect(Unit) {
        onDispose {
            webView?.let { wv ->
                wv.evaluateJavascript(PAUSE_JS, null)
                wv.stopLoading()
                wv.loadUrl("about:blank")
                (wv.parent as? ViewGroup)?.removeView(wv)
                wv.destroy()
            }
            webView = null
        }
    }

    BackHandler(enabled = fullscreenView != null) {
        fullscreenCallback?.onCustomViewHidden()
        fullscreenView = null
        fullscreenCallback = null
    }
    BackHandler(enabled = fullscreenView == null && canGoBack) { webView?.goBack() }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { webView?.goBack() }, enabled = canGoBack) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Voltar")
                }
                IconButton(onClick = { webView?.reload() }) { Icon(Icons.Rounded.Refresh, "Recarregar") }
                Text(
                    Uri.parse(lastUrl).host ?: "youtube.com",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                )
                IconButton(onClick = { webView?.loadUrl(YT_HOME) }) { Icon(Icons.Rounded.Home, "Início do YouTube") }
            }
            if (progress in 1..99) {
                LinearProgressIndicator(
                    progress = { progress / 100f },
                    modifier = Modifier.fillMaxWidth(),
                    drawStopIndicator = {},
                )
            }
            AndroidView(
                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)),
                factory = { ctx ->
                    WebView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                        )
                        setBackgroundColor(android.graphics.Color.BLACK)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.loadWithOverviewMode = true
                        settings.useWideViewPort = true
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                                val url = request.url
                                // Links normais abrem aqui dentro; links de "abrir no app" vão para o app
                                if (url.scheme == "http" || url.scheme == "https") return false
                                runCatching {
                                    context.startActivity(Intent.parseUri(url.toString(), Intent.URI_INTENT_SCHEME))
                                }
                                return true
                            }

                            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                                url?.let { lastUrl = it }
                            }

                            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                                canGoBack = view.canGoBack()
                                url?.let { if (it.startsWith("http")) lastUrl = it }
                            }
                        }
                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView, newProgress: Int) {
                                progress = newProgress
                            }

                            // Vídeo em tela cheia
                            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                                fullscreenView = view
                                fullscreenCallback = callback
                            }

                            override fun onHideCustomView() {
                                fullscreenView = null
                                fullscreenCallback = null
                            }
                        }
                        loadUrl(lastUrl)
                        webView = this
                    }
                },
            )
        }

        // Tela cheia por cima de tudo
        fullscreenView?.let { view ->
            AndroidView(
                factory = {
                    (view.parent as? ViewGroup)?.removeView(view)
                    view
                },
                modifier = Modifier.fillMaxSize().background(Color.Black),
            )
        }
    }
}

// ---------------- Abrir no app oficial ----------------

private fun searchText(title: String, artist: String): String =
    listOf(artist.takeUnless { it.startsWith("Artista desconhecido") }.orEmpty(), title)
        .filter { it.isNotBlank() }
        .joinToString(" ")

fun openInYouTube(context: Context, title: String, artist: String) {
    val q = searchText(title, artist)
    val app = Intent(Intent.ACTION_SEARCH)
        .setPackage("com.google.android.youtube")
        .putExtra(SearchManager.QUERY, q)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(app)
    } catch (e: ActivityNotFoundException) {
        openUrl(context, "https://www.youtube.com/results?search_query=${Uri.encode(q)}")
    }
}

fun openInYouTubeMusic(context: Context, title: String, artist: String) {
    val url = "https://music.youtube.com/search?q=${Uri.encode(searchText(title, artist))}"
    val app = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        .setPackage("com.google.android.apps.youtube.music")
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(app)
    } catch (e: ActivityNotFoundException) {
        openUrl(context, url)
    }
}

fun openInYouTube(context: Context, song: Song) = openInYouTube(context, song.title, song.artist)
fun openInYouTubeMusic(context: Context, song: Song) = openInYouTubeMusic(context, song.title, song.artist)

private fun openUrl(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "Nenhum app para abrir o link", Toast.LENGTH_SHORT).show()
    }
}
