package com.ritmo.player.ui

import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.ui.platform.LocalContext
import com.ritmo.player.data.AppIcons
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.data.ThemeMode
import com.ritmo.player.ui.theme.accentColors
import com.ritmo.player.ui.theme.accentNames
import com.ritmo.player.ui.theme.isThemed
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: (() -> Unit)? = null) {
    val settings by vm.settingsStore.settings.collectAsStateWithLifecycle()
    val songs by vm.songs.collectAsStateWithLifecycle()
    var minDuration by remember(settings.minDurationSec) { mutableFloatStateOf(settings.minDurationSec.toFloat()) }
    val dynamicAvailable = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    var showThemes by rememberSaveable { mutableStateOf(false) }
    var showEq by rememberSaveable { mutableStateOf(false) }
    if (showThemes) {
        ThemesScreen(vm, onBack = { showThemes = false })
        return
    }
    if (showEq) {
        EqualizerScreen(onBack = { showEq = false })
        return
    }
    var showFolders by rememberSaveable { mutableStateOf(false) }
    if (showFolders) {
        FoldersScreen(vm, onBack = { showFolders = false })
        return
    }
    val themed = settings.isThemed()

    if (onBack != null) androidx.activity.compose.BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize()) {
        SimpleTopBar("Configurações", onBack = onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {

            SectionTitle("Atualização")
            UpdateSettings(vm)
            HorizontalDivider(Modifier.padding(vertical = 12.dp))

            SectionTitle("Som")
            ListItem(
                modifier = Modifier.clickable { showEq = true },
                leadingContent = { Icon(Icons.Rounded.Equalizer, null, tint = MaterialTheme.colorScheme.primary) },
                headlineContent = { Text("Equalizador") },
                supportingContent = { Text("Graves, som 3D, predefinições e volume igual") },
                trailingContent = { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null) },
            )
            HorizontalDivider(Modifier.padding(vertical = 12.dp))

            SectionTitle("Aparência")
            ListItem(
                modifier = Modifier.clickable { showThemes = true },
                leadingContent = { Icon(Icons.Rounded.Palette, null, tint = MaterialTheme.colorScheme.primary) },
                headlineContent = { Text("Temas, papel de parede e fontes") },
                supportingContent = {
                    Text(
                        listOfNotNull(
                            settings.themeId.label,
                            if (settings.wallpaperPath != null) "papel de parede" else null,
                            settings.fontStyle.label.takeIf { settings.fontStyle.name != "DEFAULT" }?.let { "fonte $it" },
                        ).joinToString(" • ")
                    )
                },
                trailingContent = { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null) },
            )
            // Tamanho das letras
            var scale by remember(settings.fontScale) { mutableFloatStateOf(settings.fontScale) }
            Text("Tamanho das letras: ${(scale * 100).roundToInt()}%", Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("A", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = scale,
                    onValueChange = { scale = it },
                    onValueChangeFinished = { vm.settingsStore.update { it.copy(fontScale = scale) } },
                    valueRange = 0.85f..1.3f,
                    steps = 8,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                )
                Text("A", style = MaterialTheme.typography.titleLarge)
            }

            // Ícone do app na tela do celular
            Text("Ícone do app", Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            val context = LocalContext.current
            var iconIndex by remember { mutableStateOf(AppIcons.current(context)) }
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                val iconColors = listOf(
                    Color(0xFF4F7DF3) to Color.White,
                    Color.Black to Color.White,
                    Color(0xFF1A0820) to Color(0xFFFF4FA3),
                    Color(0xFF7A2A14) to Color(0xFFFFB04A),
                )
                AppIcons.options.forEachIndexed { i, option ->
                    val (bg, fg) = iconColors[i]
                    val selected = iconIndex == i
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier
                                .size(52.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(bg)
                                .border(
                                    if (selected) 3.dp else 1.dp,
                                    if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                    RoundedCornerShape(16.dp),
                                )
                                .clickable {
                                    if (!selected) {
                                        AppIcons.set(context, i)
                                        iconIndex = i
                                        Toast.makeText(context, "O ícone pode levar alguns segundos para mudar", Toast.LENGTH_LONG).show()
                                    }
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Rounded.MusicNote, option.label, tint = fg)
                        }
                        Text(option.label, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            if (!themed) {
            Text("Modo claro ou escuro", Modifier.padding(horizontal = 16.dp))
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 4.dp).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf(
                    ThemeMode.SYSTEM to "Sistema",
                    ThemeMode.LIGHT to "Claro",
                    ThemeMode.DARK to "Escuro",
                    ThemeMode.AUTO_TIME to "Pelo horário",
                )
                    .forEach { (mode, label) ->
                        FilterChip(
                            selected = settings.themeMode == mode,
                            onClick = { vm.settingsStore.update { it.copy(themeMode = mode) } },
                            label = { Text(label) },
                        )
                    }
            }

            if (dynamicAvailable) {
                ListItem(
                    headlineContent = { Text("Cores do papel de parede") },
                    supportingContent = { Text("Usa as cores do seu celular (Material You)") },
                    trailingContent = {
                        Switch(
                            checked = settings.dynamicColor,
                            onCheckedChange = { on -> vm.settingsStore.update { it.copy(dynamicColor = on) } },
                        )
                    },
                )
            }

            if (!dynamicAvailable || !settings.dynamicColor) {
                Text("Cor de destaque", Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                Row(
                    Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    accentColors.forEachIndexed { i, color ->
                        val selected = settings.accent == i
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).background(color)
                                .border(
                                    width = if (selected) 3.dp else 0.dp,
                                    color = if (selected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                    shape = CircleShape,
                                )
                                .clickable { vm.settingsStore.update { it.copy(accent = i) } },
                            contentAlignment = Alignment.Center,
                        ) {
                            if (selected) Icon(Icons.Rounded.Check, accentNames[i], tint = Color.White)
                        }
                    }
                }
            }

            }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            SectionTitle("Animações")
            ListItem(
                headlineContent = { Text("Barras que dançam") },
                supportingContent = { Text("Barras que pulam com o som na tela do player. Precisa da permissão de microfone, mas nada é gravado.") },
                trailingContent = {
                    Switch(
                        checked = settings.visualizer,
                        onCheckedChange = { on -> vm.settingsStore.update { it.copy(visualizer = on) } },
                    )
                },
            )
            ListItem(
                headlineContent = { Text("Fundo animado no player") },
                supportingContent = { Text("A capa da música desfocada, se mexendo no fundo") },
                trailingContent = {
                    Switch(
                        checked = settings.animatedPlayerBg,
                        onCheckedChange = { on -> vm.settingsStore.update { it.copy(animatedPlayerBg = on) } },
                    )
                },
            )
            ListItem(
                headlineContent = { Text("Capa em formato de disco") },
                supportingContent = { Text("A capa gira como um disco de vinil enquanto a música toca") },
                trailingContent = {
                    Switch(
                        checked = settings.vinylArt,
                        onCheckedChange = { on -> vm.settingsStore.update { it.copy(vinylArt = on) } },
                    )
                },
            )

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            SectionTitle("Reprodução")
            Text("Transição suave entre músicas", Modifier.padding(horizontal = 16.dp))
            Text(
                "A música vai abaixando no final e a próxima entra subindo",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 6.dp).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf(0, 2, 4, 6, 8).forEach { sec ->
                    FilterChip(
                        selected = settings.fadeSeconds == sec,
                        onClick = { vm.settingsStore.update { it.copy(fadeSeconds = sec) } },
                        label = { Text(if (sec == 0) "Desligada" else "$sec s") },
                    )
                }
            }
            ListItem(
                headlineContent = { Text("Continuar de onde parou") },
                supportingContent = { Text("Ao abrir o app, volta na última música, no mesmo ponto") },
                trailingContent = {
                    Switch(
                        checked = settings.resumePlayback,
                        onCheckedChange = { on -> vm.settingsStore.update { it.copy(resumePlayback = on) } },
                    )
                },
            )

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            SectionTitle("Biblioteca")
            Text(
                "Ignorar áudios com menos de ${minDuration.roundToInt()} segundos",
                Modifier.padding(horizontal = 16.dp),
            )
            Text(
                "Evita que toques de notificação e áudios do WhatsApp apareçam como música.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            Slider(
                value = minDuration,
                onValueChange = { minDuration = it },
                onValueChangeFinished = { vm.setMinDuration(minDuration.roundToInt()) },
                valueRange = 0f..120f,
                steps = 23,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            ListItem(
                modifier = Modifier.clickable { showFolders = true },
                leadingContent = { Icon(Icons.Rounded.FolderOpen, null, tint = MaterialTheme.colorScheme.primary) },
                headlineContent = { Text("Escolher pastas") },
                supportingContent = {
                    Text(
                        if (settings.hiddenFolders.isEmpty()) "Todas as pastas aparecem"
                        else "${settings.hiddenFolders.size} pasta(s) escondida(s)"
                    )
                },
                trailingContent = { Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null) },
            )
            OutlinedButton(
                onClick = { vm.loadLibrary(force = true) },
                modifier = Modifier.padding(horizontal = 16.dp),
            ) { Text("Atualizar biblioteca (${songs.size} músicas)") }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            SectionTitle("Backup")
            BackupSection()

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            SectionTitle("Sobre")
            Text(
                "Ritmo 1.7 — player de música gratuito, sem anúncios.",
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
    )
}
