package com.ritmo.player.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

/** O que foi ouvido num mês: vezes de cada música e de cada artista, total de músicas e tempo. */
data class MonthStats(
    val songPlays: Map<Long, Int> = emptyMap(),
    val artistPlays: Map<String, Int> = emptyMap(),
    val plays: Int = 0,
    val listenedMs: Long = 0,
)

/** Contagem separada por mês, para a Retrospectiva. Chave do mês: "2026-11". */
class MonthlyStatsStore private constructor(context: Context) {
    private val prefs = context.getSharedPreferences("monthly_stats", Context.MODE_PRIVATE)
    private val _months = MutableStateFlow(load())
    val months: StateFlow<Map<String, MonthStats>> = _months.asStateFlow()

    @Synchronized
    fun record(songId: Long, artist: String, durationMs: Long) {
        val key = monthKey(Calendar.getInstance())
        val old = _months.value[key] ?: MonthStats()
        val updated = old.copy(
            songPlays = old.songPlays + (songId to (old.songPlays[songId] ?: 0) + 1),
            artistPlays = if (artist.isBlank()) old.artistPlays
            else old.artistPlays + (artist to (old.artistPlays[artist] ?: 0) + 1),
            plays = old.plays + 1,
            listenedMs = old.listenedMs + durationMs.coerceAtLeast(0),
        )
        _months.value = _months.value + (key to updated)
        save()
    }

    private fun save() {
        val root = JSONObject()
        _months.value.forEach { (k, m) ->
            root.put(k, JSONObject().apply {
                put("p", JSONObject().apply { m.songPlays.forEach { (id, c) -> put(id.toString(), c) } })
                put("a", JSONObject().apply { m.artistPlays.forEach { (a, c) -> put(a, c) } })
                put("n", m.plays)
                put("ms", m.listenedMs)
            })
        }
        prefs.edit().putString("data", root.toString()).apply()
    }

    private fun load(): Map<String, MonthStats> = runCatching {
        val root = JSONObject(prefs.getString("data", "{}") ?: "{}")
        root.keys().asSequence().associateWith { k ->
            val o = root.getJSONObject(k)
            val p = o.optJSONObject("p") ?: JSONObject()
            val a = o.optJSONObject("a") ?: JSONObject()
            MonthStats(
                songPlays = p.keys().asSequence().associate { it.toLong() to p.getInt(it) },
                artistPlays = a.keys().asSequence().associateWith { a.getInt(it) },
                plays = o.optInt("n"),
                listenedMs = o.optLong("ms"),
            )
        }
    }.getOrDefault(emptyMap())

    companion object {
        @Volatile private var instance: MonthlyStatsStore? = null
        fun get(context: Context): MonthlyStatsStore =
            instance ?: synchronized(this) {
                instance ?: MonthlyStatsStore(context.applicationContext).also { instance = it }
            }

        fun monthKey(c: Calendar): String =
            String.format(Locale.US, "%04d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1)

        fun currentMonthKey(): String = monthKey(Calendar.getInstance())

        fun previousMonthKey(): String = monthKey(Calendar.getInstance().apply { add(Calendar.MONTH, -1) })

        private val monthNames = listOf(
            "janeiro", "fevereiro", "março", "abril", "maio", "junho",
            "julho", "agosto", "setembro", "outubro", "novembro", "dezembro",
        )

        /** "2026-11" → "novembro de 2026" */
        fun label(key: String): String {
            val (y, m) = key.split("-").let { it[0] to (it.getOrNull(1)?.toIntOrNull() ?: 1) }
            return "${monthNames.getOrElse(m - 1) { "" }} de $y"
        }

        /** "2026-11" → "Novembro 2026" (nome da playlist) */
        fun shortLabel(key: String): String {
            val (y, m) = key.split("-").let { it[0] to (it.getOrNull(1)?.toIntOrNull() ?: 1) }
            return monthNames.getOrElse(m - 1) { "" }.replaceFirstChar { it.uppercase() } + " " + y
        }
    }
}
