package com.ritmo.player.data

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.MetadataRetriever
import androidx.media3.extractor.metadata.id3.BinaryFrame
import androidx.media3.extractor.metadata.id3.TextInformationFrame
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.charset.Charset
import java.util.concurrent.TimeUnit

data class LyricLine(val timeMs: Long?, val text: String)

/** Letra da música. [synced] = tem o tempo de cada linha (estilo karaokê). */
data class Lyrics(val lines: List<LyricLine>, val synced: Boolean)

object LyricsRepository {

    private val timeTag = Regex("""\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]""")
    private val infoTag = Regex("""^\[[a-zA-Z]+:.*]$""")

    /** Entende letras comuns e arquivos .lrc ([01:23.45] linha). */
    fun parse(text: String): Lyrics? {
        val lines = mutableListOf<LyricLine>()
        var synced = false
        text.lines().forEach { raw ->
            val line = raw.trim()
            val tags = timeTag.findAll(line).toList()
            if (tags.isNotEmpty()) {
                synced = true
                val content = line.replace(timeTag, "").trim()
                tags.forEach { m ->
                    val min = m.groupValues[1].toLong()
                    val sec = m.groupValues[2].toLong()
                    val frac = m.groupValues[3]
                    val ms = when (frac.length) {
                        0 -> 0L
                        1 -> frac.toLong() * 100
                        2 -> frac.toLong() * 10
                        else -> frac.take(3).toLong()
                    }
                    lines += LyricLine(min * 60_000 + sec * 1000 + ms, content)
                }
            } else if (line.isNotEmpty() && !infoTag.matches(line)) {
                lines += LyricLine(null, line)
            }
        }
        if (lines.isEmpty()) return null
        return if (synced) {
            Lyrics(lines.filter { it.timeMs != null }.sortedBy { it.timeMs }, true)
        } else {
            Lyrics(lines, false)
        }
    }

    private fun userFile(context: Context, id: Long) = File(context.filesDir, "lyrics/$id.lrc")

    fun hasUserLyrics(context: Context, id: Long) = userFile(context, id).exists()

    fun saveUser(context: Context, id: Long, text: String) {
        val f = userFile(context, id)
        f.parentFile?.mkdirs()
        f.writeText(text)
    }

    fun deleteUser(context: Context, id: Long) {
        userFile(context, id).delete()
    }

    /** Procura a letra: 1) a que você adicionou, 2) arquivo .lrc ao lado da música, 3) letra gravada no arquivo. */
    suspend fun load(context: Context, song: Song): Lyrics? = withContext(Dispatchers.IO) {
        userFile(context, song.id).takeIf { it.exists() }
            ?.let { runCatching { parse(it.readText()) }.getOrNull() }
            ?.let { return@withContext it }

        if (song.path.isNotEmpty()) {
            val lrc = File(song.path.substringBeforeLast('.') + ".lrc")
            runCatching { if (lrc.canRead()) parse(lrc.readText()) else null }.getOrNull()
                ?.let { return@withContext it }
        }

        readEmbedded(context, song)?.let { parse(it) }
    }

    @OptIn(UnstableApi::class)
    private fun readEmbedded(context: Context, song: Song): String? = runCatching {
        val groups = MetadataRetriever.retrieveMetadata(context, MediaItem.fromUri(song.uri))
            .get(5, TimeUnit.SECONDS)
        for (g in 0 until groups.length) {
            val group = groups[g]
            for (t in 0 until group.length) {
                val metadata = group.getFormat(t).metadata ?: continue
                for (e in 0 until metadata.length()) {
                    when (val entry = metadata[e]) {
                        is BinaryFrame -> if (entry.id == "USLT") {
                            parseUslt(entry.data)?.let { return@runCatching it }
                        }
                        is TextInformationFrame -> if (
                            entry.description.equals("LYRICS", ignoreCase = true) ||
                            entry.description.equals("UNSYNCEDLYRICS", ignoreCase = true)
                        ) {
                            entry.values.firstOrNull()?.let { return@runCatching it }
                        }
                    }
                }
            }
        }
        null
    }.getOrNull()

    /** Lê o quadro USLT do MP3 (letra gravada no arquivo). */
    private fun parseUslt(data: ByteArray): String? {
        if (data.size < 5) return null
        val encoding = data[0].toInt()
        val charset: Charset = when (encoding) {
            1 -> Charsets.UTF_16
            2 -> Charsets.UTF_16BE
            3 -> Charsets.UTF_8
            else -> Charsets.ISO_8859_1
        }
        val twoByte = encoding == 1 || encoding == 2
        var i = 4 // pula codificação (1) + idioma (3)
        // pula a descrição, que termina em 0 (ou 00 em UTF-16)
        if (twoByte) {
            while (i + 1 < data.size && !(data[i].toInt() == 0 && data[i + 1].toInt() == 0)) i += 2
            i += 2
        } else {
            while (i < data.size && data[i].toInt() != 0) i++
            i += 1
        }
        if (i >= data.size) return null
        return String(data, i, data.size - i, charset).trim().trimEnd('\u0000').ifBlank { null }
    }
}
