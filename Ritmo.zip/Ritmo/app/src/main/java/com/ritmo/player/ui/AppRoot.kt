package com.ritmo.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle

enum class MainTab(val label: String, val icon: ImageVector) {
    LIBRARY("Biblioteca", Icons.Rounded.LibraryMusic),
    PLAYLISTS("Playlists", Icons.AutoMirrored.Rounded.QueueMusic),
    EQUALIZER("Equalizador", Icons.Rounded.Equalizer),
    SETTINGS("Ajustes", Icons.Rounded.Settings),
}

@Composable
fun AppRoot(vm: MainViewModel) {
    var tab by rememberSaveable { mutableStateOf(MainTab.LIBRARY) }
    var detail by remember { mutableStateOf<Detail?>(null) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    val player by vm.player.collectAsStateWithLifecycle()

    BackHandler(enabled = showPlayer) { showPlayer = false }
    BackHandler(enabled = !showPlayer && detail != null) { detail = null }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            bottomBar = {
                Column {
                    if (player.hasMedia) MiniPlayer(player, vm, onClick = { showPlayer = true })
                    NavigationBar {
                        MainTab.entries.forEach { t ->
                            NavigationBarItem(
                                selected = tab == t,
                                onClick = { tab = t; detail = null },
                                icon = { Icon(t.icon, null) },
                                label = { Text(t.label) },
                            )
                        }
                    }
                }
            },
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                val d = detail
                if (d != null) {
                    DetailScreen(d, vm, onBack = { detail = null })
                } else {
                    when (tab) {
                        MainTab.LIBRARY -> LibraryScreen(vm, onOpen = { detail = it })
                        MainTab.PLAYLISTS -> PlaylistsScreen(vm, onOpen = { detail = it })
                        MainTab.EQUALIZER -> EqualizerScreen()
                        MainTab.SETTINGS -> SettingsScreen(vm)
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = showPlayer && player.hasMedia,
            enter = slideInVertically { it },
            exit = slideOutVertically { it },
        ) {
            NowPlayingScreen(vm, onClose = { showPlayer = false })
        }
    }
}
