package com.ritmo.player.update

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.ritmo.player.MainActivity
import com.ritmo.player.R
import com.ritmo.player.data.UpdateInfo

/** Mostra a notificação "Nova versão do Ritmo" (uma vez por versão). */
object UpdateNotifier {
    const val ACTION_UPDATE_NOW = "com.ritmo.player.UPDATE_NOW"
    private const val CHANNEL = "updates"
    private const val NOTIFICATION_ID = 4201
    private const val PREFS = "update_notifier"
    private const val KEY_LAST = "last_notified"

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, "Atualizações do app", NotificationManager.IMPORTANCE_HIGH).apply {
                        description = "Avisa quando sai uma versão nova do Ritmo"
                    }
                )
            }
        }
    }

    /** Avisa sobre a versão, se ainda não avisou dela. A chave é o link do APK (único por versão). */
    fun notifyIfNew(context: Context, info: UpdateInfo) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getString(KEY_LAST, null) == info.apkUrl) return
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        ensureChannel(context)

        val open = PendingIntent.getActivity(
            context, 1,
            Intent(context, MainActivity::class.java)
                .setAction(ACTION_UPDATE_NOW)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val later = PendingIntent.getBroadcast(
            context, 2,
            Intent(context, UpdateDismissReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val name = info.name.ifBlank { "versão nova" }
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_tile_note)
            .setContentTitle("Nova versão do Ritmo")
            .setContentText("$name saiu. Toque para ver as novidades e atualizar")
            .setStyle(NotificationCompat.BigTextStyle().bigText("$name saiu. Toque para ver as novidades e atualizar"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_RECOMMENDATION)
            .setAutoCancel(true)
            .setContentIntent(open)
            .addAction(0, "Atualizar agora", open)
            .addAction(0, "Depois", later)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification) }
        prefs.edit().putString(KEY_LAST, info.apkUrl).apply()
    }

    fun cancel(context: Context) {
        NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID)
    }
}

/** Botão "Depois": só fecha a notificação. */
class UpdateDismissReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        UpdateNotifier.cancel(context)
    }
}
