package com.ritmo.player.ui

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ritmo.player.data.Song
import java.io.File

/** Pastas onde o Android deixa guardar áudio. */
private val ALLOWED_ROOTS = listOf(
    "Music", "Download", "Podcasts", "Ringtones", "Alarms", "Notifications", "Audiobooks", "Recordings",
)

/** Compartilhar, apagar e mover músicas. */
class MediaActions internal constructor(
    private val context: Context,
    private val vm: MainViewModel,
    private val launchSender: (IntentSender, () -> Unit) -> Unit,
    private val withLegacyWrite: (() -> Unit) -> Unit,
) {
    private fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    private fun plural(n: Int) = if (n == 1) "1 música" else "$n músicas"

    fun share(songs: List<Song>) {
        if (songs.isEmpty()) return
        val uris = ArrayList(songs.map { it.uri })
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        intent.type = "audio/*"
        intent.clipData = ClipData.newRawUri("", uris[0]).apply {
            uris.drop(1).forEach { addItem(ClipData.Item(it)) }
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        runCatching { context.startActivity(Intent.createChooser(intent, "Enviar música")) }
            .onFailure { toast("Nenhum app para compartilhar") }
    }

    fun delete(songs: List<Song>) {
        if (songs.isEmpty()) return
        val ids = songs.map { it.id }.toSet()
        val finish = { removed: Int ->
            vm.removeFromQueueByIds(ids)
            vm.loadLibrary(force = true)
            toast("${plural(removed)} apagada${if (removed == 1) "" else "s"}")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // 1.8: vai para a lixeira (o Android apaga de vez depois de 30 dias)
            val request = MediaStore.createTrashRequest(context.contentResolver, songs.map { it.uri }, true)
            launchSender(request.intentSender) {
                vm.removeFromQueueByIds(ids)
                vm.loadLibrary(force = true)
                toast("${plural(songs.size)} na lixeira (some de vez em 30 dias)")
            }
        } else {
            withLegacyWrite {
                var count = 0
                songs.forEach { s ->
                    runCatching {
                        val rows = context.contentResolver.delete(s.uri, null, null)
                        val file = File(s.path)
                        if (file.exists()) file.delete()
                        if (rows > 0 || !file.exists()) count++
                    }
                }
                finish(count)
            }
        }
    }

    /** 1.8: tira da lixeira. */
    fun restore(uris: List<android.net.Uri>, onDone: () -> Unit) {
        if (uris.isEmpty() || Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        val request = MediaStore.createTrashRequest(context.contentResolver, uris, false)
        launchSender(request.intentSender) {
            vm.loadLibrary(force = true)
            toast(if (uris.size == 1) "Música restaurada" else "${uris.size} músicas restauradas")
            onDone()
        }
    }

    /** 1.8: apaga de vez o que está na lixeira. */
    fun deleteForever(uris: List<android.net.Uri>, onDone: () -> Unit) {
        if (uris.isEmpty() || Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        val request = MediaStore.createDeleteRequest(context.contentResolver, uris)
        launchSender(request.intentSender) {
            toast("Lixeira esvaziada")
            onDone()
        }
    }

    @Suppress("DEPRECATION")
    fun move(songs: List<Song>, targetDir: String) {
        val movable = songs.filter { it.relativeDir != null && it.relativeDir != targetDir }
        if (movable.isEmpty()) {
            toast(
                if (songs.any { it.relativeDir == null }) "Músicas do cartão SD não podem ser movidas"
                else "As músicas já estão nessa pasta"
            )
            return
        }
        val pretty = targetDir.trimEnd('/')
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val request = MediaStore.createWriteRequest(context.contentResolver, movable.map { it.uri })
            launchSender(request.intentSender) {
                var ok = 0
                movable.forEach { s ->
                    runCatching {
                        val values = ContentValues().apply { put(MediaStore.Audio.Media.RELATIVE_PATH, targetDir) }
                        if (context.contentResolver.update(s.uri, values, null, null) > 0) ok++
                    }
                }
                vm.loadLibrary(force = true)
                toast(if (ok > 0) "${plural(ok)} movida${if (ok == 1) "" else "s"} para $pretty" else "Não foi possível mover")
            }
        } else {
            withLegacyWrite {
                val dir = File(Environment.getExternalStorageDirectory(), targetDir).apply { mkdirs() }
                val changed = mutableListOf<String>()
                var ok = 0
                movable.forEach { s ->
                    val src = File(s.path)
                    val dst = File(dir, src.name)
                    if (!dst.exists() && src.renameTo(dst)) {
                        ok++
                        changed += src.path
                        changed += dst.path
                    }
                }
                // Avisa o Android dos arquivos novos; a biblioteca atualiza quando terminar
                if (changed.isNotEmpty()) {
                    var pending = changed.size
                    MediaScannerConnection.scanFile(context, changed.toTypedArray(), null) { _, _ ->
                        pending--
                        if (pending == 0) vm.loadLibrary(force = true)
                    }
                }
                toast(if (ok > 0) "${plural(ok)} movida${if (ok == 1) "" else "s"} para $pretty" else "Não foi possível mover")
            }
        }
    }
}

@Composable
fun rememberMediaActions(vm: MainViewModel): MediaActions {
    val context = LocalContext.current
    var onSenderOk by remember { mutableStateOf<(() -> Unit)?>(null) }
    var onPermissionOk by remember { mutableStateOf<(() -> Unit)?>(null) }

    val senderLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        val callback = onSenderOk
        onSenderOk = null
        if (result.resultCode == Activity.RESULT_OK) callback?.invoke()
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val callback = onPermissionOk
        onPermissionOk = null
        if (granted) callback?.invoke()
        else Toast.makeText(context, "Sem permissão para alterar arquivos", Toast.LENGTH_SHORT).show()
    }

    return remember(context, vm) {
        MediaActions(
            context = context,
            vm = vm,
            launchSender = { sender, callback ->
                onSenderOk = callback
                senderLauncher.launch(IntentSenderRequest.Builder(sender).build())
            },
            withLegacyWrite = { action ->
                val granted = ContextCompat.checkSelfPermission(
                    context, Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
                if (granted) action() else {
                    onPermissionOk = action
                    permissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                }
            },
        )
    }
}

@Composable
fun ConfirmDeleteDialog(count: Int, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (count == 1) "Apagar música?" else "Apagar $count músicas?") },
        text = {
            Text(
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                    "Vai para a lixeira. Dá para restaurar por 30 dias no menu lateral → Lixeira."
                else "Os arquivos serão apagados do celular. Isso não pode ser desfeito."
            )
        },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text("Apagar", color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

/** Escolher para qual pasta mover as músicas. */
@Composable
fun MoveDialog(vm: MainViewModel, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    var creating by remember { mutableStateOf(false) }
    val folders = remember(songs) {
        (songs.mapNotNull { it.relativeDir } + listOf("Music/", "Download/"))
            .filter { dir -> dir.substringBefore('/') in ALLOWED_ROOTS }
            .distinct()
            .sortedBy { it.lowercase() }
    }

    if (creating) {
        NameDialog(
            title = "Nova pasta em Music",
            initial = "",
            confirmLabel = "Mover",
            onConfirm = { name ->
                val clean = name.replace("/", "").replace("\\", "").trim()
                if (clean.isNotEmpty()) onPick("Music/$clean/")
            },
            onDismiss = { creating = false },
        )
        return
    }

    val transparent = ListItemDefaults.colors(containerColor = Color.Transparent)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Mover para") },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                item {
                    ListItem(
                        colors = transparent,
                        leadingContent = { Icon(Icons.Rounded.CreateNewFolder, null, tint = MaterialTheme.colorScheme.primary) },
                        headlineContent = { Text("Nova pasta") },
                        modifier = Modifier.clickable { creating = true },
                    )
                }
                items(folders, key = { it }) { dir ->
                    ListItem(
                        colors = transparent,
                        leadingContent = { Icon(Icons.Rounded.Folder, null) },
                        headlineContent = { Text(dir.trimEnd('/').substringAfterLast('/')) },
                        supportingContent = { Text(dir.trimEnd('/')) },
                        modifier = Modifier.clickable { onPick(dir) },
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
