package com.ritmo.player.data

import android.content.Context
import android.media.MediaScannerConnection
import android.os.Environment
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import kotlin.coroutines.resume

/** Procura áudios nas pastas do celular que o Android ainda não registrou e manda registrar. */
object MusicScanner {
    private val extensions = setOf("mp3", "m4a", "aac", "ogg", "opus", "flac", "wav", "wma", "mka", "3gp")
    private val roots = listOf(
        "Music", "Download", "Downloads", "Documents", "Podcasts", "Audiobooks", "Recordings",
        "Android/media/com.whatsapp/WhatsApp/Media", "WhatsApp/Media", "Telegram", "Bluetooth", "Snaptube",
    )

    fun findUnindexed(known: Set<String>, hidden: Set<String>, onProgress: (Float, String) -> Unit): List<String> {
        val base = Environment.getExternalStorageDirectory()
        val dirs = roots.map { File(base, it) }.filter { runCatching { it.isDirectory }.getOrDefault(false) }
        val out = mutableListOf<String>()
        dirs.forEachIndexed { i, dir ->
            onProgress(i.toFloat() / dirs.size.coerceAtLeast(1), dir.name)
            walk(dir, 0, known, hidden, out)
        }
        onProgress(1f, "")
        return out
    }

    private fun walk(dir: File, depth: Int, known: Set<String>, hidden: Set<String>, out: MutableList<String>) {
        if (depth > 6 || out.size > 3000) return
        if (dir.absolutePath in hidden) return
        if (File(dir, ".nomedia").exists()) return
        val files = runCatching { dir.listFiles() }.getOrNull() ?: return
        for (f in files) {
            if (f.isDirectory) {
                if (!f.name.startsWith(".")) walk(f, depth + 1, known, hidden, out)
            } else if (f.extension.lowercase() in extensions && f.absolutePath !in known && f.length() > 50_000) {
                out += f.absolutePath
            }
        }
    }

    /** Pede ao Android para registrar os arquivos (espera até 30 segundos). */
    suspend fun index(context: Context, paths: List<String>) {
        if (paths.isEmpty()) return
        withTimeoutOrNull(30_000) {
            suspendCancellableCoroutine { cont ->
                var left = paths.size
                MediaScannerConnection.scanFile(context, paths.toTypedArray(), null) { _, _ ->
                    synchronized(this@MusicScanner) {
                        left--
                        if (left == 0 && cont.isActive) cont.resume(Unit)
                    }
                }
            }
        }
    }
}
